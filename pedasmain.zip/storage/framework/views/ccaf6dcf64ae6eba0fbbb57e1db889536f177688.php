<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered ">
            <thead>
                <tr>
                    <th>Tabel</th>
                    <th rowspan="2">10.2.9</th>
                    <th>Jumlah Media menurut Jenis dan Induk Organisasi di Kabupaten Soppeng, 2021</th>
                </tr>
                <tr>
                    <th>Table</th>
                    <th>Number of Media by Type and Parent Organization in Soppeng Regency, 2021</th>
                </tr>
            </thead>
            <tbody>

                <tr>
                    <td rowspan="2"> Induk Organisasi/ Parent Organization</td>
                    <td colspan="2">Jenis Media/ Type of Media</td>
                </tr>
                <tr>

                    <td>Media Cetak/ Print Media</td>
                    <td>Media Online/ Online Media</td>
                </tr>
                <tr>
                    <td>(1)</td>
                    <td>(2)</td>
                    <td>(3)</td>
                </tr>
                <tr>
                    <td>Persatuan Wartawan Soppeng</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['cetak1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="cetak1" name="cetak1" value="<?php echo e(old('cetak1', $data->cetak1)); ?>">
                        <?php $__errorArgs = ['cetak1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['online1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="online1" name="online1"
                            value="<?php echo e(old('online1', $data->online1)); ?>">
                        <?php $__errorArgs = ['online1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>Ikatan Jurnalis Soppeng&nbsp;&nbsp;(IJS)</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['cetak2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="cetak2" name="cetak2" value="<?php echo e(old('cetak2', $data->cetak2)); ?>">
                        <?php $__errorArgs = ['cetak2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['online2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="online2" name="online2"
                            value="<?php echo e(old('online2', $data->online2)); ?>">
                        <?php $__errorArgs = ['online2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>Ikatan Wartawan Online (IWO) </td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['cetak3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="cetak3" name="cetak3" value="<?php echo e(old('cetak3', $data->cetak3)); ?>">
                        <?php $__errorArgs = ['cetak3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['online3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="online3" name="online3"
                            value="<?php echo e(old('online3', $data->online3)); ?>">
                        <?php $__errorArgs = ['online3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>Lain-lain</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['cetak4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="cetak4" name="cetak4" value="<?php echo e(old('cetak4', $data->cetak4)); ?>">
                        <?php $__errorArgs = ['cetak4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['online4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="online4" name="online4"
                            value="<?php echo e(old('online4', $data->online4)); ?>">
                        <?php $__errorArgs = ['online4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>Jumlah/Total</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['cetakt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="cetakt" name="cetakt" value="<?php echo e(old('cetakt', $data->cetakt)); ?>">
                        <?php $__errorArgs = ['cetakt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['onlinet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="onlinet" name="onlinet"
                            value="<?php echo e(old('onlinet', $data->onlinet)); ?>">
                        <?php $__errorArgs = ['onlinet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table>
        <thead>
            <tr>
                <th>Tabel</th>
                <th rowspan="2">10.2.9</th>
                <th>Jumlah Media menurut Jenis dan Induk Organisasi di Kabupaten Soppeng, 2021</th>
            </tr>
            <tr>
                <th>Table</th>
                <th>Number of Media by Type and Parent Organization in Soppeng Regency, 2021</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Induk Organisasi/ Parent Organization</td>
                <td>Jenis Media/ Type of Media</td>
            </tr>
            <tr>
                <td></td>
                <td>Media Cetak/ Print Media</td>
                <td>Media Online/ Online Media</td>
            </tr>
            <tr>
                <td>(1)</td>
                <td>(3)</td>
            </tr>
            <tr>
                <td>Persatuan Wartawan Soppeng</td>
                <td>18</td>
            </tr>
            <tr>
                <td>Ikatan Jurnalis Soppeng&nbsp;&nbsp;(IJS)</td>
                <td>20</td>
            </tr>
            <tr>
                <td>Ikatan Wartawan Online (IWO) </td>
                <td>11</td>
            </tr>
            <tr>
                <td>Lain-lain</td>
                <td>6</td>
            </tr>
            <tr>
                <td>Jumlah/Total</td>
                <td>55</td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <script>
        function sumOnlines() {
            var onlineElements = document.querySelectorAll('[id^="online"]');
            var onlineSum = 0;
            for (var i = 0; i < onlineElements.length; i++) {
                if (onlineElements[i].id !== "onlinet") {
                    var onlineValue = parseFloat(onlineElements[i].value) || 0;
                    onlineSum += onlineValue;
                }
            }
            document.getElementById('onlinet').value = onlineSum;
        }

        var onlineInputs = document.querySelectorAll('[id^="online"]');
        for (var i = 0; i < onlineInputs.length; i++) {
            onlineInputs[i].addEventListener('focusout', sumOnlines);
        }
    </script>
    <script>
        function sumCetaks() {
            var cetakElements = document.querySelectorAll('[id^="cetak"]');
            var cetakSum = 0;
            for (var i = 0; i < cetakElements.length; i++) {
                if (cetakElements[i].id !== "cetakt") {
                    var cetakValue = parseFloat(cetakElements[i].value) || 0;
                    cetakSum += cetakValue;
                }
            }
            document.getElementById('cetakt').value = cetakSum;
        }

        var cetakInputs = document.querySelectorAll('[id^="cetak"]');
        for (var i = 0; i < cetakInputs.length; i++) {
            cetakInputs[i].addEventListener('focusout', sumCetaks);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/019_Diskominfo/019003.blade.php ENDPATH**/ ?>