<?php if (isset($component)) { $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51 = $component; } ?>
<?php $component = App\View\Components\TabelEntriView::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabel-entri-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TabelEntriView::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'judultabel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabel),'judultabelen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabelen)]); ?>
    <?php if(!empty($data)): ?>
         <?php $__env->slot('tabel1', null, []); ?> 
            
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Tabel</th>
                        <th rowspan="2">2.2.4</th>
                        <th><?php echo e($judultabel); ?>,
                            <?php echo e($data->tahun); ?></th>
                    </tr>
                    <tr>
                        <th>Table</th>
                        <th><?php echo e($judultabelen); ?>, <?php echo e($data->tahun); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Jenis Keputusan/ Decision Category</td>
                        <td colspan="2"> <?php echo e($data->tahun); ?></td>
                    </tr>
                    <tr>
                        <td>(1)</td>
                        <td colspan="2"> (2)</td>
                    </tr>
                    <tr>
                        <td>Peraturan Daerah/Regional Regulation</td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah1" name="jumlah1"
                                value="<?php echo e(old('jumlah1', $data->jumlah1)); ?>">
                            <?php $__errorArgs = ['jumlah1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Keputusan DPRD/Parliament Decision</td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah2"
                                name="jumlah2" value="<?php echo e(old('jumlah2', $data->jumlah2)); ?>">
                            <?php $__errorArgs = ['jumlah2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Keputusan Pimpinan DPRD/Parliament Leadership Decision</td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah3"
                                name="jumlah3" value="<?php echo e(old('jumlah3', $data->jumlah3)); ?>">
                            <?php $__errorArgs = ['jumlah3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Jumlah/Total</td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlaht'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlaht"
                                name="jumlaht" value="<?php echo e(old('jumlaht', $data->jumlaht)); ?>">
                            <?php $__errorArgs = ['jumlaht'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
         <?php $__env->endSlot(); ?>
    <?php else: ?>
         <?php $__env->slot('tabel2', null, []); ?> 
            
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Tabel</th>
                        <th rowspan="2">2.2.4</th>
                        <th colspan="5">Banyaknya Keputusan DPRD Menurut Jenis Keputusan di Kabupaten Soppeng,
                            2014-2021</th>
                        <th></th>
                        <th></th>
                    </tr>
                    <tr>
                        <th>Table</th>
                        <th colspan="5">Number of Regional Parliaments Decision by Decision Category in Soppeng
                            Regency, 2014-2021</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Jenis Keputusan/</td>
                        <td rowspan="2">2014</td>
                        <td rowspan="2">2015</td>
                        <td rowspan="2">2016</td>
                        <td rowspan="2">2017</td>
                        <td rowspan="2">2018</td>
                        <td rowspan="2">2019</td>
                        <td rowspan="2">2020</td>
                        <td rowspan="2">2021</td>
                    </tr>
                    <tr>
                        <td>Decision Category</td>
                    </tr>
                    <tr>
                        <td>(1)</td>
                        <td>(2)</td>
                        <td>(3)</td>
                        <td>(4)</td>
                        <td>(5)</td>
                        <td>(6)</td>
                        <td>(7)</td>
                        <td>(8)</td>
                        <td>(9)</td>
                    </tr>
                    <tr>
                        <td>Peraturan Daerah/Regional Regulation</td>
                        <td>9</td>
                        <td>8</td>
                        <td>8</td>
                        <td>8</td>
                        <td>9</td>
                        <td>10</td>
                        <td>11</td>
                        <td>10</td>
                    </tr>
                    <tr>
                        <td>Keputusan DPRD/Parliament Decision</td>
                        <td>12</td>
                        <td>19</td>
                        <td>23</td>
                        <td>22</td>
                        <td>28</td>
                        <td>27</td>
                        <td>26</td>
                        <td>25</td>
                    </tr>
                    <tr>
                        <td>Keputusan Pimpinan DPRD/Parliament Leadership Decision</td>
                        <td>6</td>
                        <td>11</td>
                        <td>4</td>
                        <td>6</td>
                        <td>2</td>
                        <td>2</td>
                        <td>2</td>
                        <td>3</td>
                    </tr>
                    <tr>
                        <td>Jumlah/Total</td>
                        <td>27</td>
                        <td>38</td>
                        <td>35</td>
                        <td>36</td>
                        <td>39</td>
                        <td>39</td>
                        <td>39</td>
                        <td>38</td>
                    </tr>
                </tbody>
            </table>

         <?php $__env->endSlot(); ?>
    <?php endif; ?>
     <?php $__env->slot('script', null, []); ?> 
        
        <?php echo $__env->make('tabel.skpd.027_DPRD.script5', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51)): ?>
<?php $component = $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51; ?>
<?php unset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/027_DPRD/027005.blade.php ENDPATH**/ ?>