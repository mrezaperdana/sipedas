<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-c3ow" rowspan="2">No.</th>
                    <th class="tg-c3ow" rowspan="2">Komoditas</th>
                    <th class="tg-pb0m" colspan="2"><span style="font-weight:normal">Produksi</span></th>
                </tr>
                <tr>
                    
                    <th class="tg-2b7s"><span style="font-weight:normal">2022</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-pb0m"><span style="font-weight:normal">1</span></td>
                    <td class="tg-pb0m"><span style="font-weight:normal">Tembakau</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksitembakau'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksitembakau"
                            name="produksitembakau" value="<?php echo e(old('produksitembakau', $data->produksitembakau)); ?>">
                        <?php $__errorArgs = ['produksitembakau'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j"><span style="font-weight:normal">2</span></td>
                    <td class="tg-8d8j"><span style="font-weight:normal">Kapas</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksikapas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksikapas"
                            name="produksikapas" value="<?php echo e(old('produksikapas', $data->produksikapas)); ?>">
                        <?php $__errorArgs = ['produksikapas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j" colspan="2"><span style="font-weight:normal">Jumlah</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksitotal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksitotal"
                            name="produksitotal" value="<?php echo e(old('produksitotal', $data->produksitotal)); ?>">
                        <?php $__errorArgs = ['produksitotal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>

        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>

    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-c3ow" rowspan="2">No.</th>
                <th class="tg-c3ow" rowspan="2">Komoditas</th>
                <th class="tg-pb0m" colspan="2"><span style="font-weight:normal">Produksi</span></th>
            </tr>
            <tr>
                <th class="tg-pb0m"><span style="font-weight:normal">2021</span></th>
                <th class="tg-2b7s"><span style="font-weight:normal">2022</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-pb0m"><span style="font-weight:normal">1</span></td>
                <td class="tg-pb0m"><span style="font-weight:normal">Tembakau</span></td>
                <td class="tg-jkyp"><span style="font-weight:normal">121</span></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j"><span style="font-weight:normal">2</span></td>
                <td class="tg-8d8j"><span style="font-weight:normal">Kapas</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">11.29</span></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j" colspan="2"><span style="font-weight:normal">Jumlah</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">132.29</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
            </tr>
        </tbody>

    </table>

<?php endif; ?>
<?php $__env->startSection('script'); ?>
    <script>
        function sumproduksitotals() {
            var produksitembakau = document.getElementById('produksitembakau').value || 0;
            var produksikapas = document.getElementById('produksikapas').value || 0;


            var produksitotalSum = parseInt(produksitembakau) + parseInt(produksikapas);

            document.getElementById('produksitotal').value = produksitotalSum;
        }

        document.getElementById('produksitembakau').addEventListener('focusout', sumproduksitotals);
        document.getElementById('produksikapas').addEventListener('focusout', sumproduksitotals);
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/Perkebunan/014001.blade.php ENDPATH**/ ?>