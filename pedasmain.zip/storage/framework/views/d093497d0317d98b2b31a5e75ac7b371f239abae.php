<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-amwm" rowspan="2">NO</th>
                    <th class="tg-amwm" rowspan="2">URAIAN</th>
                    
                    <th class="tg-bobw" colspan="2"><span style="font-weight:bold"><?php echo e($data->tahun); ?></span></th>
                </tr>
                <tr>
                    
                    <th class="tg-bobw"><span style="font-weight:bold">JUMLAH USAHA</span></th>
                    <th class="tg-bobw"><span style="font-weight:bold">OMZET (RUPIAH)</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-8d8j">1</td>
                    <td class="tg-bobw"><span style="font-weight:bold">Pasar</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahusaha1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahusaha1"
                            name="jumlahusaha1" value="<?php echo e(old('jumlahusaha1', $data->jumlahusaha1)); ?>">
                        <?php $__errorArgs = ['jumlahusaha1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['omzet1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet1" name="omzet1"
                            value="<?php echo e(old('omzet1', $data->omzet1)); ?>">
                        <?php $__errorArgs = ['omzet1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">2</td>
                    <td class="tg-bobw"><span style="font-weight:bold">Toko</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahusaha2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahusaha2"
                            name="jumlahusaha2" value="<?php echo e(old('jumlahusaha2', $data->jumlahusaha2)); ?>">
                        <?php $__errorArgs = ['jumlahusaha2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['omzet2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet2" name="omzet2"
                            value="<?php echo e(old('omzet2', $data->omzet2)); ?>">
                        <?php $__errorArgs = ['omzet2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">3</td>
                    <td class="tg-bobw"><span style="font-weight:bold">Kios/Warung</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahusaha3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahusaha3"
                            name="jumlahusaha3" value="<?php echo e(old('jumlahusaha3', $data->jumlahusaha3)); ?>">
                        <?php $__errorArgs = ['jumlahusaha3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['omzet3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet3" name="omzet3"
                            value="<?php echo e(old('omzet3', $data->omzet3)); ?>">
                        <?php $__errorArgs = ['omzet3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">4</td>
                    <td class="tg-bobw"><span style="font-weight:bold">Minimarket</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahusaha4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahusaha4"
                            name="jumlahusaha4" value="<?php echo e(old('jumlahusaha4', $data->jumlahusaha4)); ?>">
                        <?php $__errorArgs = ['jumlahusaha4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['omzet4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet4" name="omzet4"
                            value="<?php echo e(old('omzet4', $data->omzet4)); ?>">
                        <?php $__errorArgs = ['omzet4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">5</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya" name="lainnya"
                            value="<?php echo e(old('lainnya', $data->lainnya)); ?>">
                        <?php $__errorArgs = ['lainnya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahusaha5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahusaha5"
                            name="jumlahusaha5" value="<?php echo e(old('jumlahusaha5', $data->jumlahusaha5)); ?>">
                        <?php $__errorArgs = ['jumlahusaha5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['omzet5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet5" name="omzet5"
                            value="<?php echo e(old('omzet5', $data->omzet5)); ?>">
                        <?php $__errorArgs = ['omzet5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>

                <tr>
                    <td class="tg-bobw" colspan="2"><span style="font-weight:bold">JUMLAH</span></td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahusahat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahusahat"
                            name="jumlahusahat" value="<?php echo e(old('jumlahusahat', $data->jumlahusahat)); ?>">
                        <?php $__errorArgs = ['jumlahusahat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['omzett'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzett" name="omzett"
                            value="<?php echo e(old('omzett', $data->omzett)); ?>">
                        <?php $__errorArgs = ['omzett'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>

    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-amwm" rowspan="2">NO</th>
                <th class="tg-amwm" rowspan="2">URAIAN</th>
                <th class="tg-bobw" colspan="2"><span style="font-weight:bold">2021</span></th>
                <th class="tg-bobw" colspan="2"><span style="font-weight:bold">2022</span></th>
            </tr>
            <tr>
                <th class="tg-bobw"><span style="font-weight:bold">JUMLAH USAHA</span></th>
                <th class="tg-bobw"><span style="font-weight:bold">OMZET (RUPIAH)</span></th>
                <th class="tg-bobw"><span style="font-weight:bold">JUMLAH USAHA</span></th>
                <th class="tg-bobw"><span style="font-weight:bold">OMZET (RUPIAH)</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-8d8j">1</td>
                <td class="tg-bobw"><span style="font-weight:bold">Pasar</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">18</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">197,534,892,979</span></td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">2</td>
                <td class="tg-bobw"><span style="font-weight:bold">Toko</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">501</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">60,592,484,780</span></td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">3</td>
                <td class="tg-bobw"><span style="font-weight:bold">Kios/Warung</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">508</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">6,347,260,000</span></td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">4</td>
                <td class="tg-bobw"><span style="font-weight:bold">Minimarket</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">23</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">123,271,397,625</span></td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">5</td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
                <td class="tg-bobw"></td>
            </tr>

            <tr>
                <td class="tg-bobw" colspan="2"><span style="font-weight:bold">JUMLAH</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">1050</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">387,746,035,384</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">0</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">0</span></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    <script>
        function sumOmzets() {
            var omzet1 = document.getElementById('omzet1').value || 0;
            var omzet2 = document.getElementById('omzet2').value || 0;
            var omzet3 = document.getElementById('omzet3').value || 0;
            var omzet4 = document.getElementById('omzet4').value || 0;
            var omzet5 = document.getElementById('omzet5').value || 0;


            var omzetSum = parseInt(omzet1) + parseInt(omzet2) + parseInt(omzet3) + parseInt(omzet4) + parseInt(
                omzet5);

            document.getElementById('omzett').value = omzetSum;
        }

        document.getElementById('omzet1').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet2').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet3').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet4').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet5').addEventListener('focusout', sumOmzets);
    </script>
    <script>
        function sumJumlahusahas() {
            var jumlahusaha1 = document.getElementById('jumlahusaha1').value || 0;
            var jumlahusaha2 = document.getElementById('jumlahusaha2').value || 0;
            var jumlahusaha3 = document.getElementById('jumlahusaha3').value || 0;
            var jumlahusaha4 = document.getElementById('jumlahusaha4').value || 0;
            var jumlahusaha5 = document.getElementById('jumlahusaha5').value || 0;

            var jumlahusahaSum = parseInt(jumlahusaha1) + parseInt(jumlahusaha2) + parseInt(jumlahusaha3) + parseInt(
                jumlahusaha4) + parseInt(
                jumlahusaha5);

            document.getElementById('jumlahusahat').value = jumlahusahaSum;
        }

        document.getElementById('jumlahusaha1').addEventListener('focusout', sumJumlahusahas);
        document.getElementById('jumlahusaha2').addEventListener('focusout', sumJumlahusahas);
        document.getElementById('jumlahusaha3').addEventListener('focusout', sumJumlahusahas);
        document.getElementById('jumlahusaha4').addEventListener('focusout', sumJumlahusahas);
        document.getElementById('jumlahusaha5').addEventListener('focusout', sumJumlahusahas);
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/Perdagangan/011001.blade.php ENDPATH**/ ?>