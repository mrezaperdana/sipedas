<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Tabel</th>
                    <th rowspan="2">10.2.11</th>
                    <th>Banyaknya Website menurut Kecamatan di Kabupaten <br>Soppeng, 2018-2022</th>
                </tr>
                <tr>
                    <th>Table</th>
                    <th>Number of Website by Subdistrict in Soppeng Regency, 2018-2022</th>

                </tr>
            </thead>
            <tbody>

                <tr>
                    <td colspan="2">Kecamatan/<br>Subdistrict</td>
                    <td>2018</td>
                </tr>
                <tr>
                </tr>
                <tr>
                    <td colspan="2">(1)</td>
                    <td>(2)</td>
                </tr>
                <tr>
                    <td colspan="2">010. Marioriwawo</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['website2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="website2" name="website2" value="<?php echo e(old('website2', $data->website2)); ?>">
                        <?php $__errorArgs = ['website2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">020. Lalabata</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['website2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="website2" name="website2"
                            value="<?php echo e(old('website2', $data->website2)); ?>">
                        <?php $__errorArgs = ['website2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">030. Liliriaja</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['website3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="website3" name="website3"
                            value="<?php echo e(old('website3', $data->website3)); ?>">
                        <?php $__errorArgs = ['website3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">031. Ganra</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['website4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="website4" name="website4"
                            value="<?php echo e(old('website4', $data->website4)); ?>">
                        <?php $__errorArgs = ['website4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">032. Citta</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['website5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="website5" name="website5"
                            value="<?php echo e(old('website5', $data->website5)); ?>">
                        <?php $__errorArgs = ['website5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">040. Lilirilau</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['website6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="website6" name="website6"
                            value="<?php echo e(old('website6', $data->website6)); ?>">
                        <?php $__errorArgs = ['website6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">050. Donri-Donri</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['website7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="website7" name="website7"
                            value="<?php echo e(old('website7', $data->website7)); ?>">
                        <?php $__errorArgs = ['website7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">060. Marioriawa</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['website8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="website8" name="website8"
                            value="<?php echo e(old('website8', $data->website8)); ?>">
                        <?php $__errorArgs = ['website8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" rowspan="2">Jumlah/ Total</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['websitet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="websitet" name="websitet"
                            value="<?php echo e(old('websitet', $data->websitet)); ?>">
                        <?php $__errorArgs = ['websitet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                </tr>
            </tbody>
        </table>

        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tabel</th>
                <th rowspan="2">10.2.11</th>
                <th colspan="5">Banyaknya Website menurut Kecamatan di Kabupaten <br>Soppeng, 2018-2022</th>
            </tr>
            <tr>
                <th>Table</th>
                <th colspan="4">Number of Website by Subdistrict in Soppeng Regency, 2018-2022</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2" rowspan="2">Kecamatan/<br>Subdistrict</td>
                <td rowspan="2">2018</td>
                <td rowspan="2">2019</td>
                <td rowspan="2">2020</td>
                <td rowspan="2">2022</td>
                <td rowspan="2">2022</td>
            </tr>
            <tr>
            </tr>
            <tr>
                <td colspan="2">(1)</td>
                <td>(2)</td>
                <td>(3)</td>
                <td>(4)</td>
                <td>(5)</td>
                <td>(5)</td>
            </tr>
            <tr>
                <td colspan="2">010. Marioriwawo</td>
                <td>2</td>
                <td>&nbsp;&nbsp;7 </td>
                <td>&nbsp;&nbsp;7 </td>
                <td>&nbsp;&nbsp;7 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">020. Lalabata</td>
                <td>50</td>
                <td>&nbsp;&nbsp;60 </td>
                <td>&nbsp;&nbsp;57 </td>
                <td>&nbsp;&nbsp;55 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">030. Liliriaja</td>
                <td>2</td>
                <td>&nbsp;&nbsp;7 </td>
                <td>&nbsp;&nbsp;7 </td>
                <td>&nbsp;&nbsp;7 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">031. Ganra</td>
                <td>1</td>
                <td>&nbsp;&nbsp;3 </td>
                <td>&nbsp;&nbsp;3 </td>
                <td>&nbsp;&nbsp;3 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">032. Citta</td>
                <td>2</td>
                <td>&nbsp;&nbsp;3 </td>
                <td>&nbsp;&nbsp;3 </td>
                <td>&nbsp;&nbsp;3 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">040. Lilirilau</td>
                <td>1</td>
                <td>&nbsp;&nbsp;9 </td>
                <td>&nbsp;&nbsp;9 </td>
                <td>&nbsp;&nbsp;9 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">050. Donri-Donri</td>
                <td>2</td>
                <td>&nbsp;&nbsp;4 </td>
                <td>&nbsp;&nbsp;4 </td>
                <td>&nbsp;&nbsp;4 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">060. Marioriawa</td>
                <td>2</td>
                <td>&nbsp;&nbsp;9 </td>
                <td>&nbsp;&nbsp;9 </td>
                <td>&nbsp;&nbsp;9 </td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2" rowspan="2">Jumlah/ Total</td>
                <td rowspan="2">&nbsp;&nbsp;62 </td>
                <td rowspan="2">&nbsp;&nbsp;102 </td>
                <td rowspan="2">&nbsp;&nbsp;99 </td>
                <td rowspan="2">&nbsp;&nbsp;97 </td>
                <td rowspan="2">&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;</td>
            </tr>
            <tr>
            </tr>
        </tbody>
    </table>

<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/019_Diskominfo/019005.blade.php ENDPATH**/ ?>