<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                    <th class="tg-amwm" rowspan="2">4.2.15</th>
                    <th class="tg-wa1i" colspan="2"><span style="font-weight:bold">Banyaknya Pasien Rawat Jalan dan
                            Rawat Inap Menurut Jenis Penyakit di RSUD La Temmamala Kabupaten Soppeng, 2021</span></th>
                </tr>
                <tr>
                    <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                    <th class="tg-xxp7" colspan="2"><span style="font-weight:bold;font-style:italic">Number of
                            Newoutpatient1 and Inpatient by Type of Disease in La Temmamala Hospital of Soppeng
                            Regency,
                            2021</span>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr class="text-nowrap">
                    <td class="tg-baqh" rowspan="2"><span style="font-style:normal;color:#000">Jenis
                            Penyakit/</span><span style="font-style:italic;color:#000">Type of Disease</span></td>
                    <td class="tg-baqh" colspan="2"><span style="font-style:normal;color:#000">Rawat
                            Jalan/</span><span style="font-style:italic;color:#000">Newoutpatient1</span></td>
                    <td class="tg-baqh" rowspan="2"><span style="font-style:normal;color:#000">Rawat
                            Inap/</span><span style="font-style:italic;color:#000">Inpatient</span></td>
                </tr>
                <tr class="text-nowrap">
                    <td class="tg-baqh"><span style="font-style:normal;color:#000">Kunjungan Baru/</span><span
                            style="font-style:italic;color:#000">New Visits</span></td>
                    <td class="tg-baqh"><span style="font-style:normal;color:#000">Jumlah Kunjungan/</span><span
                            style="font-style:italic;color:#000"> Number of Visits</span></td>
                </tr>
                <tr>
                    <td class="tg-nrix">(1)</td>
                    <td class="tg-nrix">(2)</td>
                    <td class="tg-nrix">(3)</td>
                    <td class="tg-nrix">(4)</td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Demam Berdarah/</span><span
                            style="font-style:italic;color:#000">Dengue Fever</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatient1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatient1"
                            name="newoutpatient1" value="<?php echo e(old('newoutpatient1', $data->newoutpatient1)); ?>">
                        <?php $__errorArgs = ['newoutpatient1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatient1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="totaloutpatient1"
                            name="totaloutpatient1" value="<?php echo e(old('totaloutpatient1', $data->totaloutpatient1)); ?>">
                        <?php $__errorArgs = ['totaloutpatient1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatient1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatient1"
                            name="inpatient1" value="<?php echo e(old('inpatient1', $data->inpatient1)); ?>">
                        <?php $__errorArgs = ['inpatient1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Diare/</span><span
                            style="font-style:italic;color:#000">Diarrhea</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatient2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatient2"
                            name="newoutpatient2" value="<?php echo e(old('newoutpatient2', $data->newoutpatient2)); ?>">
                        <?php $__errorArgs = ['newoutpatient2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatient2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="totaloutpatient2"
                            name="totaloutpatient2" value="<?php echo e(old('totaloutpatient2', $data->totaloutpatient2)); ?>">
                        <?php $__errorArgs = ['totaloutpatient2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatient2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatient2"
                            name="inpatient2" value="<?php echo e(old('inpatient2', $data->inpatient2)); ?>">
                        <?php $__errorArgs = ['inpatient2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Tipes/</span><span
                            style="font-style:italic;color:#000">Typhoid</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatient3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatient3"
                            name="newoutpatient3" value="<?php echo e(old('newoutpatient3', $data->newoutpatient3)); ?>">
                        <?php $__errorArgs = ['newoutpatient3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatient3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="totaloutpatient3"
                            name="totaloutpatient3" value="<?php echo e(old('totaloutpatient3', $data->totaloutpatient3)); ?>">
                        <?php $__errorArgs = ['totaloutpatient3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatient3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatient3"
                            name="inpatient3" value="<?php echo e(old('inpatient3', $data->inpatient3)); ?>">
                        <?php $__errorArgs = ['inpatient3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Tuberkulosis/</span><span
                            style="font-style:italic;color:#000">Tuberculosis</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatient4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatient4"
                            name="newoutpatient4" value="<?php echo e(old('newoutpatient4', $data->newoutpatient4)); ?>">
                        <?php $__errorArgs = ['newoutpatient4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatient4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="totaloutpatient4" name="totaloutpatient4"
                            value="<?php echo e(old('totaloutpatient4', $data->totaloutpatient4)); ?>">
                        <?php $__errorArgs = ['totaloutpatient4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatient4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatient4"
                            name="inpatient4" value="<?php echo e(old('inpatient4', $data->inpatient4)); ?>">
                        <?php $__errorArgs = ['inpatient4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Tetanus/</span><span
                            style="font-style:italic;color:#000">Tetanus</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatient5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatient5"
                            name="newoutpatient5" value="<?php echo e(old('newoutpatient5', $data->newoutpatient5)); ?>">
                        <?php $__errorArgs = ['newoutpatient5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatient5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="totaloutpatient5" name="totaloutpatient5"
                            value="<?php echo e(old('totaloutpatient5', $data->totaloutpatient5)); ?>">
                        <?php $__errorArgs = ['totaloutpatient5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatient5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatient5"
                            name="inpatient5" value="<?php echo e(old('inpatient5', $data->inpatient5)); ?>">
                        <?php $__errorArgs = ['inpatient5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Malaria/</span><span
                            style="font-style:italic;color:#000">Malaria</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatient6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatient6"
                            name="newoutpatient6" value="<?php echo e(old('newoutpatient6', $data->newoutpatient6)); ?>">
                        <?php $__errorArgs = ['newoutpatient6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatient6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="totaloutpatient6" name="totaloutpatient6"
                            value="<?php echo e(old('totaloutpatient6', $data->totaloutpatient6)); ?>">
                        <?php $__errorArgs = ['totaloutpatient6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatient6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatient6"
                            name="inpatient6" value="<?php echo e(old('inpatient6', $data->inpatient6)); ?>">
                        <?php $__errorArgs = ['inpatient6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-cly1">Lainnya </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatient7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatient7"
                            name="newoutpatient7" value="<?php echo e(old('newoutpatient7', $data->newoutpatient7)); ?>">
                        <?php $__errorArgs = ['newoutpatient7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatient7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="totaloutpatient7" name="totaloutpatient7"
                            value="<?php echo e(old('totaloutpatient7', $data->totaloutpatient7)); ?>">
                        <?php $__errorArgs = ['totaloutpatient7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatient7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatient7"
                            name="inpatient7" value="<?php echo e(old('inpatient7', $data->inpatient7)); ?>">
                        <?php $__errorArgs = ['inpatient7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-baqh"><span style="font-style:normal;color:#000">Jumlah/</span><span
                            style="font-style:italic;color:#000">Total</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['newoutpatientt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newoutpatientt"
                            name="newoutpatientt" value="<?php echo e(old('newoutpatientt', $data->newoutpatientt)); ?>">
                        <?php $__errorArgs = ['newoutpatientt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totaloutpatientt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="totaloutpatientt" name="totaloutpatientt"
                            value="<?php echo e(old('totaloutpatientt', $data->totaloutpatientt)); ?>">
                        <?php $__errorArgs = ['totaloutpatientt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['inpatientt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpatientt"
                            name="inpatientt" value="<?php echo e(old('inpatientt', $data->inpatientt)); ?>">
                        <?php $__errorArgs = ['inpatientt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                <th class="tg-amwm" rowspan="2">4.2.15</th>
                <th class="tg-wa1i" colspan="2"><span style="font-weight:bold">Banyaknya Pasien Rawat Jalan dan
                        Rawat Inap Menurut Jenis Penyakit di RSUD La Temmamala Kabupaten Soppeng, 2021</span></th>
            </tr>
            <tr>
                <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                <th class="tg-xxp7" colspan="2"><span style="font-weight:bold;font-style:italic">Number of
                        Newoutpatient1 and Inpatient by Type of Disease in La Temmamala Hospital of Soppeng Regency,
                        2021</span>
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-baqh" rowspan="2"><span style="font-style:normal;color:#000">Jenis
                        Penyakit/</span><span style="font-style:italic;color:#000">Type of Disease</span></td>
                <td class="tg-baqh" colspan="2"><span style="font-style:normal;color:#000">Rawat
                        Jalan/</span><span style="font-style:italic;color:#000">Newoutpatient1</span></td>
                <td class="tg-baqh" rowspan="2"><span style="font-style:normal;color:#000">Rawat
                        Inap/</span><span style="font-style:italic;color:#000">Inpatient</span></td>
            </tr>
            <tr>
                <td class="tg-baqh"><span style="font-style:normal;color:#000">Kunjungan Baru/</span><span
                        style="font-style:italic;color:#000">New Visits</span></td>
                <td class="tg-baqh"><span style="font-style:normal;color:#000">Jumlah Kunjungan/</span><span
                        style="font-style:italic;color:#000"> Number of Visits</span></td>
            </tr>
            <tr>
                <td class="tg-nrix">(1)</td>
                <td class="tg-nrix">(2)</td>
                <td class="tg-nrix">(3)</td>
                <td class="tg-nrix">(4)</td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Demam Berdarah/</span><span
                        style="font-style:italic;color:#000">Dengue Fever</span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;21 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;65 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;36 </span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Diare/</span><span
                        style="font-style:italic;color:#000">Diarrhea</span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;52 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;208 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;42 </span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Tipes/</span><span
                        style="font-style:italic;color:#000">Typhoid</span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;15 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;44 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;26 </span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Tuberkulosis/</span><span
                        style="font-style:italic;color:#000">Tuberculosis</span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;128 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;2,713 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;41 </span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Tetanus/</span><span
                        style="font-style:italic;color:#000">Tetanus</span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;3 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;24 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;4 </span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Malaria/</span><span
                        style="font-style:italic;color:#000">Malaria</span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;1 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;1 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;1 </span></td>
            </tr>
            <tr>
                <td class="tg-cly1">Lainnya </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;5,272 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;65,440 </span></td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;5,045 </span></td>
            </tr>
            <tr>
                <td class="tg-baqh"><span style="font-style:normal;color:#000">Jumlah/</span><span
                        style="font-style:italic;color:#000">Total</span></td>
                <td class="tg-mwxe">&nbsp;&nbsp;5,492 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;68,495 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;5,195 </td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <?php echo $__env->make('tabel.skpd.036_RSUD.script3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/036_RSUD/036003.blade.php ENDPATH**/ ?>