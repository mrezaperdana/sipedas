<table class="tg">
    <thead>
        <tr>
            <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
            <th class="tg-amwm" rowspan="2">2.3.7</th>
            <th class="tg-wa1i" colspan="5"><span style="font-weight:bold">Banyaknya Pegawai Negeri Sipil (PNS) di
                    Instansi Vertikal Menurut Unit Kerja dan Golongan di Kabupaten Soppeng, 2021</span></th>
        </tr>
        <tr>
            <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
            <th class="tg-xxp7" colspan="5"><span style="font-weight:bold;font-style:italic">Number of Civil Servant
                    in Vertical Agencies by Work Units and Class in Soppeng Regency, 2021</span></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="tg-cly1"></td>
            <td class="tg-cly1"></td>
            <td class="tg-cly1"></td>
            <td class="tg-cly1"></td>
            <td class="tg-cly1"></td>
            <td class="tg-cly1"></td>
            <td class="tg-cly1"></td>
        </tr>
        <tr>
            <td class="tg-baqh" rowspan="2">No</td>
            <td class="tg-baqh" rowspan="2"><span style="font-style:normal;color:#000">Unit Kerja/ </span><span
                    style="font-style:italic;color:#000">Work Unit</span></td>
            <td class="tg-nrix"></td>
            <td class="tg-baqh" colspan="4"><span style="font-style:normal;color:#000">Golongan/ </span><span
                    style="font-style:italic;color:#000">Class</span></td>
        </tr>
        <tr>
            <td class="tg-nrix">I</td>
            <td class="tg-nrix">II</td>
            <td class="tg-nrix">III</td>
            <td class="tg-nrix">IV</td>
            <td class="tg-baqh"><span style="font-style:normal;color:#000">Jumlah/ </span><span
                    style="font-style:italic;color:#000">Total</span></td>
        </tr>
        <tr>
            <td class="tg-nrix">(1)</td>
            <td class="tg-nrix">(2)</td>
            <td class="tg-nrix">(3)</td>
            <td class="tg-nrix">(4)</td>
            <td class="tg-nrix">(5)</td>
            <td class="tg-nrix">(6)</td>
            <td class="tg-nrix">(7)</td>
        </tr>
        <tr>
            <td class="tg-nrix">9</td>
            <td class="tg-nrix">Kodim/Military District Commander</td>
            <td class="tg-nrix">19</td>
            <td class="tg-nrix">91</td>
            <td class="tg-nrix">10</td>
            <td class="tg-nrix">1</td>
            <td class="tg-cly1">121</td>
        </tr>
        <tr>
            <td class="tg-baqh" rowspan="8">Rincian</td>
            <td class="tg-cly1">Koramil Marioriwawo</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">2</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">13</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-cly1">15</td>
        </tr>
        <tr>
            <td class="tg-cly1">Koramil Lalabata</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">9</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">38</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">7</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-cly1">55</td>
        </tr>
        <tr>
            <td class="tg-cly1">Koramil Liliriaja</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">6</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-cly1">8</td>
        </tr>
        <tr>
            <td class="tg-cly1">Koramil Lilirilau</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">2</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">10</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-cly1">13</td>
        </tr>
        <tr>
            <td class="tg-cly1">Koramil Ganra</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">4</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-cly1">5</td>
        </tr>
        <tr>
            <td class="tg-cly1">Koramil Citta</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">4</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-cly1">5</td>
        </tr>
        <tr>
            <td class="tg-cly1">Koramil Donri-Donri</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">9</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-cly1">10</td>
        </tr>
        <tr>
            <td class="tg-cly1">Koramil Marioriawa</td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">9</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            <td class="tg-cly1">10</td>

        </tr>
    </tbody>
</table>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/Kodim/001001.blade.php ENDPATH**/ ?>