
<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box bg-gradient-success ">
                <span class="info-box-icon"><i class="far fa-thumbs-up"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Selesai</span>
                    <span class="info-box-number"><?php echo e($selesai); ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 70%"></div>
                    </div>
                    <span class="progress-description">
                        <a href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>" class="info-box-text"
                            style="color: inherit; text-decoration: underline;">Lihat
                            selengkapnya</a>
                    </span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box bg-gradient-warning">
                <span class="info-box-icon"><i class="fa fa-exclamation-triangle "></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Belum Selesai</span>
                    <span class="info-box-number"><?php echo e($belum); ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 70%"></div>
                    </div>
                    <span class="progress-description">
                        <a href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>" class="info-box-text"
                            style="color: inherit; text-decoration: underline;">Lihat
                            selengkapnya</a>
                    </span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box bg-gradient-danger">
                <span class="info-box-icon"><i class="fa fa-times"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Belum Terisi</span>
                    <span class="info-box-number"><?php echo e($kosong); ?></span>
                    <div class="progress">
                        <div class="progress-bar" style="width: 70%"></div>
                    </div>
                    <span class="progress-description">
                        <a href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>" class="info-box-text"
                            style="color: inherit; text-decoration: underline;">Lihat
                            selengkapnya</a>
                    </span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.users.layouts.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pedas\resources\views/dashboard/users/index.blade.php ENDPATH**/ ?>