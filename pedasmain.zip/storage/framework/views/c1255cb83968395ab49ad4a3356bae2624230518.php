<?php if (isset($component)) { $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51 = $component; } ?>
<?php $component = App\View\Components\TabelEntriView::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabel-entri-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TabelEntriView::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'judultabel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabel),'judultabelen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabelen)]); ?>
    <?php if(!empty($data)): ?>
         <?php $__env->slot('tabel1', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tabel</th>
                        <th rowspan="2">4.3.9</th>
                        <th>Banyaknya Sarana dan Prasarana Kebersihan Menurut Jenis di Kabupaten Soppeng, 2021</th>
                    </tr>
                    <tr>
                        <th>Table</th>
                        <th>Number of sanitation facilities and infrastructure by type in Soppeng Regency, 2021</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td>Jenis Sarana dan Prasarana/ Type of Infrastructure</td>
                        <td>Jumlah/ Amount</td>
                        <td>Keterangan/ Explanation</td>
                    </tr>

                    <tr>
                        <td>(1)</td>
                        <td>(2)</td>
                        <td>(3)</td>
                    </tr>
                    <tr>
                        <td>Mobil Operasional Pimpinan/ Chief Operational Car</td>

                        <td class="tg-cly1"><input type="text"
                                class="form-control <?php $__errorArgs = ['amount1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount1" name="amount1"
                                value="<?php echo e(old('amount1', $data->amount1)); ?>">
                            <?php $__errorArgs = ['amount1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td class="tg-cly1"><input type="text"
                                class="form-control form-control2 <?php $__errorArgs = ['deaf1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="deaf1"
                                name="deaf1" value="<?php echo e(old('deaf1', $data->deaf1)); ?>">
                            <?php $__errorArgs = ['deaf1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Mobil Pengangkut Sampah (Kijang Box)/Car Garbage</td>
                        <td class="tg-cly1"><input type="text"
                                class="form-control <?php $__errorArgs = ['amount2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount2"
                                name="amount2" value="<?php echo e(old('amount2', $data->amount2)); ?>">
                            <?php $__errorArgs = ['amount2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td class="tg-cly1"><input type="text"
                                class="form-control form-control2 <?php $__errorArgs = ['deaf2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="deaf2"
                                name="deaf2" value="<?php echo e(old('deaf2', $data->deaf2)); ?>">
                            <?php $__errorArgs = ['deaf2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Mobil Pengangkut Sampah (Dump Truck Mini)/Car Garbage</td>
                        <td class="tg-cly1"><input type="text"
                                class="form-control <?php $__errorArgs = ['amount3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount3"
                                name="amount3" value="<?php echo e(old('amount3', $data->amount3)); ?>">
                            <?php $__errorArgs = ['amount3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td class="tg-cly1"><input type="text"
                                class="form-control form-control2 <?php $__errorArgs = ['deaf3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="deaf3"
                                name="deaf3" value="<?php echo e(old('deaf3', $data->deaf3)); ?>">
                            <?php $__errorArgs = ['deaf3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Truk Pengangkut Sampah (Dump Truck)/Car Garbage</td>
                        <td>10</td>
                        <td>1 rusak berat/1 severely damaged</td>
                    </tr>
                    <tr>
                        <td>Mobil Pengangkut Sampah (Arm Roll)/</td>
                        <td>6</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Operasional (Pick Up)/Operational Car</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Operasional (Mobil Tangki)/</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Pemangkas/Sky Lift</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Ekskavator/Excavator</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Wheel Loader</td>
                        <td>1</td>
                        <td>rusak berat/severely damaged</td>
                    </tr>
                    <tr>
                        <td>Buldoser/Bulldozer</td>
                        <td>2</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Sepeda Motor Operasional/ Operational Motorcycle</td>
                        <td>16</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Kontainer Sampah/Garbage Container</td>
                        <td>26</td>
                        <td>2 rusak/ 2 damaged</td>
                    </tr>
                    <tr>
                        <td>Mesin Pembakar Sampah/Incenarator</td>
                        <td>1</td>
                        <td>rusak berat/severely damaged</td>
                    </tr>
                    <tr>
                        <td>Motor Sampah (3 Roda)/Garbage Motors (3 Wheels)</td>
                        <td>17</td>
                        <td>2 rusak berat/2 severely damaged</td>
                    </tr>
                    <tr>
                        <td>Tanah TPA/Landfill</td>
                        <td>1</td>
                        <td>Luas 4,536 Ha (sesuai Sertifikat milik Pemda Kab. Soppeng)/Area 4,536 Ha</td>
                    </tr>
                    <tr>
                        <td>TPS Permanen (Komunal)/Permanent Landfill</td>
                        <td>15</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Kayu (Komunal)/Wood Landfill</td>
                        <td>12</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Fiber/Plastik (Rumah Tangga)/Fiber Landfill</td>
                        <td>2000</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Pemilah/Landfill sorting</td>
                        <td>800</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Karung Gantung (Pemilah)/Hanging Sack Landfills</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mesin Pemotong Rumput/Mowing Machine</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                </tbody>
            </table>
         <?php $__env->endSlot(); ?>
    <?php else: ?>
         <?php $__env->slot('tabel2', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tabel</th>
                        <th rowspan="2">4.3.9</th>
                        <th>Banyaknya Sarana dan Prasarana Kebersihan Menurut Jenis di Kabupaten Soppeng, 2021</th>
                    </tr>
                    <tr>
                        <th>Table</th>
                        <th>Number of sanitation facilities and infrastructure by type in Soppeng Regency, 2021</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Jenis Sarana dan Prasarana/</td>
                        <td>Jumlah/</td>
                        <td>Keterangan/</td>
                    </tr>
                    <tr>
                        <td>Type of Infrastructure</td>
                        <td>Amount</td>
                        <td>Explanation</td>
                    </tr>
                    <tr>
                        <td>(1)</td>
                        <td>(2)</td>
                        <td>(3)</td>
                    </tr>
                    <tr>
                        <td>Mobil Operasional Pimpinan/ Chief Operational Car</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Pengangkut Sampah (Kijang Box)/Car Garbage</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Pengangkut Sampah (Dump Truck Mini)/Car Garbage</td>
                        <td>2</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Truk Pengangkut Sampah (Dump Truck)/Car Garbage</td>
                        <td>10</td>
                        <td>1 rusak berat/1 severely damaged</td>
                    </tr>
                    <tr>
                        <td>Mobil Pengangkut Sampah (Arm Roll)/</td>
                        <td>6</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Operasional (Pick Up)/Operational Car</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Operasional (Mobil Tangki)/</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mobil Pemangkas/Sky Lift</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Ekskavator/Excavator</td>
                        <td>1</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Wheel Loader</td>
                        <td>1</td>
                        <td>rusak berat/severely damaged</td>
                    </tr>
                    <tr>
                        <td>Buldoser/Bulldozer</td>
                        <td>2</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Sepeda Motor Operasional/ Operational Motorcycle</td>
                        <td>16</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Kontainer Sampah/Garbage Container</td>
                        <td>26</td>
                        <td>2 rusak/ 2 damaged</td>
                    </tr>
                    <tr>
                        <td>Mesin Pembakar Sampah/Incenarator</td>
                        <td>1</td>
                        <td>rusak berat/severely damaged</td>
                    </tr>
                    <tr>
                        <td>Motor Sampah (3 Roda)/Garbage Motors (3 Wheels)</td>
                        <td>17</td>
                        <td>2 rusak berat/2 severely damaged</td>
                    </tr>
                    <tr>
                        <td>Tanah TPA/Landfill</td>
                        <td>1</td>
                        <td>Luas 4,536 Ha (sesuai Sertifikat milik Pemda Kab. Soppeng)/Area 4,536 Ha</td>
                    </tr>
                    <tr>
                        <td>TPS Permanen (Komunal)/Permanent Landfill</td>
                        <td>15</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Kayu (Komunal)/Wood Landfill</td>
                        <td>12</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Fiber/Plastik (Rumah Tangga)/Fiber Landfill</td>
                        <td>2000</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Pemilah/Landfill sorting</td>
                        <td>800</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>TPS Karung Gantung (Pemilah)/Hanging Sack Landfills</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <tr>
                        <td>Mesin Pemotong Rumput/Mowing Machine</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                </tbody>
            </table>
         <?php $__env->endSlot(); ?>
    <?php endif; ?>
     <?php $__env->slot('script', null, []); ?> 
        <?php echo $__env->make('tabel.skpd.023_DPMDes.script1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51)): ?>
<?php $component = $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51; ?>
<?php unset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/004_DLH/004001.blade.php ENDPATH**/ ?>