<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-c3ow" rowspan="2">Bulan</th>
                    <th class="tg-pb0m" colspan="2"><span style="font-weight:normal">Produksi</span></th>
                </tr>
                <tr>
                    
                    <th class="tg-jkyp"><span style="font-weight:normal">2022</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Januari</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p1" name="p1" value="<?php echo e(old('p1', $data->p1)); ?>">
                        <?php $__errorArgs = ['p1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Februari</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p2" name="p2" value="<?php echo e(old('p2', $data->p2)); ?>">
                        <?php $__errorArgs = ['p2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Maret</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p3" name="p3" value="<?php echo e(old('p3', $data->p3)); ?>">
                        <?php $__errorArgs = ['p3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">April</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p4" name="p4" value="<?php echo e(old('p4', $data->p4)); ?>">
                        <?php $__errorArgs = ['p4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Mei</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p5" name="p5" value="<?php echo e(old('p5', $data->p5)); ?>">
                        <?php $__errorArgs = ['p5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Juni</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p6" name="p6" value="<?php echo e(old('p6', $data->p6)); ?>">
                        <?php $__errorArgs = ['p6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Juli</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p7" name="p7" value="<?php echo e(old('p7', $data->p7)); ?>">
                        <?php $__errorArgs = ['p7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Agustus</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p8" name="p8" value="<?php echo e(old('p8', $data->p8)); ?>">
                        <?php $__errorArgs = ['p8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">September</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p9" name="p9" value="<?php echo e(old('p9', $data->p9)); ?>">
                        <?php $__errorArgs = ['p9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Oktober</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['p10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="p10" name="p10" value="<?php echo e(old('p10', $data->p10)); ?>">
                        <?php $__errorArgs = ['p10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">November</span></td>
                    
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['p11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="p11" name="p11"
                            value="<?php echo e(old('p11', $data->p11)); ?>">
                        <?php $__errorArgs = ['p11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Desember</span></td>
                    
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['p12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="p12" name="p12"
                            value="<?php echo e(old('p12', $data->p12)); ?>">
                        <?php $__errorArgs = ['p12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-za14"><span style="font-weight:normal">Jumlah</span></td>
                    
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="pt" name="pt" value="<?php echo e(old('pt', $data->pt)); ?>">
                        <?php $__errorArgs = ['pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-c3ow" rowspan="2">Bulan</th>
                <th class="tg-pb0m" colspan="2"><span style="font-weight:normal">Produksi</span></th>
            </tr>
            <tr>
                <th class="tg-jkyp"><span style="font-weight:normal">2021</span></th>
                <th class="tg-jkyp"><span style="font-weight:normal">2022</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Januari</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Februari</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Maret</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">April</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Mei</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Juni</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Juli</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Agustus</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">September</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Oktober</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">November</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Desember</span></td>
                <td class="tg-za14"></td>
                <td class="tg-za14"></td>
            </tr>
            <tr>
                <td class="tg-za14"><span style="font-weight:normal">Jumlah</span></td>
                <td class="tg-jkyp"><span style="font-weight:normal">0</span></td>
                <td class="tg-jkyp"><span style="font-weight:normal">0</span></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    <script>
        function sumHs() {
            var h1 = parseFloat(document.getElementById('h1').value) || 0;
            var h2 = parseFloat(document.getElementById('h2').value) || 0;
            var h3 = parseFloat(document.getElementById('h3').value) || 0;
            var h4 = parseFloat(document.getElementById('h4').value) || 0;
            var h5 = parseFloat(document.getElementById('h5').value) || 0;
            var h6 = parseFloat(document.getElementById('h6').value) || 0;
            var h7 = parseFloat(document.getElementById('h7').value) || 0;
            var h8 = parseFloat(document.getElementById('h8').value) || 0;
            var h9 = parseFloat(document.getElementById('h9').value) || 0;
            var h10 = parseFloat(document.getElementById('h10').value) || 0;
            var h11 = parseFloat(document.getElementById('h11').value) || 0;
            var h12 = parseFloat(document.getElementById('h12').value) || 0;
            var hSum = (h1) + (h2) + (h3) + (h4) + (
                h5) + (h6) + (h7) + (h8) + (h9) + (
                h10) + (
                h11) + (h12);

            document.getElementById('ht').value = hSum;
        }

        document.getElementById('h1').addEventListener('focusout', sumHs);
        document.getElementById('h2').addEventListener('focusout', sumHs);
        document.getElementById('h3').addEventListener('focusout', sumHs);
        document.getElementById('h4').addEventListener('focusout', sumHs);
        document.getElementById('h5').addEventListener('focusout', sumHs);
        document.getElementById('h6').addEventListener('focusout', sumHs);
        document.getElementById('h7').addEventListener('focusout', sumHs);
        document.getElementById('h8').addEventListener('focusout', sumHs);
        document.getElementById('h9').addEventListener('focusout', sumHs);
        document.getElementById('h10').addEventListener('focusout', sumHs);
        document.getElementById('h11').addEventListener('focusout', sumHs);
        document.getElementById('h12').addEventListener('focusout', sumHs);
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/006_Kehutanan/006002.blade.php ENDPATH**/ ?>