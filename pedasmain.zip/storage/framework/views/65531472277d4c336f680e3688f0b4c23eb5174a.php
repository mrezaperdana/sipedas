
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
    ini profil admin

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admins.layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pedas\resources\views/dashboard/admins/profile.blade.php ENDPATH**/ ?>