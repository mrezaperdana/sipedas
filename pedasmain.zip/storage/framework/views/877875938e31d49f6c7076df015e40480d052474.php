<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Tabel</th>
                    <th rowspan="2">2.2.5</th>
                    <th colspan="5">
                        <?php echo e($judultabel); ?>, <?php echo e($data->tahun); ?>

                        (lanjutan)
                    </th>

                </tr>
                <tr>
                    <th>Table</th>
                    <th colspan="5">
                        <?php echo e($judultabelen); ?>, <?php echo e($data->tahun); ?>

                        (continued)
                    </th>

                </tr>
            </thead>
            <tbody>

                <tr>
                    <td rowspan="4">
                        Kecamatan/Subdistrict</td>
                    <td colspan="6">Organisasi Masyarakat/Community Organization</td>

                </tr>

                <tr>
                    <td>Forum/Forum</td>

                    <td>Badan/Agency</td>

                    <td>Komunitas/Community</td>

                    <td>Profesi/Profession</td>

                    <td>Lainnya/ </td>

                    <td>Total</td>

                </tr>

                <tr>

                    <td>2022</td>

                    <td>2022</td>

                    <td>2022</td>

                    <td>2022</td>

                    <td>2022</td>

                    <td>2022</td>
                </tr>
                <tr>
                    <td colspan="2">(1)</td>
                    <td>(3)</td>
                    <td>(4)</td>
                    <td>(5)</td>
                    <td>(6)</td>

                </tr>
                <tr>
                    <td>010. Marioriwawo</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['forum1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="forum1" name="forum1" value="<?php echo e(old('forum1', $data->forum1)); ?>">
                        <?php $__errorArgs = ['forum1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['badan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="badan1" name="badan1" value="<?php echo e(old('badan1', $data->badan1)); ?>">
                        <?php $__errorArgs = ['badan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas1"
                            name="komunitas1" value="<?php echo e(old('komunitas1', $data->komunitas1)); ?>">
                        <?php $__errorArgs = ['komunitas1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi1" name="profesi1"
                            value="<?php echo e(old('profesi1', $data->profesi1)); ?>">
                        <?php $__errorArgs = ['profesi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya1" name="lainnya1"
                            value="<?php echo e(old('lainnya1', $data->lainnya1)); ?>">
                        <?php $__errorArgs = ['lainnya1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['total1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="total1" name="total1" value="<?php echo e(old('total1', $data->total1)); ?>">
                        <?php $__errorArgs = ['total1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>020. Lalabata</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['forum2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="forum2" name="forum2" value="<?php echo e(old('forum2', $data->forum2)); ?>">
                        <?php $__errorArgs = ['forum2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['badan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="badan2" name="badan2" value="<?php echo e(old('badan2', $data->badan2)); ?>">
                        <?php $__errorArgs = ['badan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas2"
                            name="komunitas2" value="<?php echo e(old('komunitas2', $data->komunitas2)); ?>">
                        <?php $__errorArgs = ['komunitas2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi2" name="profesi2"
                            value="<?php echo e(old('profesi2', $data->profesi2)); ?>">
                        <?php $__errorArgs = ['profesi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya2" name="lainnya2"
                            value="<?php echo e(old('lainnya2', $data->lainnya2)); ?>">
                        <?php $__errorArgs = ['lainnya2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['total2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total2" name="total2"
                            value="<?php echo e(old('total2', $data->total2)); ?>">
                        <?php $__errorArgs = ['total2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>030. Liliriaja</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['forum3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="forum3" name="forum3"
                            value="<?php echo e(old('forum3', $data->forum3)); ?>">
                        <?php $__errorArgs = ['forum3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['badan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="badan3" name="badan3"
                            value="<?php echo e(old('badan3', $data->badan3)); ?>">
                        <?php $__errorArgs = ['badan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas3"
                            name="komunitas3" value="<?php echo e(old('komunitas3', $data->komunitas3)); ?>">
                        <?php $__errorArgs = ['komunitas3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi3"
                            name="profesi3" value="<?php echo e(old('profesi3', $data->profesi3)); ?>">
                        <?php $__errorArgs = ['profesi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya3"
                            name="lainnya3" value="<?php echo e(old('lainnya3', $data->lainnya3)); ?>">
                        <?php $__errorArgs = ['lainnya3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['total3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total3" name="total3"
                            value="<?php echo e(old('total3', $data->total3)); ?>">
                        <?php $__errorArgs = ['total3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>031. Ganra</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['forum4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="forum4" name="forum4"
                            value="<?php echo e(old('forum4', $data->forum4)); ?>">
                        <?php $__errorArgs = ['forum4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['badan4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="badan4" name="badan4"
                            value="<?php echo e(old('badan4', $data->badan4)); ?>">
                        <?php $__errorArgs = ['badan4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas4"
                            name="komunitas4" value="<?php echo e(old('komunitas4', $data->komunitas4)); ?>">
                        <?php $__errorArgs = ['komunitas4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi4"
                            name="profesi4" value="<?php echo e(old('profesi4', $data->profesi4)); ?>">
                        <?php $__errorArgs = ['profesi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya4"
                            name="lainnya4" value="<?php echo e(old('lainnya4', $data->lainnya4)); ?>">
                        <?php $__errorArgs = ['lainnya4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['total4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total4" name="total4"
                            value="<?php echo e(old('total4', $data->total4)); ?>">
                        <?php $__errorArgs = ['total4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>032. Citta</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['forum5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="forum5" name="forum5"
                            value="<?php echo e(old('forum5', $data->forum5)); ?>">
                        <?php $__errorArgs = ['forum5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['badan5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="badan5" name="badan5"
                            value="<?php echo e(old('badan5', $data->badan5)); ?>">
                        <?php $__errorArgs = ['badan5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas5"
                            name="komunitas5" value="<?php echo e(old('komunitas5', $data->komunitas5)); ?>">
                        <?php $__errorArgs = ['komunitas5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi5"
                            name="profesi5" value="<?php echo e(old('profesi5', $data->profesi5)); ?>">
                        <?php $__errorArgs = ['profesi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya5"
                            name="lainnya5" value="<?php echo e(old('lainnya5', $data->lainnya5)); ?>">
                        <?php $__errorArgs = ['lainnya5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['total5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total5" name="total5"
                            value="<?php echo e(old('total5', $data->total5)); ?>">
                        <?php $__errorArgs = ['total5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>040. Lilirilau</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['forum6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="forum6" name="forum6"
                            value="<?php echo e(old('forum6', $data->forum6)); ?>">
                        <?php $__errorArgs = ['forum6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['badan6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="badan6" name="badan6"
                            value="<?php echo e(old('badan6', $data->badan6)); ?>">
                        <?php $__errorArgs = ['badan6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas6"
                            name="komunitas6" value="<?php echo e(old('komunitas6', $data->komunitas6)); ?>">
                        <?php $__errorArgs = ['komunitas6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi6"
                            name="profesi6" value="<?php echo e(old('profesi6', $data->profesi6)); ?>">
                        <?php $__errorArgs = ['profesi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya6"
                            name="lainnya6" value="<?php echo e(old('lainnya6', $data->lainnya6)); ?>">
                        <?php $__errorArgs = ['lainnya6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['total6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total6" name="total6"
                            value="<?php echo e(old('total6', $data->total6)); ?>">
                        <?php $__errorArgs = ['total6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>050. Donri-Donri</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['forum7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="forum7" name="forum7"
                            value="<?php echo e(old('forum7', $data->forum7)); ?>">
                        <?php $__errorArgs = ['forum7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['badan7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="badan7" name="badan7"
                            value="<?php echo e(old('badan7', $data->badan7)); ?>">
                        <?php $__errorArgs = ['badan7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas7"
                            name="komunitas7" value="<?php echo e(old('komunitas7', $data->komunitas7)); ?>">
                        <?php $__errorArgs = ['komunitas7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi7"
                            name="profesi7" value="<?php echo e(old('profesi7', $data->profesi7)); ?>">
                        <?php $__errorArgs = ['profesi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya7"
                            name="lainnya7" value="<?php echo e(old('lainnya7', $data->lainnya7)); ?>">
                        <?php $__errorArgs = ['lainnya7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['total7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total7" name="total7"
                            value="<?php echo e(old('total7', $data->total7)); ?>">
                        <?php $__errorArgs = ['total7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>060. Marioriawa</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['forum8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="forum8" name="forum8"
                            value="<?php echo e(old('forum8', $data->forum8)); ?>">
                        <?php $__errorArgs = ['forum8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['badan8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="badan8" name="badan8"
                            value="<?php echo e(old('badan8', $data->badan8)); ?>">
                        <?php $__errorArgs = ['badan8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitas8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitas8"
                            name="komunitas8" value="<?php echo e(old('komunitas8', $data->komunitas8)); ?>">
                        <?php $__errorArgs = ['komunitas8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesi8"
                            name="profesi8" value="<?php echo e(old('profesi8', $data->profesi8)); ?>">
                        <?php $__errorArgs = ['profesi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnya8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnya8"
                            name="lainnya8" value="<?php echo e(old('lainnya8', $data->lainnya8)); ?>">
                        <?php $__errorArgs = ['lainnya8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['total8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="total8" name="total8"
                            value="<?php echo e(old('total8', $data->total8)); ?>">
                        <?php $__errorArgs = ['total8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>Jumlah/Total</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['forumt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="forumt" name="forumt"
                            value="<?php echo e(old('forumt', $data->forumt)); ?>">
                        <?php $__errorArgs = ['forumt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['badant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="badant" name="badant"
                            value="<?php echo e(old('badant', $data->badant)); ?>">
                        <?php $__errorArgs = ['badant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['komunitast'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="komunitast"
                            name="komunitast" value="<?php echo e(old('komunitast', $data->komunitast)); ?>">
                        <?php $__errorArgs = ['komunitast'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['profesit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="profesit"
                            name="profesit" value="<?php echo e(old('profesit', $data->profesit)); ?>">
                        <?php $__errorArgs = ['profesit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lainnyat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lainnyat"
                            name="lainnyat" value="<?php echo e(old('lainnyat', $data->lainnyat)); ?>">
                        <?php $__errorArgs = ['lainnyat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['totalt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="totalt" name="totalt"
                            value="<?php echo e(old('totalt', $data->totalt)); ?>">
                        <?php $__errorArgs = ['totalt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tabel</th>
                <th rowspan="2">2.2.5</th>
                <th>Jumlah Organisasi Masyarakat menurut Kecamatan di Kabupaten Soppeng, 2017-2022
                    (lanjutan)</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <th>Table</th>
                <th>Number of Community Organizations by Subdistrict in Soppeng Regency, 2017-2022
                    (continued)</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>

            </tr>
            <tr>

            </tr>
            <tr>
                <td rowspan="5">Kecamatan/</td>
                <td colspan="39">Organisasi Masyarakat/</td>

            </tr>
            <tr>
                <td colspan="39">Community Organization</td>

            </tr>
            <tr>
                <td>Forum/</td>

                <td>Badan/</td>

                <td>Komunitas/</td>

                <td>Profesi/</td>

                <td>Lainnya/</td>

                <td>Total</td>

            </tr>
            <tr>
                <td>Forum</td>

                <td>Agency</td>

                <td>Community</td>

                <td>Profession</td>

                <td> </td>

            </tr>
            <tr>
                <td>2017</td>
                <td>2018</td>
                <td>2019</td>
                <td>2020</td>
                <td>2021</td>
                <td>2022</td>

                <td>2017</td>
                <td>2018</td>
                <td>2019</td>
                <td>2020</td>
                <td>2021</td>
                <td>2022</td>
                <td>2017</td>

                <td>2018</td>
                <td>2019</td>
                <td>2020</td>
                <td>2021</td>
                <td>2022</td>
                <td>2017</td>

                <td>2018</td>
                <td>2019</td>
                <td>2020</td>
                <td>2021</td>
                <td>2022</td>
                <td>2017</td>

                <td>2018</td>
                <td>2019</td>
                <td>2020</td>
                <td>2021</td>
                <td>2022</td>
                <td>2017</td>
                <td>2018</td>
                <td>2019</td>
                <td>2020</td>
                <td>2021</td>
                <td>2022</td>
            </tr>
            <tr>
                <td colspan="2">(1)</td>
                <td>(3)</td>
                <td>(4)</td>
                <td>(5)</td>
                <td>(6)</td>

                <td>(7)</td>
                <td>(8)</td>
                <td>(9)</td>
                <td>(10)</td>
                <td>(11)</td>

                <td>(12)</td>

                <td>(13)</td>
                <td>(14)</td>
                <td>(15)</td>
                <td>(16)</td>

                <td>(17)</td>

                <td>(18)</td>
                <td>(19)</td>
                <td>(20)</td>
                <td>(21)</td>

                <td>(22)</td>

                <td>(23)</td>
                <td>(24)</td>
                <td>(25)</td>
                <td>(26)</td>

                <td>(27)</td>
                <td>(28)</td>
                <td>(29)</td>
                <td>(30)</td>
                <td>(31)</td>
                <td>(31)</td>
            </tr>
            <tr>
                <td>010. Marioriwawo</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td> 26 </td>
                <td> 6 </td>
                <td> 3 </td>
                <td> 10 </td>

                <td>-</td>

                <td>-</td>
                <td>-</td>
                <td> 1 </td>
                <td>-</td>

                <td>-</td>
                <td> 26 </td>
                <td> 6 </td>
                <td> 4 </td>
                <td> 10 </td>
                <td>-</td>
            </tr>
            <tr>
                <td>020. Lalabata</td>
                <td>-</td>
                <td>-</td>

                <td> 1 </td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td> 1 </td>

                <td> 23 </td>

                <td> 24 </td>

                <td> 1 </td>
                <td>-</td>

                <td> 38 </td>

                <td> 78 </td>
                <td> 8 </td>
                <td> 5 </td>
                <td> 1 </td>

                <td>-</td>

                <td>-</td>
                <td> 5 </td>
                <td>-</td>
                <td>-</td>

                <td> 61 </td>
                <td> 102 </td>
                <td> 13 </td>
                <td> 7 </td>
                <td> 2 </td>
                <td>-</td>
            </tr>
            <tr>
                <td>030. Liliriaja</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td> 22 </td>
                <td> 4 </td>
                <td>-</td>
                <td> 8 </td>

                <td>-</td>

                <td>-</td>
                <td> 3 </td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td> 22 </td>
                <td> 7 </td>
                <td>-</td>
                <td> 8 </td>
                <td>-</td>
            </tr>
            <tr>
                <td>031. Ganra</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td> 22 </td>
                <td> 1 </td>
                <td>-</td>
                <td> 1 </td>

                <td>-</td>

                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td> 22 </td>
                <td> 1 </td>
                <td>-</td>
                <td> 1 </td>
                <td>-</td>
            </tr>
            <tr>
                <td>032. Citta</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td> 1 </td>
                <td> 1 </td>
                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td> 1 </td>
                <td> 1 </td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>
            <tr>
                <td>040. Lilirilau</td>
                <td> 30 </td>
                <td> 30 </td>

                <td> 1 </td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td> 54 </td>
                <td> 10 </td>
                <td> 3 </td>
                <td> 1 </td>

                <td>-</td>

                <td>-</td>
                <td> 1 </td>
                <td>-</td>
                <td>-</td>

                <td> 30 </td>
                <td> 84 </td>
                <td> 11 </td>
                <td> 4 </td>
                <td> 1 </td>
                <td>-</td>
            </tr>
            <tr>
                <td>050. Donri-Donri</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td> 10 </td>
                <td> 8 </td>
                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>
                <td>-</td>
                <td> 1 </td>
                <td>-</td>

                <td>-</td>
                <td> 10 </td>
                <td> 8 </td>
                <td> 1 </td>
                <td>-</td>
                <td>-</td>
            </tr>
            <tr>
                <td>060. Marioriawa</td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td>-</td>

                <td>-</td>

                <td>-</td>

                <td> 1 </td>
                <td>-</td>

                <td>-</td>

                <td> 3 </td>
                <td> 1 </td>
                <td>-</td>
                <td> 5 </td>

                <td>-</td>

                <td>-</td>
                <td> 1 </td>
                <td>-</td>
                <td>-</td>

                <td>-</td>
                <td> 3 </td>
                <td> 2 </td>
                <td> 1 </td>
                <td> 5 </td>
                <td>-</td>
            </tr>
            <tr>
                <td>Jumlah/Total</td>
                <td> 30 </td>
                <td> 30 </td>
                <td>-</td>
                <td> 2 </td>
                <td>-</td>

                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td> 1 </td>

                <td> 23 </td>

                <td> 24 </td>
                <td>-</td>
                <td> 2 </td>
                <td>-</td>

                <td> 38 </td>

                <td> 216 </td>
                <td> 39 </td>
                <td> 11 </td>
                <td> 26 </td>

                <td>-</td>

                <td>-</td>
                <td> 10 </td>
                <td> 2 </td>
                <td>-</td>

                <td> 91 </td>
                <td> 270 </td>
                <td> 49 </td>
                <td> 17 </td>
                <td> 27 </td>

            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <script>
        function sumForums() {
            var forumElements = document.querySelectorAll('[id^="forum"]');
            var forumSum = 0;
            for (var i = 0; i < forumElements.length; i++) {
                if (forumElements[i].id !== "forumt") {
                    var forumValue = parseFloat(forumElements[i].value) || 0;
                    forumSum += forumValue;
                }
            }
            document.getElementById('forumt').value = forumSum;
        }

        var forumInputs = document.querySelectorAll('[id^="forum"]');
        for (var i = 0; i < forumInputs.length; i++) {
            forumInputs[i].addEventListener('focusout', sumForums);
        }
    </script>
    <script>
        function sumBadans() {
            var badanElements = document.querySelectorAll('[id^="badan"]');
            var badanSum = 0;
            for (var i = 0; i < badanElements.length; i++) {
                if (badanElements[i].id !== "badant") {
                    var badanValue = parseFloat(badanElements[i].value) || 0;
                    badanSum += badanValue;
                }
            }
            document.getElementById('badant').value = badanSum;
        }

        var badanInputs = document.querySelectorAll('[id^="badan"]');
        for (var i = 0; i < badanInputs.length; i++) {
            badanInputs[i].addEventListener('focusout', sumBadans);
        }
    </script>
    <script>
        function sumKomunitass() {
            var komunitasElements = document.querySelectorAll('[id^="komunitas"]');
            var komunitasSum = 0;
            for (var i = 0; i < komunitasElements.length; i++) {
                if (komunitasElements[i].id !== "komunitast") {
                    var komunitasValue = parseFloat(komunitasElements[i].value) || 0;
                    komunitasSum += komunitasValue;
                }
            }
            document.getElementById('komunitast').value = komunitasSum;
        }

        var komunitasInputs = document.querySelectorAll('[id^="komunitas"]');
        for (var i = 0; i < komunitasInputs.length; i++) {
            komunitasInputs[i].addEventListener('focusout', sumKomunitass);
        }
    </script>
    <script>
        function sumProfesis() {
            var profesiElements = document.querySelectorAll('[id^="profesi"]');
            var profesiSum = 0;
            for (var i = 0; i < profesiElements.length; i++) {
                if (profesiElements[i].id !== "profesit") {
                    var profesiValue = parseFloat(profesiElements[i].value) || 0;
                    profesiSum += profesiValue;
                }
            }
            document.getElementById('profesit').value = profesiSum;
        }

        var profesiInputs = document.querySelectorAll('[id^="profesi"]');
        for (var i = 0; i < profesiInputs.length; i++) {
            profesiInputs[i].addEventListener('focusout', sumProfesis);
        }
    </script>
    <script>
        function sumLainnyas() {
            var lainnyaElements = document.querySelectorAll('[id^="lainnya"]');
            var lainnyaSum = 0;
            for (var i = 0; i < lainnyaElements.length; i++) {
                if (lainnyaElements[i].id !== "lainnyat") {
                    var lainnyaValue = parseFloat(lainnyaElements[i].value) || 0;
                    lainnyaSum += lainnyaValue;
                }
            }
            document.getElementById('lainnyat').value = lainnyaSum;
        }

        var lainnyaInputs = document.querySelectorAll('[id^="lainnya"]');
        for (var i = 0; i < lainnyaInputs.length; i++) {
            lainnyaInputs[i].addEventListener('focusout', sumLainnyas);
        }
    </script>
    <script>
        function sumTotals() {
            var totalElements = document.querySelectorAll('[id^="total"]');
            var totalSum = 0;
            for (var i = 0; i < totalElements.length; i++) {
                if (totalElements[i].id !== "totalt") {
                    var totalValue = parseFloat(totalElements[i].value) || 0;
                    totalSum += totalValue;
                }
            }
            document.getElementById('totalt').value = totalSum;
        }

        var totalInputs = document.querySelectorAll('[id^="total"]');
        for (var i = 0; i < totalInputs.length; i++) {
            totalInputs[i].addEventListener('focusout', sumTotals);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/020_Kesbangpol/020003.blade.php ENDPATH**/ ?>