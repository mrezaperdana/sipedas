<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-amwm" rowspan="2">NO</th>
                    <th class="tg-amwm" rowspan="2">BULAN</th>
                    
                    <th class="tg-bobw" colspan="2"><span style="font-weight:bold">2022</span></th>
                </tr>
                <tr>
                    
                    <th class="tg-wa1i"><span style="font-weight:bold">PRODUKSI AIR BERSIH (M3) AIR YANG
                            DIDISTRIBUSIKAN</span></th>
                    <th class="tg-wa1i"><span style="font-weight:bold">HARGA</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-8d8j">1</td>
                    <td class="tg-7zrl">Januari</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi1"
                            name="produksi1" value="<?php echo e(old('produksi1', $data->produksi1)); ?>">
                        <?php $__errorArgs = ['produksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['harga1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="harga1" name="harga1" value="<?php echo e(old('harga1', $data->harga1)); ?>">
                        <?php $__errorArgs = ['harga1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                <tr>
                    <td class="tg-8d8j">2</td>
                    <td class="tg-7zrl">Februari</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi2"
                            name="produksi2" value="<?php echo e(old('produksi2', $data->produksi2)); ?>">
                        <?php $__errorArgs = ['produksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['harga2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="harga2" name="harga2" value="<?php echo e(old('harga2', $data->harga2)); ?>">
                        <?php $__errorArgs = ['harga2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">3</td>
                    <td class="tg-7zrl">Maret</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi3"
                            name="produksi3" value="<?php echo e(old('produksi3', $data->produksi3)); ?>">
                        <?php $__errorArgs = ['produksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['harga3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="harga3" name="harga3" value="<?php echo e(old('harga3', $data->harga3)); ?>">
                        <?php $__errorArgs = ['harga3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">4</td>
                    <td class="tg-7zrl">April</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi4"
                            name="produksi4" value="<?php echo e(old('produksi4', $data->produksi4)); ?>">
                        <?php $__errorArgs = ['produksi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['harga4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="harga4" name="harga4" value="<?php echo e(old('harga4', $data->harga4)); ?>">
                        <?php $__errorArgs = ['harga4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">5</td>
                    <td class="tg-7zrl">Mei</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi5"
                            name="produksi5" value="<?php echo e(old('produksi5', $data->produksi5)); ?>">
                        <?php $__errorArgs = ['produksi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['harga5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="harga5" name="harga5" value="<?php echo e(old('harga5', $data->harga5)); ?>">
                        <?php $__errorArgs = ['harga5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">6</td>
                    <td class="tg-7zrl">Juni</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi6"
                            name="produksi6" value="<?php echo e(old('produksi6', $data->produksi6)); ?>">
                        <?php $__errorArgs = ['produksi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['harga6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga6" name="harga6"
                            value="<?php echo e(old('harga6', $data->harga6)); ?>">
                        <?php $__errorArgs = ['harga6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">7</td>
                    <td class="tg-7zrl">Juli</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi7"
                            name="produksi7" value="<?php echo e(old('produksi7', $data->produksi7)); ?>">
                        <?php $__errorArgs = ['produksi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['harga7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga7" name="harga7"
                            value="<?php echo e(old('harga7', $data->harga7)); ?>">
                        <?php $__errorArgs = ['harga7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">8</td>
                    <td class="tg-7zrl">Agustus</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi8"
                            name="produksi8" value="<?php echo e(old('produksi8', $data->produksi8)); ?>">
                        <?php $__errorArgs = ['produksi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['harga8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga8" name="harga8"
                            value="<?php echo e(old('harga8', $data->harga8)); ?>">
                        <?php $__errorArgs = ['harga8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">9</td>
                    <td class="tg-7zrl">September</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi9"
                            name="produksi9" value="<?php echo e(old('produksi9', $data->produksi9)); ?>">
                        <?php $__errorArgs = ['produksi9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['harga9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga9" name="harga9"
                            value="<?php echo e(old('harga9', $data->harga9)); ?>">
                        <?php $__errorArgs = ['harga9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">10</td>
                    <td class="tg-7zrl">Oktober</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi10"
                            name="produksi10" value="<?php echo e(old('produksi10', $data->produksi10)); ?>">
                        <?php $__errorArgs = ['produksi10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['harga10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga10"
                            name="harga10" value="<?php echo e(old('harga10', $data->harga10)); ?>">
                        <?php $__errorArgs = ['harga10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">11</td>
                    <td class="tg-7zrl">November</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi11"
                            name="produksi11" value="<?php echo e(old('produksi11', $data->produksi11)); ?>">
                        <?php $__errorArgs = ['produksi11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['harga11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga11"
                            name="harga11" value="<?php echo e(old('harga11', $data->harga11)); ?>">
                        <?php $__errorArgs = ['harga11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">12</td>
                    <td class="tg-7zrl">Desember</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksi12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi12"
                            name="produksi12" value="<?php echo e(old('produksi12', $data->produksi12)); ?>">
                        <?php $__errorArgs = ['produksi12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['harga12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga12"
                            name="harga12" value="<?php echo e(old('harga12', $data->harga12)); ?>">
                        <?php $__errorArgs = ['harga12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-bobw" colspan="2"><span style="font-weight:bold">JUMLAH</span></td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['produksit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksit"
                            name="produksit" value="<?php echo e(old('produksit', $data->produksit)); ?>">
                        <?php $__errorArgs = ['produksit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['hargat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="hargat" name="hargat"
                            value="<?php echo e(old('hargat', $data->hargat)); ?>">
                        <?php $__errorArgs = ['hargat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>

    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-amwm" rowspan="2">NO</th>
                <th class="tg-amwm" rowspan="2">BULAN</th>
                <th class="tg-bobw" colspan="2"><span style="font-weight:bold">2021</span></th>
                <th class="tg-bobw" colspan="2"><span style="font-weight:bold">2022</span></th>
            </tr>
            <tr>
                <th class="tg-wa1i"><span style="font-weight:bold">PRODUKSI AIR BERSIH (M3) AIR YANG
                        DIDISTRIBUSIKAN</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">HARGA</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">PRODUKSI AIR BERSIH (M3) AIR YANG
                        DIDISTRIBUSIKAN</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">HARGA</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-8d8j">1</td>
                <td class="tg-7zrl">Januari</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">2</td>
                <td class="tg-7zrl">Februari</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">3</td>
                <td class="tg-7zrl">Maret</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">4</td>
                <td class="tg-7zrl">April</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">5</td>
                <td class="tg-7zrl">Mei</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">6</td>
                <td class="tg-7zrl">Juni</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">7</td>
                <td class="tg-7zrl">Juli</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">8</td>
                <td class="tg-7zrl">Agustus</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">9</td>
                <td class="tg-7zrl">September</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">10</td>
                <td class="tg-7zrl">Oktober</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">11</td>
                <td class="tg-7zrl">November</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">12</td>
                <td class="tg-7zrl">Desember</td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-xj7a"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-bobw" colspan="2"><span style="font-weight:bold">JUMLAH</span></td>
                <td class="tg-mukt"><span style="font-weight:normal;background-color:#FF0">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
                <td class="tg-mukt"><span style="font-weight:normal;background-color:#FF0">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    <script>
        function sumProduksis() {
            var produksi1 = document.getElementById('produksi1').value || 0;
            var produksi2 = document.getElementById('produksi2').value || 0;
            var produksi3 = document.getElementById('produksi3').value || 0;
            var produksi4 = document.getElementById('produksi4').value || 0;
            var produksi5 = document.getElementById('produksi5').value || 0;
            var produksi6 = document.getElementById('produksi6').value || 0;
            var produksi7 = document.getElementById('produksi7').value || 0;
            var produksi8 = document.getElementById('produksi8').value || 0;
            var produksi9 = document.getElementById('produksi9').value || 0;
            var produksi10 = document.getElementById('produksi10').value || 0;
            var produksi11 = document.getElementById('produksi11').value || 0;
            var produksi12 = document.getElementById('produksi12').value || 0;
            var produksiSum = parseInt(produksi1) + parseInt(produksi2) + parseInt(produksi3) + parseInt(produksi4) +
                parseInt(
                    produksi5) + parseInt(produksi6) + parseInt(produksi7) + parseInt(produksi8) + parseInt(produksi9) +
                parseInt(
                    produksi10) + parseInt(
                    produksi11) + parseInt(produksi12);

            document.getElementById('produksit').value = produksiSum;
        }

        document.getElementById('produksi1').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi2').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi3').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi4').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi5').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi6').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi7').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi8').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi9').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi10').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi11').addEventListener('focusout', sumProduksis);
        document.getElementById('produksi12').addEventListener('focusout', sumProduksis);
    </script>
    <script>
        function sumHargas() {
            var harga1 = document.getElementById('harga1').value || 0;
            var harga2 = document.getElementById('harga2').value || 0;
            var harga3 = document.getElementById('harga3').value || 0;
            var harga4 = document.getElementById('harga4').value || 0;
            var harga5 = document.getElementById('harga5').value || 0;
            var harga6 = document.getElementById('harga6').value || 0;
            var harga7 = document.getElementById('harga7').value || 0;
            var harga8 = document.getElementById('harga8').value || 0;
            var harga9 = document.getElementById('harga9').value || 0;
            var harga10 = document.getElementById('harga10').value || 0;
            var harga11 = document.getElementById('harga11').value || 0;
            var harga12 = document.getElementById('harga12').value || 0;
            var hargaSum = parseInt(harga1) + parseInt(harga2) + parseInt(harga3) + parseInt(harga4) + parseInt(
                harga5) + parseInt(harga6) + parseInt(harga7) + parseInt(harga8) + parseInt(harga9) + parseInt(
                harga10) + parseInt(
                harga11) + parseInt(harga12);

            document.getElementById('hargat').value = hargaSum;
        }

        document.getElementById('harga1').addEventListener('focusout', sumHargas);
        document.getElementById('harga2').addEventListener('focusout', sumHargas);
        document.getElementById('harga3').addEventListener('focusout', sumHargas);
        document.getElementById('harga4').addEventListener('focusout', sumHargas);
        document.getElementById('harga5').addEventListener('focusout', sumHargas);
        document.getElementById('harga6').addEventListener('focusout', sumHargas);
        document.getElementById('harga7').addEventListener('focusout', sumHargas);
        document.getElementById('harga8').addEventListener('focusout', sumHargas);
        document.getElementById('harga9').addEventListener('focusout', sumHargas);
        document.getElementById('harga10').addEventListener('focusout', sumHargas);
        document.getElementById('harga11').addEventListener('focusout', sumHargas);
        document.getElementById('harga12').addEventListener('focusout', sumHargas);
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/PDAM/009001.blade.php ENDPATH**/ ?>