
<?php $__env->startSection('title', 'Pengaturan'); ?>
<?php $__env->startSection('content'); ?>

    pengaturan admin

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admins.layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pedas\resources\views/dashboard/admins/settings.blade.php ENDPATH**/ ?>