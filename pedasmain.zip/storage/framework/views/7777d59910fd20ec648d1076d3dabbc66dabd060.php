<?php if (isset($component)) { $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51 = $component; } ?>
<?php $component = App\View\Components\TabelEntriView::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabel-entri-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TabelEntriView::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'judultabel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabel),'judultabelen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabelen)]); ?>
    <?php if(!empty($data)): ?>
         <?php $__env->slot('tabel1', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                        <th class="tg-amwm" rowspan="2">2.1</th>
                        <th class="tg-yla0"><span style="font-weight:bold"><?php echo e($judultabel); ?>, <?php echo e($data->tahun); ?></span>
                        </th>
                    </tr>
                    <tr>
                        <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                        <th class="tg-sn55"><span style="font-weight:bold;font-style:italic"><?php echo e($judultabelen); ?>,
                                <?php echo e($data->tahun); ?></span></th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td class="tg-nrix">Nama Instansi dan Kantor Pemerintah</td>
                        <td class="tg-nrix" colspan="2">Banyaknya Pegawai</td>
                    </tr>
                    <tr>
                        <td class="tg-lhti"><span style="font-style:italic">Name of Agency and Government Office</span>
                        </td>
                        <td class="tg-lhti" colspan="2"><span style="font-style:italic">Number of Employee</span>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-nrix">(1)</td>
                        <td class="tg-nrix" colspan="2">(2)</td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Kantor Camat /</span><span
                                style="font-style:italic;color:#000">SubdistrictVillage Office</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah1"
                                name="jumlah1" value="<?php echo e(old('jumlah1', $data->jumlah1)); ?>">
                            <?php $__errorArgs = ['jumlah1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Kantor
                                Desa/Kelurahan/</span><span style="font-style:italic;color:#000">Villages/Urban Villages
                                Office</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah2"
                                name="jumlah2" value="<?php echo e(old('jumlah2', $data->jumlah2)); ?>">
                            <?php $__errorArgs = ['jumlah2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">UPTD Dinas Pendidikan (Tidak
                                Termasuk
                                Guru)/</span><span style="font-style:italic;color:#000">Education Office (Exclude
                                teacher)</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah3"
                                name="jumlah3" value="<?php echo e(old('jumlah3', $data->jumlah3)); ?>">
                            <?php $__errorArgs = ['jumlah3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Puskesmas/</span><span
                                style="font-style:italic;color:#000">Public Health Center</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah4"
                                name="jumlah4" value="<?php echo e(old('jumlah4', $data->jumlah4)); ?>">
                            <?php $__errorArgs = ['jumlah4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-cly1">Penyuluh DP3APPKB</td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah5"
                                name="jumlah5" value="<?php echo e(old('jumlah5', $data->jumlah5)); ?>">
                            <?php $__errorArgs = ['jumlah5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Kantor Urusan Agama
                                (KUA)/</span><span style="font-style:italic;color:#000">Religious Affairs Office</span>
                        </td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah6"
                                name="jumlah6" value="<?php echo e(old('jumlah6', $data->jumlah6)); ?>">
                            <?php $__errorArgs = ['jumlah6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-cly1">Penyuluh Pertanian (Termasuk PPL)/Agriculture Conselor Agency (Include
                            Conselor)
                        </td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah7"
                                name="jumlah7" value="<?php echo e(old('jumlah7', $data->jumlah7)); ?>">
                            <?php $__errorArgs = ['jumlah7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">UPTD Dinas Pertanian
                                /</span><span style="font-style:italic;color:#000">Agriculture Office</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah8"
                                name="jumlah8" value="<?php echo e(old('jumlah8', $data->jumlah8)); ?>">
                            <?php $__errorArgs = ['jumlah8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Koramil/</span><span
                                style="font-style:italic;color:#000">Rayon Military Command</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah9"
                                name="jumlah9" value="<?php echo e(old('jumlah9', $data->jumlah9)); ?>">
                            <?php $__errorArgs = ['jumlah9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Polsek/</span><span
                                style="font-style:italic;color:#000">Police Sector</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah10"
                                name="jumlah10" value="<?php echo e(old('jumlah10', $data->jumlah10)); ?>">
                            <?php $__errorArgs = ['jumlah10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">PT. PLN/</span><span
                                style="font-style:italic;color:#000">State Electricity Company</span><span
                                style="font-style:normal;color:#000"> </span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah11"
                                name="jumlah11" value="<?php echo e(old('jumlah11', $data->jumlah11)); ?>">
                            <?php $__errorArgs = ['jumlah11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">PT. Pos Indonesia/</span><span
                                style="font-style:italic;color:#000">Indonesian Post Station</span></td>
                        <td class="tg-cly1" colspan="2"><input type="text"
                                class="form-control <?php $__errorArgs = ['jumlah12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah12"
                                name="jumlah12" value="<?php echo e(old('jumlah12', $data->jumlah12)); ?>">
                            <?php $__errorArgs = ['jumlah12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
         <?php $__env->endSlot(); ?>
    <?php else: ?>
         <?php $__env->slot('tabel2', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                        <th class="tg-amwm" rowspan="2">2.1</th>
                        <th class="tg-yla0"><span style="font-weight:bold">Banyaknya Pegawai Instansi dan Kantor
                                Pemerintah di
                                Kecamatan Marioriawa, 2021</span></th>
                    </tr>
                    <tr>
                        <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                        <th class="tg-sn55"><span style="font-weight:bold;font-style:italic">Number of Employee of
                                Agency and
                                Government Office&nbsp;&nbsp;in Marioriawa Subdistrict, 2021</span></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="tg-cly1"></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-7zrl"></td>
                    </tr>
                    <tr>
                        <td class="tg-nrix">Nama Instansi dan Kantor Pemerintah</td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-nrix">Banyaknya Pegawai</td>
                    </tr>
                    <tr>
                        <td class="tg-lhti"><span style="font-style:italic">Name of Agency and Government
                                Office</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-lhti"><span style="font-style:italic">Number of Employee</span></td>
                    </tr>
                    <tr>
                        <td class="tg-nrix">(1)</td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-nrix">(2)</td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Kantor Camat /</span><span
                                style="font-style:italic;color:#000">SubdistrictVillage Office</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">34</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Kantor
                                Desa/Kelurahan/</span><span style="font-style:italic;color:#000">Villages/Urban
                                Villages Office</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">114</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">UPTD Dinas Pendidikan (Tidak
                                Termasuk
                                Guru)/</span><span style="font-style:italic;color:#000">Education Office (Exclude
                                teacher)</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">1</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Puskesmas/</span><span
                                style="font-style:italic;color:#000">Public Health Center</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">139</span></td>
                    </tr>
                    <tr>
                        <td class="tg-cly1">Penyuluh DP3APPKB</td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">2</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Kantor Urusan Agama
                                (KUA)/</span><span style="font-style:italic;color:#000">Religious Affairs Office</span>
                        </td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">3</span></td>
                    </tr>
                    <tr>
                        <td class="tg-cly1">Penyuluh Pertanian (Termasuk PPL)/Agriculture Conselor Agency (Include
                            Conselor)
                        </td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">1</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">UPTD Dinas Pertanian
                                /</span><span style="font-style:italic;color:#000">Agriculture Office</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">11</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Koramil/</span><span
                                style="font-style:italic;color:#000">Rayon Military Command</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">8</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">Polsek/</span><span
                                style="font-style:italic;color:#000">Police Sector</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">15</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">PT. PLN/</span><span
                                style="font-style:italic;color:#000">State Electricity Company</span><span
                                style="font-style:normal;color:#000"> </span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">5</span></td>
                    </tr>
                    <tr>
                        <td class="tg-0lax"><span style="font-style:normal;color:#000">PT. Pos Indonesia/</span><span
                                style="font-style:italic;color:#000">Indonesian Post Station</span></td>
                        <td class="tg-7zrl"></td>
                        <td class="tg-iygw"><span style="background-color:#D7F3CB">3</span></td>
                    </tr>
                </tbody>
            </table>
         <?php $__env->endSlot(); ?>
    <?php endif; ?>
     <?php $__env->slot('script', null, []); ?> 

     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51)): ?>
<?php $component = $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51; ?>
<?php unset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/046_Marioriawa/046003.blade.php ENDPATH**/ ?>