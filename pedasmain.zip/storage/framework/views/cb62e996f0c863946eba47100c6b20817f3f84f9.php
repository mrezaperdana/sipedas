
<?php $__env->startSection('title', 'Pengaturan'); ?>
<?php $__env->startSection('content'); ?>

    pengaturan user

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.users.layouts.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pedas\resources\views/dashboard/users/settings.blade.php ENDPATH**/ ?>