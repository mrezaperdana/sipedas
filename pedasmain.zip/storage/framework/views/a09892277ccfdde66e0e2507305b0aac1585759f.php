<p>Kolom Catatan:</p>
<div class="input-group flex-nowrap">
    <td class="tg-cly1"><input type="text" class="form-control-lg form-control <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            id="catatan" name="catatan" value="<?php echo e(old('catatan', $data->catatan)); ?>">
        <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </td>
</div>
<script>
    window.addEventListener('load', () => {
        const inputs = document.querySelectorAll('.form-control:not(#catatan):not(.form-control2)');

        inputs.forEach((input) => {
            input.addEventListener('input', (event) => {
                const value = event.target.value;

                // Check if the value is a valid number or the string "..."
                const isValid = /^-?\d*\.?\d*$/.test(value);

                if (!isValid) {
                    event.target.setCustomValidity(
                        'Hanya boleh diisi angka, jika desimal gunakan titik (misal 13.2) atau isikan tanda minus (-) jika data tidak tersedia'
                    );
                } else {
                    event.target.setCustomValidity('');
                }

            });
        });
    });
</script>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/catatan.blade.php ENDPATH**/ ?>