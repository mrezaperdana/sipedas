<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-baqh" rowspan="2">NO</th>
                    <th class="tg-baqh" rowspan="2">KANTOR CABANG/UNIT PEGADAIAN</th>
                    
                    <th class="tg-nrix" colspan="2">2022</th>
                </tr>
                <tr>
                    
                    <th class="tg-nrix">NILAI OMZET (Rp)</th>
                    <th class="tg-nrix">NILAI LABA (Rp)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-nrix">1</td>
                    <td class="tg-nrix">Cabang Watansoppeng</td>
                    
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['omzet1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="omzet1" name="omzet1" value="<?php echo e(old('omzet1', $data->omzet1)); ?>">
                        <?php $__errorArgs = ['omzet1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['laba1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="laba1" name="laba1" value="<?php echo e(old('laba1', $data->laba1)); ?>">
                        <?php $__errorArgs = ['laba1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">2</td>
                    <td class="tg-nrix">UPC Takalala</td>
                    
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['omzet2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="omzet2" name="omzet2" value="<?php echo e(old('omzet2', $data->omzet2)); ?>">
                        <?php $__errorArgs = ['omzet2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['laba2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="laba2" name="laba2" value="<?php echo e(old('laba2', $data->laba2)); ?>">
                        <?php $__errorArgs = ['laba2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">3</td>
                    <td class="tg-nrix">UPC Batu-Batu</td>
                    
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['omzet3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="omzet3" name="omzet3" value="<?php echo e(old('omzet3', $data->omzet3)); ?>">
                        <?php $__errorArgs = ['omzet3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['laba3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="laba3" name="laba3" value="<?php echo e(old('laba3', $data->laba3)); ?>">
                        <?php $__errorArgs = ['laba3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">4</td>
                    <td class="tg-nrix">UPC Malaka Raya</td>
                    
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['omzet4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="omzet4" name="omzet4" value="<?php echo e(old('omzet4', $data->omzet4)); ?>">
                        <?php $__errorArgs = ['omzet4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['laba4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="laba4" name="laba4" value="<?php echo e(old('laba4', $data->laba4)); ?>">
                        <?php $__errorArgs = ['laba4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">5</td>
                    <td class="tg-nrix">UPC Tajuncu</td>
                    
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['omzet5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="omzet5" name="omzet5" value="<?php echo e(old('omzet5', $data->omzet5)); ?>">
                        <?php $__errorArgs = ['omzet5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['laba5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="laba5" name="laba5" value="<?php echo e(old('laba5', $data->laba5)); ?>">
                        <?php $__errorArgs = ['laba5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">6</td>
                    <td class="tg-nrix">UPC Panincong</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['omzet6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet6" name="omzet6"
                            value="<?php echo e(old('omzet6', $data->omzet6)); ?>">
                        <?php $__errorArgs = ['omzet6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['laba6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="laba6" name="laba6"
                            value="<?php echo e(old('laba6', $data->laba6)); ?>">
                        <?php $__errorArgs = ['laba6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">7</td>
                    <td class="tg-nrix">UPC Lappariaja</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['omzet7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet7" name="omzet7"
                            value="<?php echo e(old('omzet7', $data->omzet7)); ?>">
                        <?php $__errorArgs = ['omzet7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['laba7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="laba7" name="laba7"
                            value="<?php echo e(old('laba7', $data->laba7)); ?>">
                        <?php $__errorArgs = ['laba7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">8</td>
                    <td class="tg-nrix">UPC Pasar Lolloe</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['omzet8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzet8" name="omzet8"
                            value="<?php echo e(old('omzet8', $data->omzet8)); ?>">
                        <?php $__errorArgs = ['omzet8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['laba8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="laba8" name="laba8"
                            value="<?php echo e(old('laba8', $data->laba8)); ?>">
                        <?php $__errorArgs = ['laba8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix" colspan="2">JUMLAH</td>
                    
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['omzett'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="omzett" name="omzett"
                            value="<?php echo e(old('omzett', $data->omzett)); ?>">
                        <?php $__errorArgs = ['omzett'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number"
                            class="form-control <?php $__errorArgs = ['labat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="labat" name="labat"
                            value="<?php echo e(old('labat', $data->labat)); ?>">
                        <?php $__errorArgs = ['labat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>

    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-baqh" rowspan="2">NO</th>
                <th class="tg-baqh" rowspan="2">KANTOR CABANG/UNIT PEGADAIAN</th>
                <th class="tg-nrix" colspan="2">2021</th>
                <th class="tg-nrix" colspan="2">2022</th>
            </tr>
            <tr>
                <th class="tg-nrix">NILAI OMZET (Rp)</th>
                <th class="tg-nrix">NILAI LABA (Rp)</th>
                <th class="tg-nrix">NILAI OMZET (Rp)</th>
                <th class="tg-nrix">NILAI LABA (Rp)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-nrix">1</td>
                <td class="tg-nrix">Cabang Watansoppeng</td>
                <td class="tg-nrix">58,367,131,405.00</td>
                <td class="tg-nrix">2,154,691,332.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">2</td>
                <td class="tg-nrix">UPC Takalala</td>
                <td class="tg-2b7s"><span style="font-weight:normal">38,543,743,050.00</span></td>
                <td class="tg-nrix">2,379,832,997.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">3</td>
                <td class="tg-nrix">UPC Batu-Batu</td>
                <td class="tg-nrix">44,114,556,080.00</td>
                <td class="tg-nrix">2,432,973,670.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">4</td>
                <td class="tg-nrix">UPC Malaka Raya</td>
                <td class="tg-nrix">27,850,743,350.00</td>
                <td class="tg-nrix">1,613,318,602.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">5</td>
                <td class="tg-nrix">UPC Tajuncu</td>
                <td class="tg-nrix">40,255,248,200.00</td>
                <td class="tg-nrix">2,197,524,486.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">6</td>
                <td class="tg-nrix">UPC Panincong</td>
                <td class="tg-nrix">18,304,245,700.00</td>
                <td class="tg-nrix">858,485,341.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">7</td>
                <td class="tg-nrix">UPC Lappariaja</td>
                <td class="tg-nrix">20,629,033,130.00</td>
                <td class="tg-nrix">804,478,872.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">8</td>
                <td class="tg-nrix">UPC Pasar Lolloe</td>
                <td class="tg-nrix">17,349,361,950.00</td>
                <td class="tg-nrix">984,919,912.00</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix" colspan="2">JUMLAH</td>
                <td class="tg-nrix">265,414,062,865.00</td>
                <td class="tg-nrix">13,426,225,212.00</td>
                <td class="tg-nrix">0.00</td>
                <td class="tg-nrix">0.00</td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>

<?php $__env->startSection('script'); ?>
    <script>
        function sumLabas() {
            var laba1 = document.getElementById('laba1').value || 0;
            var laba2 = document.getElementById('laba2').value || 0;
            var laba3 = document.getElementById('laba3').value || 0;
            var laba4 = document.getElementById('laba4').value || 0;
            var laba5 = document.getElementById('laba5').value || 0;
            var laba6 = document.getElementById('laba6').value || 0;
            var laba7 = document.getElementById('laba7').value || 0;
            var laba8 = document.getElementById('laba8').value || 0;

            var labaSum = parseInt(laba1) + parseInt(laba2) + parseInt(laba3) + parseInt(laba4) + parseInt(
                laba5) + parseInt(laba6) + parseInt(laba7) + parseInt(laba8);

            document.getElementById('labat').value = labaSum;
        }

        document.getElementById('laba1').addEventListener('focusout', sumLabas);
        document.getElementById('laba2').addEventListener('focusout', sumLabas);
        document.getElementById('laba3').addEventListener('focusout', sumLabas);
        document.getElementById('laba4').addEventListener('focusout', sumLabas);
        document.getElementById('laba5').addEventListener('focusout', sumLabas);
        document.getElementById('laba6').addEventListener('focusout', sumLabas);
        document.getElementById('laba7').addEventListener('focusout', sumLabas);
        document.getElementById('laba8').addEventListener('focusout', sumLabas);
    </script>
    <script>
        function sumOmzets() {
            var omzet1 = document.getElementById('omzet1').value || 0;
            var omzet2 = document.getElementById('omzet2').value || 0;
            var omzet3 = document.getElementById('omzet3').value || 0;
            var omzet4 = document.getElementById('omzet4').value || 0;
            var omzet5 = document.getElementById('omzet5').value || 0;
            var omzet6 = document.getElementById('omzet6').value || 0;
            var omzet7 = document.getElementById('omzet7').value || 0;
            var omzet8 = document.getElementById('omzet8').value || 0;

            var omzetSum = parseInt(omzet1) + parseInt(omzet2) + parseInt(omzet3) + parseInt(omzet4) + parseInt(
                omzet5) + parseInt(omzet6) + parseInt(omzet7) + parseInt(omzet8);

            document.getElementById('omzett').value = omzetSum;
        }

        document.getElementById('omzet1').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet2').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet3').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet4').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet5').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet6').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet7').addEventListener('focusout', sumOmzets);
        document.getElementById('omzet8').addEventListener('focusout', sumOmzets);
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/Pegadaian/010001.blade.php ENDPATH**/ ?>