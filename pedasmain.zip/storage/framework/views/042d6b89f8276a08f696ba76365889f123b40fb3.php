<?php if (isset($component)) { $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51 = $component; } ?>
<?php $component = App\View\Components\TabelEntriView::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabel-entri-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TabelEntriView::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'judultabel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabel),'judultabelen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabelen)]); ?>
    <?php if(!empty($data)): ?>
         <?php $__env->slot('tabel1', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th colspan="8">VOLUME PRODUKSI SAMPAH KABUPATEN SOPPENG TAHUN 2018-2021</th>

                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td rowspan="3">NO</td>
                        <td rowspan="3">BULAN</td>
                        <td colspan="3">2018</td>
                    </tr>
                    <tr>
                        <td colspan="2">PRODUKSI SAMPAH</td>
                        <td rowspan="2">NILAI SAMPAH YANG DIDAUR ULANG (Rp)</td>
                    </tr>
                    <tr>
                        <td>VOLUME (M3)</td>
                        <td>NILAI (Rp)</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Januari</td>
                        <td>5,162</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Februari</td>
                        <td>5,211</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Maret</td>
                        <td>5,142</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>April</td>
                        <td>4,981</td>
                        <td></td>
                        <td></td>
                        <td>4,530</td>
                        <td></td>
                        <td></td>
                        <td>4,737</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Mei</td>
                        <td>5,193</td>
                        <td></td>
                        <td></td>
                        <td>4,768</td>
                        <td></td>
                        <td></td>
                        <td>4,179</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Juni</td>
                        <td>5,237</td>
                        <td></td>
                        <td></td>
                        <td>4,249</td>
                        <td></td>
                        <td></td>
                        <td>4,753</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>Juli</td>
                        <td>5,161</td>
                        <td></td>
                        <td></td>
                        <td>5,208</td>
                        <td></td>
                        <td></td>
                        <td>5,032</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>Agustus</td>
                        <td>5,293</td>
                        <td></td>
                        <td></td>
                        <td>5,201</td>
                        <td></td>
                        <td></td>
                        <td>4,690</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>September</td>
                        <td>5,089</td>
                        <td></td>
                        <td></td>
                        <td>4,978</td>
                        <td></td>
                        <td></td>
                        <td>5,040</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>Oktober</td>
                        <td>5,562</td>
                        <td></td>
                        <td></td>
                        <td>5,195</td>
                        <td></td>
                        <td></td>
                        <td>4,938</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>11</td>
                        <td>November</td>
                        <td>5,761</td>
                        <td></td>
                        <td></td>
                        <td>4,882</td>
                        <td></td>
                        <td></td>
                        <td>4,428</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>Desember</td>
                        <td>4,776</td>
                        <td></td>
                        <td></td>
                        <td>4,778</td>
                        <td></td>
                        <td></td>
                        <td>4,844</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td colspan="2">JUMLAH</td>
                        <td>62,570</td>
                        <td></td>
                        <td></td>
                        <td>57,958</td>
                        <td></td>
                        <td></td>
                        <td>57,131</td>
                        <td></td>
                        <td></td>
                        <td>69,517</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                </tbody>
            </table>

         <?php $__env->endSlot(); ?>
    <?php else: ?>
         <?php $__env->slot('tabel2', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th colspan="8">VOLUME PRODUKSI SAMPAH</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="8">KABUPATEN SOPPENG TAHUN 2018-2021</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td rowspan="3">NO</td>
                        <td rowspan="3">BULAN</td>
                        <td colspan="3">2018</td>
                        <td colspan="3">2019</td>
                        <td colspan="3">2020</td>
                        <td colspan="3">2021</td>
                    </tr>
                    <tr>
                        <td colspan="2">PRODUKSI SAMPAH</td>
                        <td rowspan="2">NILAI SAMPAH YANG DIDAUR ULANG (Rp)</td>
                        <td colspan="2">PRODUKSI SAMPAH</td>
                        <td rowspan="2">NILAI SAMPAH YANG DIDAUR ULANG (Rp)</td>
                        <td colspan="2">PRODUKSI SAMPAH</td>
                        <td rowspan="2">NILAI SAMPAH YANG DIDAUR ULANG (Rp)</td>
                        <td colspan="2">PRODUKSI SAMPAH</td>
                        <td rowspan="2">NILAI SAMPAH YANG DIDAUR ULANG (Rp)*</td>
                    </tr>
                    <tr>
                        <td>VOLUME (M3)</td>
                        <td>NILAI (Rp)</td>
                        <td>VOLUME (M3)</td>
                        <td>NILAI (Rp)</td>
                        <td>VOLUME (M3)</td>
                        <td>NILAI (Rp)</td>
                        <td>VOLUME (M3)</td>
                        <td>NILAI (Rp)*</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Januari</td>
                        <td>5,162</td>
                        <td></td>
                        <td></td>
                        <td>4,954</td>
                        <td></td>
                        <td></td>
                        <td>4,892</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Februari</td>
                        <td>5,211</td>
                        <td></td>
                        <td></td>
                        <td>4,441</td>
                        <td></td>
                        <td></td>
                        <td>4,804</td>
                        <td></td>
                        <td></td>
                        <td>5,333</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Maret</td>
                        <td>5,142</td>
                        <td></td>
                        <td></td>
                        <td>4,774</td>
                        <td></td>
                        <td></td>
                        <td>4,794</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>April</td>
                        <td>4,981</td>
                        <td></td>
                        <td></td>
                        <td>4,530</td>
                        <td></td>
                        <td></td>
                        <td>4,737</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Mei</td>
                        <td>5,193</td>
                        <td></td>
                        <td></td>
                        <td>4,768</td>
                        <td></td>
                        <td></td>
                        <td>4,179</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>Juni</td>
                        <td>5,237</td>
                        <td></td>
                        <td></td>
                        <td>4,249</td>
                        <td></td>
                        <td></td>
                        <td>4,753</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>Juli</td>
                        <td>5,161</td>
                        <td></td>
                        <td></td>
                        <td>5,208</td>
                        <td></td>
                        <td></td>
                        <td>5,032</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>Agustus</td>
                        <td>5,293</td>
                        <td></td>
                        <td></td>
                        <td>5,201</td>
                        <td></td>
                        <td></td>
                        <td>4,690</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>September</td>
                        <td>5,089</td>
                        <td></td>
                        <td></td>
                        <td>4,978</td>
                        <td></td>
                        <td></td>
                        <td>5,040</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>Oktober</td>
                        <td>5,562</td>
                        <td></td>
                        <td></td>
                        <td>5,195</td>
                        <td></td>
                        <td></td>
                        <td>4,938</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>11</td>
                        <td>November</td>
                        <td>5,761</td>
                        <td></td>
                        <td></td>
                        <td>4,882</td>
                        <td></td>
                        <td></td>
                        <td>4,428</td>
                        <td></td>
                        <td></td>
                        <td>5,714</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>Desember</td>
                        <td>4,776</td>
                        <td></td>
                        <td></td>
                        <td>4,778</td>
                        <td></td>
                        <td></td>
                        <td>4,844</td>
                        <td></td>
                        <td></td>
                        <td>5,904</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                    <tr>
                        <td colspan="2">JUMLAH</td>
                        <td>62,570</td>
                        <td></td>
                        <td></td>
                        <td>57,958</td>
                        <td></td>
                        <td></td>
                        <td>57,131</td>
                        <td></td>
                        <td></td>
                        <td>69,517</td>
                        <td>...</td>
                        <td>...</td>
                    </tr>
                </tbody>
            </table>

         <?php $__env->endSlot(); ?>
    <?php endif; ?>
     <?php $__env->slot('script', null, []); ?> 
        <?php echo $__env->make('tabel.skpd.023_DPMDes.script3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51)): ?>
<?php $component = $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51; ?>
<?php unset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/004_DLH/004003.blade.php ENDPATH**/ ?>