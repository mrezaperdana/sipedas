<?php if (isset($component)) { $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51 = $component; } ?>
<?php $component = App\View\Components\TabelEntriView::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabel-entri-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TabelEntriView::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'judultabel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabel),'judultabelen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($judultabelen)]); ?>
    <?php if(!empty($data)): ?>
         <?php $__env->slot('tabel1', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tabel 4.3.10</th>
                        <th>Daftar Nama dan Alamat Taman Kota di Kabupaten Soppeng, 2021</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Table 4.3.10</td>
                        <td>List of Name and Addreses of City Parks in Soppeng Regency, 2021</td>
                    </tr>

                    <tr>
                        <td>Taman/ Park</td>
                        <td>Alamat/ Address</td>
                    </tr>
                    <tr>
                        <td>(1)</td>
                        <td>(2)</td>
                    </tr>
                    <tr>
                        <td>Taman Bunga Laburawung</td>
                        <td>sebelah Utara Stadion H. A. Wana</td>
                    </tr>
                    <tr>
                        <td>Taman Tugu BNI</td>
                        <td>Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman Lamumpatue (Bank SulSelBar)</td>
                        <td>Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman SalassaE</td>
                        <td>Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman Villa Yuliana</td>
                        <td>Jl. Pengayoman</td>
                    </tr>
                    <tr>
                        <td>Taman Kalong</td>
                        <td>Jl. Merdeka/Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman Tugu Adipura</td>
                        <td>Jl. Pemuda</td>
                    </tr>
                    <tr>
                        <td>Taman BNI</td>
                        <td>Jl. Kalino</td>
                    </tr>
                    <tr>
                        <td>Taman Anggrek</td>
                        <td>Jl. Kemakmuran</td>
                    </tr>
                    <tr>
                        <td>Taman Sutra</td>
                        <td>Jl. Kemakmuran</td>
                    </tr>
                    <tr>
                        <td>Taman Dare' Bunga-BungaE</td>
                        <td>Pajalesang, Kec. Lilirilau</td>
                    </tr>
                    <tr>
                        <td>Taman Tugu Arung Palakka</td>
                        <td>Tettikenrarae, Kec. Marioriwawo</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga Batu-batu</td>
                        <td>Batu-batu, Kec. Marioriawa</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga dekat KUA Liliriaja</td>
                        <td>Cangadi, Kec. Liliriaja</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga Salaonro</td>
                        <td>Kel. Ujung, Kec. Lilirilau</td>
                    </tr>
                    <tr>
                        <td>Taman Waduk Ompo</td>
                        <td>Ompo</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga Depan Kelurahan Botto</td>
                        <td>Jl. Kayangan</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga (Taman Gula Merah)</td>
                        <td>Jl. Harun Sewo</td>
                    </tr>
                    <tr>
                        <td>Isikan jika masih ada yang lain</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Isikan jika masih ada yang lain</td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
         <?php $__env->endSlot(); ?>
    <?php else: ?>
         <?php $__env->slot('tabel2', null, []); ?> 
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tabel 4.3.10</th>
                        <th>Daftar Nama dan Alamat Taman Kota di Kabupaten Soppeng, 2021</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Table 4.3.10</td>
                        <td>List of Name and Addreses of City Parks in Soppeng Regency, 2021</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Taman/</td>
                        <td>Alamat/</td>
                    </tr>
                    <tr>
                        <td>The Park</td>
                        <td>Address</td>
                    </tr>
                    <tr>
                        <td>(1)</td>
                        <td>(2)</td>
                    </tr>
                    <tr>
                        <td>Taman Bunga Laburawung</td>
                        <td>sebelah Utara Stadion H. A. Wana</td>
                    </tr>
                    <tr>
                        <td>Taman Tugu BNI</td>
                        <td>Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman Lamumpatue (Bank SulSelBar)</td>
                        <td>Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman SalassaE</td>
                        <td>Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman Villa Yuliana</td>
                        <td>Jl. Pengayoman</td>
                    </tr>
                    <tr>
                        <td>Taman Kalong</td>
                        <td>Jl. Merdeka/Jl. Lamumpatu'e</td>
                    </tr>
                    <tr>
                        <td>Taman Tugu Adipura</td>
                        <td>Jl. Pemuda</td>
                    </tr>
                    <tr>
                        <td>Taman BNI</td>
                        <td>Jl. Kalino</td>
                    </tr>
                    <tr>
                        <td>Taman Anggrek</td>
                        <td>Jl. Kemakmuran</td>
                    </tr>
                    <tr>
                        <td>Taman Sutra</td>
                        <td>Jl. Kemakmuran</td>
                    </tr>
                    <tr>
                        <td>Taman Dare' Bunga-BungaE</td>
                        <td>Pajalesang, Kec. Lilirilau</td>
                    </tr>
                    <tr>
                        <td>Taman Tugu Arung Palakka</td>
                        <td>Tettikenrarae, Kec. Marioriwawo</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga Batu-batu</td>
                        <td>Batu-batu, Kec. Marioriawa</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga dekat KUA Liliriaja</td>
                        <td>Cangadi, Kec. Liliriaja</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga Salaonro</td>
                        <td>Kel. Ujung, Kec. Lilirilau</td>
                    </tr>
                    <tr>
                        <td>Taman Waduk Ompo</td>
                        <td>Ompo</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga Depan Kelurahan Botto</td>
                        <td>Jl. Kayangan</td>
                    </tr>
                    <tr>
                        <td>Taman Segitiga (Taman Gula Merah)</td>
                        <td>Jl. Harun Sewo</td>
                    </tr>
                    <tr>
                        <td>Isikan jika masih ada yang lain</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Isikan jika masih ada yang lain</td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
         <?php $__env->endSlot(); ?>
    <?php endif; ?>
     <?php $__env->slot('script', null, []); ?> 
        <?php echo $__env->make('tabel.skpd.023_DPMDes.script2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51)): ?>
<?php $component = $__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51; ?>
<?php unset($__componentOriginal46b31e1315d8d7fb1ead1df40f02c6dd395ffc51); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/004_DLH/004002.blade.php ENDPATH**/ ?>