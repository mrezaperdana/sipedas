<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p> <?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-wa1i"><span style="font-weight:bold">Tahun</span></th>
                    <th class="tg-wa1i"><span style="font-weight:bold">NILAI OMZET (Rp.000)</span></th>
                    <th class="tg-wa1i"><span style="font-weight:bold">NILAI LABA (Rp.000)</span></th>
                </tr>
            </thead>
            <tbody>
                
                
                <tr>
                    <td class="tg-2b7s"><?php echo e($data->tahun); ?></td>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['omzet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="omzet" name="omzet" value="<?php echo e(old('omzet', $data->omzet)); ?>">
                        <?php $__errorArgs = ['omzet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" class="form-control <?php $__errorArgs = ['laba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="laba" name="laba" value="<?php echo e(old('laba', $data->laba)); ?>">
                        <?php $__errorArgs = ['laba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>

    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-wa1i"><span style="font-weight:bold">Tahun</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">NILAI OMZET (Rp.000)</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">NILAI LABA (Rp.000)</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-2b7s">2020</td>
                <td class="tg-2b7s"><span style="font-weight:normal">99903191</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">8391827</span></td>
            </tr>
            <tr>
                <td class="tg-2b7s">2021</td>
                <td class="tg-2b7s"><span style="font-weight:normal">98533869</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">7625570</span></td>
            </tr>
            <tr>
                <td class="tg-2b7s">2022</td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/Koperasi/008001.blade.php ENDPATH**/ ?>