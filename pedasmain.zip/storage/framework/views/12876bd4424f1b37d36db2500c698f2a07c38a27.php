<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                    <th class="tg-wa1i"><span style="font-weight:bold">Banyaknya Tenaga Medis di RSUD La
                            Temmamala Kabupaten Soppeng, <?php echo e($data->tahun); ?></span></th>
                </tr>
                <tr>
                    <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                    <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Number of
                            Paramedics in La Temmamala Hospital of Soppeng Regency, <?php echo e($data->tahun); ?></span></th>
                </tr>
            </thead>
            <tbody>

                <tr>
                    <td class="tg-nrix">Tenaga Medis/Paramedics

                    </td>
                    <td class="tg-baqh"><?php echo e($data->tahun); ?></td>

                </tr>

                <tr>
                    <td class="tg-nrix">(1)</td>
                    <td class="tg-nrix">(2)</td>

                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Spesialis/</span><span
                            style="font-style:italic;color:#000">Specialist Doctor</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis1"
                            name="tenagamedis1" value="<?php echo e(old('tenagamedis1', $data->tenagamedis1)); ?>">
                        <?php $__errorArgs = ['tenagamedis1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Spesialis Gigi/</span><span
                            style="font-style:italic;color:#000">Dental Specialist Doctor</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis2"
                            name="tenagamedis2" value="<?php echo e(old('tenagamedis2', $data->tenagamedis2)); ?>">
                        <?php $__errorArgs = ['tenagamedis2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Umum/</span><span
                            style="font-style:italic;color:#000">General Practitioners</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis3"
                            name="tenagamedis3" value="<?php echo e(old('tenagamedis3', $data->tenagamedis3)); ?>">
                        <?php $__errorArgs = ['tenagamedis3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Gigi/</span><span
                            style="font-style:italic;color:#000">Dentist</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis4"
                            name="tenagamedis4" value="<?php echo e(old('tenagamedis4', $data->tenagamedis4)); ?>">
                        <?php $__errorArgs = ['tenagamedis4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Bidan/</span><span
                            style="font-style:italic;color:#000">Midwife</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis5"
                            name="tenagamedis5" value="<?php echo e(old('tenagamedis5', $data->tenagamedis5)); ?>">
                        <?php $__errorArgs = ['tenagamedis5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Perawat/</span><span
                            style="font-style:italic;color:#000">Nurse</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis6"
                            name="tenagamedis6" value="<?php echo e(old('tenagamedis6', $data->tenagamedis6)); ?>">
                        <?php $__errorArgs = ['tenagamedis6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Perawat Gigi/</span><span
                            style="font-style:italic;color:#000">Dental Nurse</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis7"
                            name="tenagamedis7" value="<?php echo e(old('tenagamedis7', $data->tenagamedis7)); ?>">
                        <?php $__errorArgs = ['tenagamedis7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Tenaga Teknis
                            Kefarmasian/</span><span style="font-style:italic;color:#000">Pharmacist</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis8"
                            name="tenagamedis8" value="<?php echo e(old('tenagamedis8', $data->tenagamedis8)); ?>">
                        <?php $__errorArgs = ['tenagamedis8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Apoterker/</span><span
                            style="font-style:italic;color:#000">Druggist</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis9"
                            name="tenagamedis9" value="<?php echo e(old('tenagamedis9', $data->tenagamedis9)); ?>">
                        <?php $__errorArgs = ['tenagamedis9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Kesehatan Masyarakat/</span><span
                            style="font-style:italic;color:#000">Public Health</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis10"
                            name="tenagamedis10" value="<?php echo e(old('tenagamedis10', $data->tenagamedis10)); ?>">
                        <?php $__errorArgs = ['tenagamedis10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Kesehatan Lingkungan/ </span><span
                            style="font-style:italic;color:#000">Environmental Health</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis11"
                            name="tenagamedis11" value="<?php echo e(old('tenagamedis11', $data->tenagamedis11)); ?>">
                        <?php $__errorArgs = ['tenagamedis11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Fisiotrapi/</span><span
                            style="font-style:italic;color:#000">Physiotheraphist</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedis12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedis12"
                            name="tenagamedis12" value="<?php echo e(old('tenagamedis12', $data->tenagamedis12)); ?>">
                        <?php $__errorArgs = ['tenagamedis12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-baqh"><span style="font-style:normal;color:#000">Jumlah/</span><span
                            style="font-style:italic;color:#000">Total</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['tenagamedist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tenagamedist"
                            name="tenagamedist" value="<?php echo e(old('tenagamedist', $data->tenagamedist)); ?>">
                        <?php $__errorArgs = ['tenagamedist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                <th class="tg-amwm" rowspan="2">4.2.13</th>
                <th class="tg-wa1i" colspan="4"><span style="font-weight:bold">Banyaknya Tenaga Medis di RSUD La
                        Temmamala Kabupaten Soppeng, <?php echo e($data->tahun); ?></span></th>
            </tr>
            <tr>
                <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                <th class="tg-xxp7" colspan="4"><span style="font-weight:bold;font-style:italic">Number of
                        Paramedics in La Temmamala Hospital of Soppeng Regency, <?php echo e($data->tahun); ?></span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">Tenaga Medis/</td>
                <td class="tg-baqh" rowspan="2"><?php echo e($data->tahun); ?></td>
                <td class="tg-baqh" rowspan="2">2018</td>
                <td class="tg-baqh" rowspan="2">2019</td>
                <td class="tg-baqh" rowspan="2">2020</td>
                <td class="tg-baqh" rowspan="2">2021</td>
            </tr>
            <tr>
                <td class="tg-lhti"><span style="font-style:italic">Paramedics</span></td>
            </tr>
            <tr>
                <td class="tg-nrix">(1)</td>
                <td class="tg-nrix">(2)</td>
                <td class="tg-nrix">(3)</td>
                <td class="tg-nrix">(4)</td>
                <td class="tg-nrix">(5)</td>
                <td class="tg-nrix">(6)</td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Spesialis/</span><span
                        style="font-style:italic;color:#000">Specialist Doctor</span></td>
                <td class="tg-mwxe">21</td>
                <td class="tg-mwxe">22</td>
                <td class="tg-mwxe">21</td>
                <td class="tg-mwxe">27</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">26</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Spesialis Gigi/</span><span
                        style="font-style:italic;color:#000">Dental Specialist Doctor</span></td>
                <td class="tg-mwxe">1</td>
                <td class="tg-mwxe">1</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">2</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Umum/</span><span
                        style="font-style:italic;color:#000">General Practitioners</span></td>
                <td class="tg-mwxe">8</td>
                <td class="tg-mwxe">17</td>
                <td class="tg-mwxe">11</td>
                <td class="tg-mwxe">11</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">8</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Dokter Gigi/</span><span
                        style="font-style:italic;color:#000">Dentist</span></td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">1</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Bidan/</span><span
                        style="font-style:italic;color:#000">Midwife</span></td>
                <td class="tg-mwxe">23</td>
                <td class="tg-mwxe">106</td>
                <td class="tg-mwxe">27</td>
                <td class="tg-mwxe">27</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">27</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Perawat/</span><span
                        style="font-style:italic;color:#000">Nurse</span></td>
                <td class="tg-mwxe">103</td>
                <td class="tg-mwxe">295</td>
                <td class="tg-mwxe">123</td>
                <td class="tg-mwxe">125</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">121</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Perawat Gigi/</span><span
                        style="font-style:italic;color:#000">Dental Nurse</span></td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">3</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">2</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Tenaga Teknis Kefarmasian/</span><span
                        style="font-style:italic;color:#000">Pharmacist</span></td>
                <td class="tg-mwxe">5</td>
                <td class="tg-mwxe">11</td>
                <td class="tg-mwxe">8</td>
                <td class="tg-mwxe">8</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">8</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Apoterker/</span><span
                        style="font-style:italic;color:#000">Druggist</span></td>
                <td class="tg-mwxe">8</td>
                <td class="tg-mwxe">32</td>
                <td class="tg-mwxe">10</td>
                <td class="tg-mwxe">12</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">11</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Kesehatan Masyarakat/</span><span
                        style="font-style:italic;color:#000">Public Health</span></td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">2</td>
                <td class="tg-mwxe">1</td>
                <td class="tg-mwxe">4</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">4</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Kesehatan Lingkungan/ </span><span
                        style="font-style:italic;color:#000">Environmental Health</span></td>
                <td class="tg-mwxe">3</td>
                <td class="tg-mwxe">3</td>
                <td class="tg-mwxe">5</td>
                <td class="tg-mwxe">6</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">6</span></td>
            </tr>
            <tr>
                <td class="tg-0lax"><span style="font-style:normal;color:#000">Fisiotrapi/</span><span
                        style="font-style:italic;color:#000">Physiotheraphist</span></td>
                <td class="tg-mwxe">5</td>
                <td class="tg-mwxe">8</td>
                <td class="tg-mwxe">7</td>
                <td class="tg-mwxe">7</td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">7</span></td>
            </tr>
            <tr>
                <td class="tg-baqh"><span style="font-style:normal;color:#000">Jumlah/</span><span
                        style="font-style:italic;color:#000">Total</span></td>
                <td class="tg-mwxe">183</td>
                <td class="tg-mwxe">502</td>
                <td class="tg-mwxe">219</td>
                <td class="tg-mwxe">233</td>
                <td class="tg-mwxe">223</td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    

    <?php echo $__env->make('tabel.skpd.036_RSUD.script1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/036_RSUD/036001.blade.php ENDPATH**/ ?>