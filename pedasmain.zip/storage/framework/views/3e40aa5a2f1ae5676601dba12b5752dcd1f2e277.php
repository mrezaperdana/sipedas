
<?php $__env->startSection('title', 'Edit'); ?>
<?php $__env->startSection('content'); ?>

    
    <!-- About Me Box -->
    <div class="col-md">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Informasi Umum</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                
                <?php echo $__env->make($tipetabel, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
    <!-- /.card -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.users.layouts.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pedas\resources\views/dashboard/admins/entriedit.blade.php ENDPATH**/ ?>