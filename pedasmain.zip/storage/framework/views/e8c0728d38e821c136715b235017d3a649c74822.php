
<?php $__env->startSection('title', 'Tambah Kegiatan'); ?>
<?php $__env->startSection('head'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <div class="flex-grow-1">
                                <h3 class="card-title">Form Penambahan Kegiatan Baru</h3>
                            </div>

                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">

                            <form action="<?php echo e(route('admin.storekegiatan')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="judul" class="form-label">1. Nama Kegiatan</label>
                                    <p>Contoh: Survei Angkatan Kerja Nasional Februari</p>
                                    <input list="judulList" type="text"
                                        class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="judul"
                                        name="judul" required value="<?php echo e(old('judul')); ?>">
                                    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <datalist id="judulList">
                                        <?php $__currentLoopData = $unique_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($judul); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>

                                </div>
                                <hr class="my-4">
                                <div class="mb-3">
                                    <label for="tahun" class="form-label">2. Tahun Pelaksanaan</label>

                                    <input list="tahunList" type="text"
                                        class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tahun"
                                        name="tahun" required value="<?php echo e(old('tahun')); ?>">
                                    <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <datalist id="tahunList">
                                        <?php $__currentLoopData = $datakegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allItemss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($allItemss->tahun); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                                <hr class="my-4">
                                <div class="mb-3">
                                    <label for="template_file" class="form-label">3. Template Excel</label>
                                    <div class="form-group"><input type="file" name="template_file" id="template_file">
                                    </div>
                                </div>
                                <hr class="my-4">
                                <div class="mb-3">
                                    <label for="responden" class="form-label">3. Responden Kegiatan</label>
                                    <p>*Nama lengkap instansi bisa dilihat di tabel <a href="#tabel-instansi">berikut.</a>
                                    </p>
                                </div>
                                <hr class="my-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="select-all">
                                    <label class="form-check-label" for="select-all">
                                        Semua Instansi
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label for="search">Search:</label>
                                    <input type="text" id="instansi-filter" class="form-control"
                                        placeholder="Filter by singkatan..." onkeyup="filterInstansi()">
                                </div>
                                
                                <div class="row" id="instansi-checkboxes">
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allItemss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-3 col-md-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="responden[]"
                                                    value="<?php echo e($allItemss->kodeinstansi); ?>"
                                                    id="<?php echo e($allItemss->kodeinstansi); ?>"
                                                    data-singkatan="<?php echo e($allItemss->singkatan); ?>"
                                                    <?php if(in_array($allItemss->kodeinstansi, json_decode($data['responden'] ?? '[]', true))): ?> checked <?php endif; ?>>
                                                <label class="form-check-label" for="<?php echo e($allItemss->kodeinstansi); ?>">
                                                    <?php echo e($allItemss->singkatan); ?>

                                                </label>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <div class="flex-grow-1">
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-primary"> <i
                                                class="nav-icon fas fa-plus "></i> Tambah
                                            Kegiatan</button>
                                        <a class="btn btn-info"href="<?php echo e(route('admin.daftarkegiatan')); ?>"
                                            role="button">Batal</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <div class="flex-grow-1">
                                <h3 class="card-title" id="tabel-instansi">Daftar Semua Instansi</h3>
                            </div>

                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div style="height: 300px; overflow-y: scroll;">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Instansi</th>
                                            <th>Singkatan</th>
                                            <th>Kode Instansi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allItemss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($allItemss->namainstansi); ?></td>
                                                <td><?php echo e($allItemss->singkatan); ?> </td>
                                                <td><?php echo e($allItemss->kodeinstansi); ?> </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
        <script>
            function filterInstansi() {
                var input, filter, checkboxes, checkbox, singkatan;
                input = document.getElementById("instansi-filter");
                filter = input.value.toUpperCase();
                checkboxes = document.querySelectorAll("input[name='responden[]']");
                for (var i = 0; i < checkboxes.length; i++) {
                    checkbox = checkboxes[i];
                    singkatan = checkbox.getAttribute("data-singkatan").toUpperCase();
                    if (singkatan.indexOf(filter) > -1) {
                        checkbox.parentNode.parentNode.style.display = "";
                    } else {
                        checkbox.parentNode.parentNode.style.display = "none";
                    }
                }
            }
        </script>
        <script>
            document.getElementById('select-all').addEventListener('click', function() {
                const checkboxes = document.getElementsByName('responden[]');
                for (let i = 0; i < checkboxes.length; i++) {
                    checkboxes[i].checked = this.checked;
                }
            });

            document.getElementById('responden-form').addEventListener('submit', function(event) {
                event.preventDefault();
                const form = event.target;
                const formData = new FormData(form);
                console.log(formData.getAll('responden[]'));
                // Submit the form or do other things with the form data
            });
        </script>

        <!-- Bootstrap JavaScript -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

        <!-- Custom JavaScript -->
        <script>
            // add event listener for "Select All" checkbox
            document.getElementById("select-all").addEventListener("click", function() {
                var checkboxes = document.querySelectorAll("input[type=checkbox]");
                for (var i = 0; i < checkboxes.length; i++) {
                    checkboxes[i].checked = this.checked;
                }
            });
        </script>

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- DataTables  & Plugins -->

    <script src="/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="/plugins/jszip/jszip.min.js"></script>
    <script src="/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <!-- Page specific script -->

    <script>
        $('#example1').DataTable({
            searching: true, // Disable search functionality
            paging: true, // Enable pagination
            ordering: true, // Enable sorting
            responsive: true, // Make the table responsive
            pagingType: "full_numbers", // Use the "full_numbers" pagination control style
            dom: "lfrtip", // Display the pagination control at the bottom of the table
            initComplete: true, // Disable filter functionality
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admins.layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pedas\resources\views/dashboard/admins/daftarkegiatan/create.blade.php ENDPATH**/ ?>