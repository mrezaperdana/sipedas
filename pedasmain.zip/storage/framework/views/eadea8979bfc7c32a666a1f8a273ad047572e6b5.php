<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                    <th class="tg-amwm" rowspan="2">2.2.1</th>
                    <th class="tg-wa1i" colspan="2"><span style="font-weight:bold"><?php echo e($judultabel); ?>,
                            <?php echo e($data->tahun); ?></span></th>
                </tr>
                <tr>
                    <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                    <th class="tg-xxp7" colspan="2"><span style="font-weight:bold;font-style:italic">
                            <?php echo e($judultabelen); ?>, <?php echo e($data->tahun); ?></span>
                    </th>
                </tr>
                <tr>
                    <th class="tg-baqh" rowspan="2"><span style="font-style:normal;color:#000">Partai
                            Politik/</span><span style="font-style:italic;color:#000">Political Party</span></th>
                    <th class="tg-nrix" colspan="3">Jenis Kelamin/Sex</th>
                </tr>
                <tr>
                    <th class="tg-nrix">Laki-Laki/Men</th>
                    <th class="tg-nrix">Perempuan/Women</th>
                    <th class="tg-nrix">Jumlah/Total</th>
                </tr>
                <tr>
                    <th class="tg-nrix">(1)</th>
                    <th class="tg-nrix">(2)</th>
                    <th class="tg-nrix">(3)</th>
                    <th class="tg-nrix">(4)</th>
                </tr>
            </thead>
            <tbody>

                <tr>
                    <td class="tg-7zrl">Gerindra</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki1"
                            name="lakilaki1" value="<?php echo e(old('lakilaki1', $data->lakilaki1)); ?>">
                        <?php $__errorArgs = ['lakilaki1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan1"
                            name="perempuan1" value="<?php echo e(old('perempuan1', $data->perempuan1)); ?>">
                        <?php $__errorArgs = ['perempuan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah1" name="jumlah1"
                            value="<?php echo e(old('jumlah1', $data->jumlah1)); ?>">
                        <?php $__errorArgs = ['jumlah1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">Golkar</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki2"
                            name="lakilaki2" value="<?php echo e(old('lakilaki2', $data->lakilaki2)); ?>">
                        <?php $__errorArgs = ['lakilaki2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan2"
                            name="perempuan2" value="<?php echo e(old('perempuan2', $data->perempuan2)); ?>">
                        <?php $__errorArgs = ['perempuan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah2" name="jumlah2"
                            value="<?php echo e(old('jumlah2', $data->jumlah2)); ?>">
                        <?php $__errorArgs = ['jumlah2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">PDI-P</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki3"
                            name="lakilaki3" value="<?php echo e(old('lakilaki3', $data->lakilaki3)); ?>">
                        <?php $__errorArgs = ['lakilaki3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan3"
                            name="perempuan3" value="<?php echo e(old('perempuan3', $data->perempuan3)); ?>">
                        <?php $__errorArgs = ['perempuan3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah3" name="jumlah3"
                            value="<?php echo e(old('jumlah3', $data->jumlah3)); ?>">
                        <?php $__errorArgs = ['jumlah3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">PPP</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki4"
                            name="lakilaki4" value="<?php echo e(old('lakilaki4', $data->lakilaki4)); ?>">
                        <?php $__errorArgs = ['lakilaki4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan4"
                            name="perempuan4" value="<?php echo e(old('perempuan4', $data->perempuan4)); ?>">
                        <?php $__errorArgs = ['perempuan4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah4"
                            name="jumlah4" value="<?php echo e(old('jumlah4', $data->jumlah4)); ?>">
                        <?php $__errorArgs = ['jumlah4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">Demokrat</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki5"
                            name="lakilaki5" value="<?php echo e(old('lakilaki5', $data->lakilaki5)); ?>">
                        <?php $__errorArgs = ['lakilaki5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan5"
                            name="perempuan5" value="<?php echo e(old('perempuan5', $data->perempuan5)); ?>">
                        <?php $__errorArgs = ['perempuan5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah5"
                            name="jumlah5" value="<?php echo e(old('jumlah5', $data->jumlah5)); ?>">
                        <?php $__errorArgs = ['jumlah5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">PAN</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki6"
                            name="lakilaki6" value="<?php echo e(old('lakilaki6', $data->lakilaki6)); ?>">
                        <?php $__errorArgs = ['lakilaki6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan6"
                            name="perempuan6" value="<?php echo e(old('perempuan6', $data->perempuan6)); ?>">
                        <?php $__errorArgs = ['perempuan6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah6"
                            name="jumlah6" value="<?php echo e(old('jumlah6', $data->jumlah6)); ?>">
                        <?php $__errorArgs = ['jumlah6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">PKS</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki7"
                            name="lakilaki7" value="<?php echo e(old('lakilaki7', $data->lakilaki7)); ?>">
                        <?php $__errorArgs = ['lakilaki7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan7"
                            name="perempuan7" value="<?php echo e(old('perempuan7', $data->perempuan7)); ?>">
                        <?php $__errorArgs = ['perempuan7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah7"
                            name="jumlah7" value="<?php echo e(old('jumlah7', $data->jumlah7)); ?>">
                        <?php $__errorArgs = ['jumlah7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">PKB</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki8"
                            name="lakilaki8" value="<?php echo e(old('lakilaki8', $data->lakilaki8)); ?>">
                        <?php $__errorArgs = ['lakilaki8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan8"
                            name="perempuan8" value="<?php echo e(old('perempuan8', $data->perempuan8)); ?>">
                        <?php $__errorArgs = ['perempuan8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah8"
                            name="jumlah8" value="<?php echo e(old('jumlah8', $data->jumlah8)); ?>">
                        <?php $__errorArgs = ['jumlah8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">PBB</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki9"
                            name="lakilaki9" value="<?php echo e(old('lakilaki9', $data->lakilaki9)); ?>">
                        <?php $__errorArgs = ['lakilaki9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan9"
                            name="perempuan9" value="<?php echo e(old('perempuan9', $data->perempuan9)); ?>">
                        <?php $__errorArgs = ['perempuan9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah9"
                            name="jumlah9" value="<?php echo e(old('jumlah9', $data->jumlah9)); ?>">
                        <?php $__errorArgs = ['jumlah9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl">Nasdem</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki10"
                            name="lakilaki10" value="<?php echo e(old('lakilaki10', $data->lakilaki10)); ?>">
                        <?php $__errorArgs = ['lakilaki10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan10"
                            name="perempuan10" value="<?php echo e(old('perempuan10', $data->perempuan10)); ?>">
                        <?php $__errorArgs = ['perempuan10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah10"
                            name="jumlah10" value="<?php echo e(old('jumlah10', $data->jumlah10)); ?>">
                        <?php $__errorArgs = ['jumlah10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['var'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="var" name="lainnyavar"
                            value="<?php echo e(old('lainnyavar', $data->lainnyavar)); ?>">
                        <?php $__errorArgs = ['lainnyavar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilaki11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilaki11"
                            name="lakilaki11" value="<?php echo e(old('lakilaki11', $data->lakilaki11)); ?>">
                        <?php $__errorArgs = ['lakilaki11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuan11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuan11"
                            name="perempuan11" value="<?php echo e(old('perempuan11', $data->perempuan11)); ?>">
                        <?php $__errorArgs = ['perempuan11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlah11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah11"
                            name="jumlah11" value="<?php echo e(old('jumlah11', $data->jumlah11)); ?>">
                        <?php $__errorArgs = ['jumlah11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-f4yw"><span style="background-color:#FFF">Jumlah/Total</span></td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['lakilakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lakilakit"
                            name="lakilakit" value="<?php echo e(old('lakilakit', $data->lakilakit)); ?>">
                        <?php $__errorArgs = ['lakilakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['perempuant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="perempuant"
                            name="perempuant" value="<?php echo e(old('perempuant', $data->perempuant)); ?>">
                        <?php $__errorArgs = ['perempuant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['jumlaht'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlaht"
                            name="jumlaht" value="<?php echo e(old('jumlaht', $data->jumlaht)); ?>">
                        <?php $__errorArgs = ['jumlaht'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-7zrl"></th>
                <th class="tg-7zrl"></th>
                <th class="tg-7zrl"></th>
                <th class="tg-7zrl"></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-wa1i"><span style="font-weight:bold">Tabel</span></td>
                <td class="tg-amwm" rowspan="2">2.2.1</td>
                <td class="tg-wa1i" colspan="2"><span style="font-weight:bold">Banyaknya Anggota DPRD Menurut
                        Partai Politik dan Jenis Kelamin di Kabupaten Soppeng, <?php echo e($data->tahun); ?></span></td>
            </tr>
            <tr>
                <td class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></td>
                <td class="tg-xxp7" colspan="2"><span style="font-weight:bold;font-style:italic">Number of
                        Regional
                        Parliaments Members by Poltical Party and Sex in Soppeng Regency, <?php echo e($data->tahun); ?></span>
                </td>
            </tr>
            <tr>
                <td class="tg-baqh" rowspan="2"><span style="font-style:normal;color:#000">Partai
                        Politik/</span><span style="font-style:italic;color:#000">Political Party</span></td>
                <td class="tg-nrix" colspan="3">Jenis Kelamin/Sex</td>
            </tr>
            <tr>
                <td class="tg-nrix">Laki-Laki/Men</td>
                <td class="tg-nrix">Perempuan/Women</td>
                <td class="tg-nrix">Jumlah/Total</td>
            </tr>
            <tr>
                <td class="tg-nrix">(1)</td>
                <td class="tg-nrix">(2)</td>
                <td class="tg-nrix">(3)</td>
                <td class="tg-nrix">(4)</td>
            </tr>
            <tr>
                <td class="tg-7zrl">Gerindra</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">2</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">3</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">Golkar</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">8</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">4</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">12</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">PDI-P</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">5</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">5</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">PPP</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">Demokrat</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">2</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">3</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">PAN</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">PKS</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">PKB</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">PBB</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">-</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">0</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl">Nasdem</td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">4</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">1</span></td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">5</span></td>
            </tr>
            <tr>
                <td class="tg-f4yw"><span style="background-color:#FFF">Jumlah/Total</span></td>
                <td class="tg-nrix">23</td>
                <td class="tg-nrix">7</td>
                <td class="tg-nrix">30</td>
            </tr>
        </tbody>
    </table>

<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <?php echo $__env->make('tabel.skpd.027_DPRD.script1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/027_DPRD/027001.blade.php ENDPATH**/ ?>