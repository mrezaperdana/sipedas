<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-bobw"><span style="font-weight:bold">Uraian</span></th>
                    
                    <th class="tg-kex3"><span style="font-weight:bold"><?php echo e($data->tahun); ?>

                        </span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-cly1">Jumlah Pengiriman</td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahpengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahpengiriman"
                            name="jumlahpengiriman" value="<?php echo e(old('jumlahpengiriman', $data->jumlahpengiriman)); ?>">
                        <?php $__errorArgs = ['jumlahpengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-cly1">Nilai Pengiriman</td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['nilaipengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nilaipengiriman"
                            name="nilaipengiriman" value="<?php echo e(old('nilaipengiriman', $data->nilaipengiriman)); ?>">
                        <?php $__errorArgs = ['nilaipengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-cly1">Jumlah Penerimaan</td>
                    
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahpenerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahpenerimaan"
                            name="jumlahpenerimaan" value="<?php echo e(old('jumlahpenerimaan', $data->jumlahpenerimaan)); ?>">
                        <?php $__errorArgs = ['jumlahpenerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>

    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-bobw"><span style="font-weight:bold">Uraian</span></th>
                <th class="tg-bobw"><span style="font-weight:bold">2021</span></th>
                <th class="tg-kex3"><span style="font-weight:bold">2022</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-cly1">Jumlah Pengiriman</td>
                <td class="tg-mwxe"><span style="font-weight:normal">34,747.00</span></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-cly1">Nilai Pengiriman</td>
                <td class="tg-mwxe"><span style="font-weight:normal">390,310,328.00</span></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-cly1">Jumlah Penerimaan</td>
                <td class="tg-mwxe"><span style="font-weight:normal">24,873.00</span></td>
                <td class="tg-7zrl"></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/POS/017001.blade.php ENDPATH**/ ?>