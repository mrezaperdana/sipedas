<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-amwm" rowspan="2">NO</th>
                    <th class="tg-amwm" rowspan="2">KOMODITAS</th>
                    <th class="tg-amwm" rowspan="2">WUJUD</th>
                    <th class="tg-wa1i" colspan="6"><span style="font-weight:bold">PRODUKSI PERIKANAN
                            2020-2022</span>
                    </th>
                </tr>
                <tr>
                    

                    <th class="tg-wa1i"><span style="font-weight:bold">2022 (Ton)</span></th>
                    <th class="tg-wa1i"><span style="font-weight:bold">NILAI 2022 (000)</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-wa1i"><span style="font-weight:bold">A</span></td>
                    <td class="tg-yla0"><span style="font-weight:bold">IKAN BUDIDAYA KOLAM</span></td>
                    <td class="tg-yla0"></td>
                    <td class="tg-cly1"></td>
                    <td class="tg-7zrl"></td>
                </tr>
                <tr>
                    <td class="tg-nrix">1</td>
                    <td class="tg-7zrl">IKAN MAS</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['awujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="awujud1" name="awujud1"
                            value="<?php echo e(old('awujud1', $data->awujud1)); ?>">
                        <?php $__errorArgs = ['awujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['aproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="aproduksi1"
                            name="aproduksi1" value="<?php echo e(old('aproduksi1', $data->aproduksi1)); ?>">
                        <?php $__errorArgs = ['aproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['anilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="anilai1" name="anilai1"
                            value="<?php echo e(old('anilai1', $data->anilai1)); ?>">
                        <?php $__errorArgs = ['anilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">2</td>
                    <td class="tg-7zrl">IKAN NILA</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['awujud2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="awujud2" name="awujud2"
                            value="<?php echo e(old('awujud2', $data->awujud2)); ?>">
                        <?php $__errorArgs = ['awujud2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['aproduksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="aproduksi2"
                            name="aproduksi2" value="<?php echo e(old('aproduksi2', $data->aproduksi2)); ?>">
                        <?php $__errorArgs = ['aproduksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['anilai2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="anilai2" name="anilai2"
                            value="<?php echo e(old('anilai2', $data->anilai2)); ?>">
                        <?php $__errorArgs = ['anilai2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">3</td>
                    <td class="tg-7zrl">IKAN LELE</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['awujud3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="awujud3" name="awujud3"
                            value="<?php echo e(old('awujud3', $data->awujud3)); ?>">
                        <?php $__errorArgs = ['awujud3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['aproduksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="aproduksi3"
                            name="aproduksi3" value="<?php echo e(old('aproduksi3', $data->aproduksi3)); ?>">
                        <?php $__errorArgs = ['aproduksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['anilai3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="anilai3" name="anilai3"
                            value="<?php echo e(old('anilai3', $data->anilai3)); ?>">
                        <?php $__errorArgs = ['anilai3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahproduksia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahproduksia"
                            name="jumlahproduksia" value="<?php echo e(old('jumlahproduksia', $data->jumlahproduksia)); ?>">
                        <?php $__errorArgs = ['jumlahproduksia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahnilaia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahnilaia"
                            name="jumlahnilaia" value="<?php echo e(old('jumlahnilaia', $data->jumlahnilaia)); ?>">
                        <?php $__errorArgs = ['jumlahnilaia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>

                </tr>
                <tr>
                    <td class="tg-wa1i"><span style="font-weight:bold">B</span></td>
                    <td class="tg-yla0"><span style="font-weight:bold">IKAN BUDIDAYA SAWAH (MINAPADI)</span></td>
                    <td class="tg-7zrl"></td>
                    <td class="tg-7zrl"></td>
                    <td class="tg-7zrl"></td>

                </tr>
                <tr>
                    <td class="tg-nrix">1</td>
                    <td class="tg-7zrl">IKAN MAS</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['bwujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bwujud1"
                            name="bwujud1" value="<?php echo e(old('bwujud1', $data->bwujud1)); ?>">
                        <?php $__errorArgs = ['bwujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['bproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bproduksi1"
                            name="bproduksi1" value="<?php echo e(old('bproduksi1', $data->bproduksi1)); ?>">
                        <?php $__errorArgs = ['bproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['bnilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bnilai1"
                            name="bnilai1" value="<?php echo e(old('bnilai1', $data->bnilai1)); ?>">
                        <?php $__errorArgs = ['bnilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahproduksib'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahproduksib"
                            name="jumlahproduksib" value="<?php echo e(old('jumlahproduksib', $data->jumlahproduksib)); ?>">
                        <?php $__errorArgs = ['jumlahproduksib'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahnilaib'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahnilaib"
                            name="jumlahnilaib" value="<?php echo e(old('jumlahnilaib', $data->jumlahnilaib)); ?>">
                        <?php $__errorArgs = ['jumlahnilaib'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>

                </tr>
                <tr>
                    <td class="tg-wa1i"><span style="font-weight:bold">C</span></td>
                    <td class="tg-yla0"><span style="font-weight:bold">IKAN BUDIDAYA KERAMBA (KJA)</span></td>
                    
                    <td class="tg-7zrl"></td>
                    <td class="tg-7zrl"></td>
                </tr>
                <tr>
                    <td class="tg-nrix">1</td>
                    <td class="tg-7zrl">IKAN NILA</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['cwujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="cwujud1"
                            name="cwujud1" value="<?php echo e(old('cwujud1', $data->cwujud1)); ?>">
                        <?php $__errorArgs = ['cwujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['cproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="cproduksi1"
                            name="cproduksi1" value="<?php echo e(old('cproduksi1', $data->cproduksi1)); ?>">
                        <?php $__errorArgs = ['cproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['cnilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="cnilai1"
                            name="cnilai1" value="<?php echo e(old('cnilai1', $data->cnilai1)); ?>">
                        <?php $__errorArgs = ['cnilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahproduksic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahproduksic"
                            name="jumlahproduksic" value="<?php echo e(old('jumlahproduksic', $data->jumlahproduksic)); ?>">
                        <?php $__errorArgs = ['jumlahproduksic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahnilaic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahnilaic"
                            name="jumlahnilaic" value="<?php echo e(old('jumlahnilaic', $data->jumlahnilaic)); ?>">
                        <?php $__errorArgs = ['jumlahnilaic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>

                </tr>
                <tr>
                    <td class="tg-wa1i"><span style="font-weight:bold">D</span></td>
                    <td class="tg-yla0"><span style="font-weight:bold">IKAN PERAIRAN UMUM DARATAN</span></td>
                    
                    <td class="tg-7zrl"></td>
                    <td class="tg-7zrl"></td>
                </tr>
                <tr>
                    <td class="tg-nrix">1</td>
                    <td class="tg-7zrl">IKAN MAS</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud1"
                            name="dwujud1" value="<?php echo e(old('dwujud1', $data->dwujud1)); ?>">
                        <?php $__errorArgs = ['dwujud1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi1"
                            name="dproduksi1" value="<?php echo e(old('dproduksi1', $data->dproduksi1)); ?>">
                        <?php $__errorArgs = ['dproduksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai1"
                            name="dnilai1" value="<?php echo e(old('dnilai1', $data->dnilai1)); ?>">
                        <?php $__errorArgs = ['dnilai1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">2</td>
                    <td class="tg-7zrl">IKAN NILA</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud2"
                            name="dwujud2" value="<?php echo e(old('dwujud2', $data->dwujud2)); ?>">
                        <?php $__errorArgs = ['dwujud2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi2"
                            name="dproduksi2" value="<?php echo e(old('dproduksi2', $data->dproduksi2)); ?>">
                        <?php $__errorArgs = ['dproduksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai2"
                            name="dnilai2" value="<?php echo e(old('dnilai2', $data->dnilai2)); ?>">
                        <?php $__errorArgs = ['dnilai2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">3</td>
                    <td class="tg-7zrl">IKAN LELE</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud3"
                            name="dwujud3" value="<?php echo e(old('dwujud3', $data->dwujud3)); ?>">
                        <?php $__errorArgs = ['dwujud3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi3"
                            name="dproduksi3" value="<?php echo e(old('dproduksi3', $data->dproduksi3)); ?>">
                        <?php $__errorArgs = ['dproduksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai3"
                            name="dnilai3" value="<?php echo e(old('dnilai3', $data->dnilai3)); ?>">
                        <?php $__errorArgs = ['dnilai3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">4</td>
                    <td class="tg-7zrl">BAWAL TAWAR</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud4"
                            name="dwujud4" value="<?php echo e(old('dwujud4', $data->dwujud4)); ?>">
                        <?php $__errorArgs = ['dwujud4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi4"
                            name="dproduksi4" value="<?php echo e(old('dproduksi4', $data->dproduksi4)); ?>">
                        <?php $__errorArgs = ['dproduksi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai4"
                            name="dnilai4" value="<?php echo e(old('dnilai4', $data->dnilai4)); ?>">
                        <?php $__errorArgs = ['dnilai4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">5</td>
                    <td class="tg-7zrl">BETOK</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud5"
                            name="dwujud5" value="<?php echo e(old('dwujud5', $data->dwujud5)); ?>">
                        <?php $__errorArgs = ['dwujud5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi5"
                            name="dproduksi5" value="<?php echo e(old('dproduksi5', $data->dproduksi5)); ?>">
                        <?php $__errorArgs = ['dproduksi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai5"
                            name="dnilai5" value="<?php echo e(old('dnilai5', $data->dnilai5)); ?>">
                        <?php $__errorArgs = ['dnilai5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">6</td>
                    <td class="tg-7zrl">BELUT</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud6"
                            name="dwujud6" value="<?php echo e(old('dwujud6', $data->dwujud6)); ?>">
                        <?php $__errorArgs = ['dwujud6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi6"
                            name="dproduksi6" value="<?php echo e(old('dproduksi6', $data->dproduksi6)); ?>">
                        <?php $__errorArgs = ['dproduksi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai6"
                            name="dnilai6" value="<?php echo e(old('dnilai6', $data->dnilai6)); ?>">
                        <?php $__errorArgs = ['dnilai6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">7</td>
                    <td class="tg-7zrl">SEPAT SIAM</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud7"
                            name="dwujud7" value="<?php echo e(old('dwujud7', $data->dwujud7)); ?>">
                        <?php $__errorArgs = ['dwujud7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi7"
                            name="dproduksi7" value="<?php echo e(old('dproduksi7', $data->dproduksi7)); ?>">
                        <?php $__errorArgs = ['dproduksi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai7"
                            name="dnilai7" value="<?php echo e(old('dnilai7', $data->dnilai7)); ?>">
                        <?php $__errorArgs = ['dnilai7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">8</td>
                    <td class="tg-7zrl">GABUS</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud8"
                            name="dwujud8" value="<?php echo e(old('dwujud8', $data->dwujud8)); ?>">
                        <?php $__errorArgs = ['dwujud8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi8"
                            name="dproduksi8" value="<?php echo e(old('dproduksi8', $data->dproduksi8)); ?>">
                        <?php $__errorArgs = ['dproduksi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai8"
                            name="dnilai8" value="<?php echo e(old('dnilai8', $data->dnilai8)); ?>">
                        <?php $__errorArgs = ['dnilai8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">9</td>
                    <td class="tg-7zrl">NILEM</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud9"
                            name="dwujud9" value="<?php echo e(old('dwujud9', $data->dwujud9)); ?>">
                        <?php $__errorArgs = ['dwujud9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi9"
                            name="dproduksi9" value="<?php echo e(old('dproduksi9', $data->dproduksi9)); ?>">
                        <?php $__errorArgs = ['dproduksi9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai9"
                            name="dnilai9" value="<?php echo e(old('dnilai9', $data->dnilai9)); ?>">
                        <?php $__errorArgs = ['dnilai9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">10</td>
                    <td class="tg-7zrl">TAWES</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud10"
                            name="dwujud10" value="<?php echo e(old('dwujud10', $data->dwujud10)); ?>">
                        <?php $__errorArgs = ['dwujud10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi10"
                            name="dproduksi10" value="<?php echo e(old('dproduksi10', $data->dproduksi10)); ?>">
                        <?php $__errorArgs = ['dproduksi10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai10"
                            name="dnilai10" value="<?php echo e(old('dnilai10', $data->dnilai10)); ?>">
                        <?php $__errorArgs = ['dnilai10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">11</td>
                    <td class="tg-7zrl">BETUTU</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud11"
                            name="dwujud11" value="<?php echo e(old('dwujud11', $data->dwujud11)); ?>">
                        <?php $__errorArgs = ['dwujud11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi11"
                            name="dproduksi11" value="<?php echo e(old('dproduksi11', $data->dproduksi11)); ?>">
                        <?php $__errorArgs = ['dproduksi11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai11"
                            name="dnilai11" value="<?php echo e(old('dnilai11', $data->dnilai11)); ?>">
                        <?php $__errorArgs = ['dnilai11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">12</td>
                    <td class="tg-cly1">ALAME</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud12"
                            name="dwujud12" value="<?php echo e(old('dwujud12', $data->dwujud12)); ?>">
                        <?php $__errorArgs = ['dwujud12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi12"
                            name="dproduksi12" value="<?php echo e(old('dproduksi12', $data->dproduksi12)); ?>">
                        <?php $__errorArgs = ['dproduksi12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai12"
                            name="dnilai12" value="<?php echo e(old('dnilai12', $data->dnilai12)); ?>">
                        <?php $__errorArgs = ['dnilai12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">13</td>
                    <td class="tg-cly1">PATIN</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud13"
                            name="dwujud13" value="<?php echo e(old('dwujud13', $data->dwujud13)); ?>">
                        <?php $__errorArgs = ['dwujud13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi13"
                            name="dproduksi13" value="<?php echo e(old('dproduksi13', $data->dproduksi13)); ?>">
                        <?php $__errorArgs = ['dproduksi13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai13"
                            name="dnilai13" value="<?php echo e(old('dnilai13', $data->dnilai13)); ?>">
                        <?php $__errorArgs = ['dnilai13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nrix">14</td>
                    <td class="tg-cly1">SIDAT</td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['dwujud14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dwujud14"
                            name="dwujud14" value="<?php echo e(old('dwujud14', $data->dwujud14)); ?>">
                        <?php $__errorArgs = ['dwujud14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dproduksi14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dproduksi14"
                            name="dproduksi14" value="<?php echo e(old('dproduksi14', $data->dproduksi14)); ?>">
                        <?php $__errorArgs = ['dproduksi14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['dnilai14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dnilai14"
                            name="dnilai14" value="<?php echo e(old('dnilai14', $data->dnilai14)); ?>">
                        <?php $__errorArgs = ['dnilai14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahproduksid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahproduksid"
                            name="jumlahproduksid" value="<?php echo e(old('jumlahproduksid', $data->jumlahproduksid)); ?>">
                        <?php $__errorArgs = ['jumlahproduksid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['jumlahnilaid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlahnilaid"
                            name="jumlahnilaid" value="<?php echo e(old('jumlahnilaid', $data->jumlahnilaid)); ?>">
                        <?php $__errorArgs = ['jumlahnilaid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-amwm" rowspan="2">NO</th>
                <th class="tg-amwm" rowspan="2">KOMODITAS</th>
                <th class="tg-amwm" rowspan="2">WUJUD</th>
                <th class="tg-wa1i" colspan="6"><span style="font-weight:bold">PRODUKSI PERIKANAN
                        2020-2022</span>
                </th>
            </tr>
            <tr>
                <th class="tg-wa1i"><span style="font-weight:bold">2020 (Ton)</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">NILAI 2020 (000)</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">2021 (Ton)</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">NILAI 2021 (000)</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">2022 (Ton)</span></th>
                <th class="tg-wa1i"><span style="font-weight:bold">NILAI 2022 (000)</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-wa1i"><span style="font-weight:bold">A</span></td>
                <td class="tg-yla0"><span style="font-weight:bold">IKAN BUDIDAYA KOLAM</span></td>
                <td class="tg-yla0"></td>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">1</td>
                <td class="tg-7zrl">IKAN MAS</td>
                <td class="tg-8d8j">IKAN HIDUP</td>
                <td class="tg-mwxe">74.22</td>
                <td class="tg-2b7s">&nbsp;&nbsp;2,226,630 </td>
                <td class="tg-mwxe">76.53</td>
                <td class="tg-2b7s">&nbsp;&nbsp;2,295,750 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">2</td>
                <td class="tg-7zrl">IKAN NILA</td>
                <td class="tg-8d8j">IKAN HIDUP</td>
                <td class="tg-2b7s">&nbsp;&nbsp;84.86 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;2,121,575 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;90.59 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;2,717,700 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">3</td>
                <td class="tg-7zrl">IKAN LELE</td>
                <td class="tg-8d8j">IKAN HIDUP</td>
                <td class="tg-2b7s">&nbsp;&nbsp;135.96 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;2,719,240 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;133.19 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;2,663,840 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>

            </tr>
            <tr>
                <td class="tg-wa1i"><span style="font-weight:bold">B</span></td>
                <td class="tg-yla0"><span style="font-weight:bold">IKAN BUDIDAYA SAWAH (MINAPADI)</span></td>
                <td class="tg-wa1i"></td>
                <td class="tg-cly1"></td>
                <td class="tg-cly1"></td>
                <td class="tg-cly1"></td>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">1</td>
                <td class="tg-7zrl">IKAN MAS</td>
                <td class="tg-8d8j">IKAN HIDUP</td>
                <td class="tg-mwxe">129.39</td>
                <td class="tg-2b7s">&nbsp;&nbsp;3,881,610 </td>
                <td class="tg-mwxe">135.35</td>
                <td class="tg-2b7s">&nbsp;&nbsp;4,060,470 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>

            </tr>
            <tr>
                <td class="tg-wa1i"><span style="font-weight:bold">C</span></td>
                <td class="tg-yla0"><span style="font-weight:bold">IKAN BUDIDAYA KERAMBA (KJA)</span></td>
                <td class="tg-wa1i"></td>
                <td class="tg-cly1"></td>
                <td class="tg-cly1"></td>
                <td class="tg-cly1"></td>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">1</td>
                <td class="tg-7zrl">IKAN NILA</td>
                <td class="tg-8d8j">IKAN HIDUP</td>
                <td class="tg-cly1">1.39</td>
                <td class="tg-2b7s">&nbsp;&nbsp;34,750 </td>
                <td class="tg-cly1">0.95</td>
                <td class="tg-2b7s">&nbsp;&nbsp;28,500 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>

            </tr>
            <tr>
                <td class="tg-wa1i"><span style="font-weight:bold">D</span></td>
                <td class="tg-yla0"><span style="font-weight:bold">IKAN PERAIRAN UMUM DARATAN</span></td>
                <td class="tg-wa1i"></td>
                <td class="tg-wa1i"></td>
                <td class="tg-wa1i"></td>
                <td class="tg-wa1i"></td>
                <td class="tg-wa1i"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">1</td>
                <td class="tg-7zrl">IKAN MAS</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;2.60 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;78,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;24.70 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;741,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">2</td>
                <td class="tg-7zrl">IKAN NILA</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;991.20 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;24,780,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;1,176.90 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;29,422,500 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">3</td>
                <td class="tg-7zrl">IKAN LELE</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;</td>
                <td class="tg-cly1"></td>
                <td class="tg-2b7s">&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;</td>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">4</td>
                <td class="tg-7zrl">BAWAL TAWAR</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-8d8j">&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;</td>
                <td class="tg-cly1"></td>
                <td class="tg-8d8j">&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;</td>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">5</td>
                <td class="tg-7zrl">BETOK</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;21.10 </td>
                <td class="tg-cly1">&nbsp;&nbsp;316,500 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;9.90 </td>
                <td class="tg-cly1">&nbsp;&nbsp;148,500 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">6</td>
                <td class="tg-7zrl">BELUT</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-8d8j">&nbsp;&nbsp;6.40 </td>
                <td class="tg-cly1">&nbsp;&nbsp;128,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;1.50 </td>
                <td class="tg-cly1">&nbsp;&nbsp;30,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">7</td>
                <td class="tg-7zrl">SEPAT SIAM</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;61.60 </td>
                <td class="tg-cly1">&nbsp;&nbsp;924,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;47.20 </td>
                <td class="tg-cly1">&nbsp;&nbsp;708,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">8</td>
                <td class="tg-7zrl">GABUS</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;56.30 </td>
                <td class="tg-cly1">&nbsp;&nbsp;1,689,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;44.40 </td>
                <td class="tg-cly1">&nbsp;&nbsp;1,332,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">9</td>
                <td class="tg-7zrl">NILEM</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-8d8j">&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;</td>
                <td class="tg-cly1"></td>
                <td class="tg-2b7s">&nbsp;&nbsp;26.10 </td>
                <td class="tg-cly1">&nbsp;&nbsp;391,500 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">10</td>
                <td class="tg-7zrl">TAWES</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;1,299.80 </td>
                <td class="tg-cly1">&nbsp;&nbsp;19,497,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;1,032.80 </td>
                <td class="tg-cly1">&nbsp;&nbsp;15,492,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">11</td>
                <td class="tg-7zrl">BETUTU</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;65.10 </td>
                <td class="tg-cly1">&nbsp;&nbsp;976,500 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;76.40 </td>
                <td class="tg-cly1">&nbsp;&nbsp;1,146,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">12</td>
                <td class="tg-cly1">ALAME</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-2b7s">&nbsp;&nbsp;12.90 </td>
                <td class="tg-cly1">&nbsp;&nbsp;258,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;9.90 </td>
                <td class="tg-cly1">&nbsp;&nbsp;198,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">13</td>
                <td class="tg-cly1">PATIN</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-8d8j">&nbsp;&nbsp;429.80 </td>
                <td class="tg-cly1">&nbsp;&nbsp;8,596,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;533.30 </td>
                <td class="tg-cly1">&nbsp;&nbsp;10,666,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">14</td>
                <td class="tg-cly1">SIDAT</td>
                <td class="tg-8d8j">IKAN SEGAR</td>
                <td class="tg-8d8j">&nbsp;&nbsp;11.10 </td>
                <td class="tg-cly1">&nbsp;&nbsp;888,000 </td>
                <td class="tg-2b7s">&nbsp;&nbsp;6.00 </td>
                <td class="tg-cly1">&nbsp;&nbsp;480,000 </td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-wa1i" colspan="3"><span style="font-weight:bold">JUMLAH</span></td>
                <td class="tg-kex3"><span style="font-weight:bold">&nbsp;&nbsp;2,957.90 </span></td>
                <td class="tg-cly1"></td>
                <td class="tg-kex3"><span style="font-weight:bold">&nbsp;&nbsp;2,989.10 </span></td>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>

<?php $__env->startSection('script'); ?>
    <script>
        function sumJumlahnilais() {
            var anilai1 = document.getElementById('anilai1').value || 0;
            var anilai2 = document.getElementById('anilai2').value || 0;
            var anilai3 = document.getElementById('anilai3').value || 0;
            var bnilai1 = document.getElementById('bnilai1').value || 0;
            var cnilai1 = document.getElementById('cnilai1').value || 0;
            var dnilai1 = document.getElementById('dnilai1').value || 0;
            var dnilai2 = document.getElementById('dnilai2').value || 0;
            var dnilai3 = document.getElementById('dnilai3').value || 0;
            var dnilai4 = document.getElementById('dnilai4').value || 0;
            var dnilai5 = document.getElementById('dnilai5').value || 0;
            var dnilai6 = document.getElementById('dnilai6').value || 0;
            var dnilai7 = document.getElementById('dnilai7').value || 0;
            var dnilai8 = document.getElementById('dnilai8').value || 0;
            var dnilai9 = document.getElementById('dnilai9').value || 0;
            var dnilai10 = document.getElementById('dnilai10').value || 0;
            var dnilai11 = document.getElementById('dnilai11').value || 0;
            var dnilai12 = document.getElementById('dnilai12').value || 0;
            var dnilai13 = document.getElementById('dnilai13').value || 0;
            var dnilai14 = document.getElementById('dnilai14').value || 0;



            var jumlahnilaiSuma = parseInt(anilai1) + parseInt(anilai2) + parseInt(anilai3);

            var jumlahnilaiSumb = parseInt(bnilai1);

            var jumlahnilaiSumc = parseInt(cnilai1);

            var jumlahnilaiSumd = parseInt(dnilai1) + parseInt(dnilai2) + parseInt(dnilai3) + parseInt(dnilai4) + parseInt(
                dnilai5) + parseInt(dnilai6) + parseInt(dnilai7) + parseInt(dnilai8) + parseInt(dnilai9) + parseInt(
                dnilai10) + parseInt(dnilai11) + parseInt(dnilai12) + parseInt(dnilai13) + parseInt(dnilai14);

            document.getElementById('jumlahnilaia').value = jumlahnilaiSuma;
            document.getElementById('jumlahnilaib').value = jumlahnilaiSumb;
            document.getElementById('jumlahnilaic').value = jumlahnilaiSumc;
            document.getElementById('jumlahnilaid').value = jumlahnilaiSumd;



        }

        var variables = ['anilai1', 'anilai2', 'anilai3', 'bnilai1', 'cnilai1', 'dnilai1', 'dnilai2', 'dnilai3',
            'dnilai4',
            'dnilai5', 'dnilai6', 'dnilai7', 'dnilai8', 'dnilai9', 'dnilai10', 'dnilai11', 'dnilai12', 'dnilai13',
            'dnilai14'
        ];

        variables.forEach(function(variable) {
            document.getElementById(variable).addEventListener('focusout', sumJumlahnilais);
        });
    </script>

    <script>
        function sumJumlahproduksis() {
            var aproduksi1 = document.getElementById('aproduksi1').value || 0;
            var aproduksi2 = document.getElementById('aproduksi2').value || 0;
            var aproduksi3 = document.getElementById('aproduksi3').value || 0;
            var bproduksi1 = document.getElementById('bproduksi1').value || 0;
            var cproduksi1 = document.getElementById('cproduksi1').value || 0;
            var dproduksi1 = document.getElementById('dproduksi1').value || 0;
            var dproduksi2 = document.getElementById('dproduksi2').value || 0;
            var dproduksi3 = document.getElementById('dproduksi3').value || 0;
            var dproduksi4 = document.getElementById('dproduksi4').value || 0;
            var dproduksi5 = document.getElementById('dproduksi5').value || 0;
            var dproduksi6 = document.getElementById('dproduksi6').value || 0;
            var dproduksi7 = document.getElementById('dproduksi7').value || 0;
            var dproduksi8 = document.getElementById('dproduksi8').value || 0;
            var dproduksi9 = document.getElementById('dproduksi9').value || 0;
            var dproduksi10 = document.getElementById('dproduksi10').value || 0;
            var dproduksi11 = document.getElementById('dproduksi11').value || 0;
            var dproduksi12 = document.getElementById('dproduksi12').value || 0;
            var dproduksi13 = document.getElementById('dproduksi13').value || 0;
            var dproduksi14 = document.getElementById('dproduksi14').value || 0;

            var jumlahproduksiSuma = parseInt(aproduksi1) + parseInt(aproduksi2) + parseInt(aproduksi3);

            var jumlahproduksiSumb = parseInt(bproduksi1);

            var jumlahproduksiSumc = parseInt(cproduksi1);

            var jumlahproduksiSumd = parseInt(dproduksi1) + parseInt(dproduksi2) + parseInt(dproduksi3) + parseInt(
                dproduksi4) + parseInt(
                dproduksi5) + parseInt(dproduksi6) + parseInt(dproduksi7) + parseInt(dproduksi8) + parseInt(
                dproduksi9) + parseInt(
                dproduksi10) + parseInt(dproduksi11) + parseInt(dproduksi12) + parseInt(dproduksi13) + parseInt(
                dproduksi14);

            document.getElementById('jumlahproduksia').value = jumlahproduksiSuma;
            document.getElementById('jumlahproduksib').value = jumlahproduksiSumb;
            document.getElementById('jumlahproduksic').value = jumlahproduksiSumc;
            document.getElementById('jumlahproduksid').value = jumlahproduksiSumd;
        }

        var variables = ['aproduksi1', 'aproduksi2', 'aproduksi3', 'bproduksi1', 'cproduksi1', 'dproduksi1',
            'dproduksi2',
            'dproduksi3', 'dproduksi4',
            'dproduksi5', 'dproduksi6', 'dproduksi7', 'dproduksi8', 'dproduksi9', 'dproduksi10', 'dproduksi11',
            'dproduksi12', 'dproduksi13',
            'dproduksi14'
        ];

        variables.forEach(function(variable) {
            document.getElementById(variable).addEventListener('focusout', sumJumlahproduksis);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/Perikanan/013001.blade.php ENDPATH**/ ?>