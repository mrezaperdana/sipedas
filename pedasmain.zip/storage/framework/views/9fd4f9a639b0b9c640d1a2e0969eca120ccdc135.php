<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-bobw" colspan="5"><span style="font-weight:bold">PSB POTS/ SPEEDY</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-bobw"><span style="font-weight:bold">Bulan</span></td>

                    <td class="tg-bobw"><span style="font-weight:bold"><?php echo e($data->tahun); ?></span></td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Januari</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy1" name="speedy1"
                            value="<?php echo e(old('speedy1', $data->speedy1)); ?>">
                        <?php $__errorArgs = ['speedy1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Februari</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy2" name="speedy2"
                            value="<?php echo e(old('speedy2', $data->speedy2)); ?>">
                        <?php $__errorArgs = ['speedy2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Maret</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy3" name="speedy3"
                            value="<?php echo e(old('speedy3', $data->speedy3)); ?>">
                        <?php $__errorArgs = ['speedy3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">April</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy4" name="speedy4"
                            value="<?php echo e(old('speedy4', $data->speedy4)); ?>">
                        <?php $__errorArgs = ['speedy4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Mei</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy5" name="speedy5"
                            value="<?php echo e(old('speedy5', $data->speedy5)); ?>">
                        <?php $__errorArgs = ['speedy5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Juni</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy6" name="speedy6"
                            value="<?php echo e(old('speedy6', $data->speedy6)); ?>">
                        <?php $__errorArgs = ['speedy6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Juli</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy7" name="speedy7"
                            value="<?php echo e(old('speedy7', $data->speedy7)); ?>">
                        <?php $__errorArgs = ['speedy7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Agustus</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy8" name="speedy8"
                            value="<?php echo e(old('speedy8', $data->speedy8)); ?>">
                        <?php $__errorArgs = ['speedy8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">September</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy9" name="speedy9"
                            value="<?php echo e(old('speedy9', $data->speedy9)); ?>">
                        <?php $__errorArgs = ['speedy9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Oktober</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy10" name="speedy10"
                            value="<?php echo e(old('speedy10', $data->speedy10)); ?>">
                        <?php $__errorArgs = ['speedy10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">November</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy11"
                            name="speedy11" value="<?php echo e(old('speedy11', $data->speedy11)); ?>">
                        <?php $__errorArgs = ['speedy11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Desember</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedy12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedy12"
                            name="speedy12" value="<?php echo e(old('speedy12', $data->speedy12)); ?>">
                        <?php $__errorArgs = ['speedy12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-bobw"><span style="font-weight:bold">Jumlah</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['speedyt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="speedyt"
                            name="speedyt" value="<?php echo e(old('speedyt', $data->speedyt)); ?>">
                        <?php $__errorArgs = ['speedyt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-bobw" colspan="5"><span style="font-weight:bold">PSB POTS/ SPEEDY</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-bobw"><span style="font-weight:bold">Bulan</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2018</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2019</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2020</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2021</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Januari</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Februari</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Maret</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">April</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Mei</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Juni</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Juli</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Agustus</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">September</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Oktober</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">November</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Desember</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-bobw"><span style="font-weight:bold">Jumlah</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <script>
        function sumSpeedys() {
            var speedyElements = document.querySelectorAll('[id^="speedy"]');
            var speedySum = 0;
            for (var i = 0; i < speedyElements.length; i++) {
                if (speedyElements[i].id !== "speedyt") {
                    var speedyValue = parseFloat(speedyElements[i].value) || 0;
                    speedySum += speedyValue;
                }
            }
            document.getElementById('speedyt').value = speedySum;
        }

        var speedyInputs = document.querySelectorAll('[id^="speedy"]');
        for (var i = 0; i < speedyInputs.length; i++) {
            speedyInputs[i].addEventListener('focusout', sumSpeedys);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/048_Telkom_Cangadi/048011.blade.php ENDPATH**/ ?>