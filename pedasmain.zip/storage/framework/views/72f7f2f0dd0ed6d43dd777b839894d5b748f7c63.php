<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                    <th class="tg-amwm" rowspan="2">2.4.1</th>
                    <th class="tg-yla0"><span style="font-weight:bold">Perbandingan Realisasi Penerimaan dan Pengeluaran
                            Pemerintah di Kabupaten Soppeng (Rupiah), <?php echo e($data->tahun); ?></span></th>
                </tr>
                <tr>
                    <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                    <th class="tg-sn55"><span style="font-weight:bold;font-style:italic">Comparison of Actual Government
                            Revenues and Expenditurers in Soppeng Regency (Rupiahs), <?php echo e($data->tahun); ?></span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-cly1"></td>
                    <td class="tg-7zrl"></td>
                    <td class="tg-7zrl"></td>
                </tr>
                <tr>
                    <td class="tg-nrix">Tahun / Years</td>
                    <td class="tg-nrix">Penerimaan / Revenues</td>
                    <td class="tg-nrix">Pengeluaran / Expenditures</td>
                </tr>

                <tr>
                    <td class="tg-nrix">(1)</td>
                    <td class="tg-nrix">(2)</td>
                    <td class="tg-nrix">(3)</td>
                </tr>
                <tr>
                    <td class="tg-nrix"><?php echo e($data->tahun); ?></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['penerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="penerimaan"
                            name="penerimaan" value="<?php echo e(old('penerimaan', $data->penerimaan)); ?>">
                        <?php $__errorArgs = ['penerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>

                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pengeluaran"
                            name="pengeluaran" value="<?php echo e(old('pengeluaran', $data->pengeluaran)); ?>">
                        <?php $__errorArgs = ['pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>

            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                <th class="tg-amwm" rowspan="2">2.4.1</th>
                <th class="tg-yla0"><span style="font-weight:bold">Perbandingan Realisasi Penerimaan dan Pengeluaran
                        Pemerintah di Kabupaten Soppeng (Rupiah), <?php echo e($data->tahun); ?></span></th>
            </tr>
            <tr>
                <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                <th class="tg-sn55"><span style="font-weight:bold;font-style:italic">Comparison of Actual Government
                        Revenues and Expenditurers in Soppeng Regency (Rupiahs), <?php echo e($data->tahun); ?></span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-cly1"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-nrix">Tahun /</td>
                <td class="tg-nrix">Penerimaan /</td>
                <td class="tg-nrix">Pengeluaran /</td>
            </tr>
            <tr>
                <td class="tg-lhti"><span style="font-style:italic">Years</span></td>
                <td class="tg-lhti"><span style="font-style:italic">Revenues</span></td>
                <td class="tg-lhti"><span style="font-style:italic">Expenditures</span></td>
            </tr>
            <tr>
                <td class="tg-nrix">(1)</td>
                <td class="tg-nrix">(2)</td>
                <td class="tg-nrix">(3)</td>
            </tr>
            <tr>
                <td class="tg-nrix"><?php echo e($data->tahun); ?></td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;817,856,582,025 </span></td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;751,476,161,605 </span></td>
            </tr>
            <tr>
                <td class="tg-nrix">2015</td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;912,814,997,983 </span></td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;850,297,715,044 </span></td>
            </tr>
            <tr>
                <td class="tg-nrix">2016</td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;1,236,893,800,959 </span></td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;1,002,459,449,170 </span></td>
            </tr>
            <tr>
                <td class="tg-nrix">2017</td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;1,155,718,382,299 </span></td>
                <td class="tg-f4yw"><span style="background-color:#FFF">&nbsp;&nbsp;1,141,423,783,213 </span></td>
            </tr>
            <tr>
                <td class="tg-nrix">2018</td>
                <td class="tg-nrix">&nbsp;&nbsp;1,156,095,496,077 </td>
                <td class="tg-nrix">&nbsp;&nbsp;1,152,398,350,007 </td>
            </tr>
            <tr>
                <td class="tg-nrix">2019</td>
                <td class="tg-nrix">&nbsp;&nbsp;1,215,328,628,941 </td>
                <td class="tg-nrix">&nbsp;&nbsp;1,189,972,761,947 </td>
            </tr>
            <tr>
                <td class="tg-nrix">2020</td>
                <td class="tg-nrix">&nbsp;&nbsp;1,202,470,518,866 </td>
                <td class="tg-nrix">&nbsp;&nbsp;1,251,860,939,170 </td>
            </tr>
            <tr>
                <td class="tg-nrix">2021</td>
                <td class="tg-nrix">&nbsp;&nbsp;1,211,846,653,202 </td>
                <td class="tg-nrix">&nbsp;&nbsp;1,895,366,790,876 </td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/024_BPKPD/024001.blade.php ENDPATH**/ ?>