<?php if(!empty($data)): ?>

    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-7zrl">No</th>
                    <th class="tg-7zrl">Komoditas</th>
                    <th class="tg-7zrl">Satuan</th>
                    
                    <th class="tg-8d8j"><?php echo e($data->tahun); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-8d8j">1</td>
                    <td class="tg-7zrl">Sapi Potong</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi1"
                            name="produksi1" value="<?php echo e(old('produksi1', $data->produksi1)); ?>">
                        <?php $__errorArgs = ['produksi1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">2</td>
                    <td class="tg-7zrl">Sapi Perah</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi2"
                            name="produksi2" value="<?php echo e(old('produksi2', $data->produksi2)); ?>">
                        <?php $__errorArgs = ['produksi2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">3</td>
                    <td class="tg-7zrl">Kerbau</td>
                    <td class="tg-7zrl">Kg</td>
                    < <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi3"
                            name="produksi3" value="<?php echo e(old('produksi3', $data->produksi3)); ?>">
                        <?php $__errorArgs = ['produksi3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">4</td>
                    <td class="tg-7zrl">Kambing</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi4"
                            name="produksi4" value="<?php echo e(old('produksi4', $data->produksi4)); ?>">
                        <?php $__errorArgs = ['produksi4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">5</td>
                    <td class="tg-7zrl">Domba</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi5"
                            name="produksi5" value="<?php echo e(old('produksi5', $data->produksi5)); ?>">
                        <?php $__errorArgs = ['produksi5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">6</td>
                    <td class="tg-7zrl">Babi</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi6"
                            name="produksi6" value="<?php echo e(old('produksi6', $data->produksi6)); ?>">
                        <?php $__errorArgs = ['produksi6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">7</td>
                    <td class="tg-7zrl">Kuda</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi7"
                            name="produksi7" value="<?php echo e(old('produksi7', $data->produksi7)); ?>">
                        <?php $__errorArgs = ['produksi7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                <tr>
                    <td class="tg-8d8j">8</td>
                    <td class="tg-7zrl">Ayam Buras</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi8"
                            name="produksi8" value="<?php echo e(old('produksi8', $data->produksi8)); ?>">
                        <?php $__errorArgs = ['produksi8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">9</td>
                    <td class="tg-7zrl">Ayam Ras Pedaging</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi9"
                            name="produksi9" value="<?php echo e(old('produksi9', $data->produksi9)); ?>">
                        <?php $__errorArgs = ['produksi9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">10</td>
                    <td class="tg-7zrl">Ayam ras petelur</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi10"
                            name="produksi10" value="<?php echo e(old('produksi10', $data->produksi10)); ?>">
                        <?php $__errorArgs = ['produksi10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">11</td>
                    <td class="tg-7zrl">Itik</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi11"
                            name="produksi11" value="<?php echo e(old('produksi11', $data->produksi11)); ?>">
                        <?php $__errorArgs = ['produksi11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">12</td>
                    <td class="tg-7zrl">Kelinci</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi12"
                            name="produksi12" value="<?php echo e(old('produksi12', $data->produksi12)); ?>">
                        <?php $__errorArgs = ['produksi12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">13</td>
                    <td class="tg-7zrl">Burung puyuh</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi13"
                            name="produksi13" value="<?php echo e(old('produksi13', $data->produksi13)); ?>">
                        <?php $__errorArgs = ['produksi13'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">14</td>
                    <td class="tg-7zrl">Merpati</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi14"
                            name="produksi14" value="<?php echo e(old('produksi14', $data->produksi14)); ?>">
                        <?php $__errorArgs = ['produksi14'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">15</td>
                    <td class="tg-7zrl">Telur Ayam buras</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi15'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi15"
                            name="produksi15" value="<?php echo e(old('produksi15', $data->produksi15)); ?>">
                        <?php $__errorArgs = ['produksi15'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">16</td>
                    <td class="tg-7zrl">Telur Ayam Ras Petelur</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi16'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi16"
                            name="produksi16" value="<?php echo e(old('produksi16', $data->produksi16)); ?>">
                        <?php $__errorArgs = ['produksi16'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">17</td>
                    <td class="tg-7zrl">Telur Itik</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi17'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi17"
                            name="produksi17" value="<?php echo e(old('produksi17', $data->produksi17)); ?>">
                        <?php $__errorArgs = ['produksi17'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">18</td>
                    <td class="tg-7zrl">Telur burung puyuh</td>
                    <td class="tg-7zrl">Kg</td>

                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi18'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi18"
                            name="produksi18" value="<?php echo e(old('produksi18', $data->produksi18)); ?>">
                        <?php $__errorArgs = ['produksi18'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">19</td>
                    <td class="tg-7zrl">Tulang sapi</td>
                    <td class="tg-7zrl">Kg</td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi19'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi19"
                            name="produksi19" value="<?php echo e(old('produksi19', $data->produksi19)); ?>">
                        <?php $__errorArgs = ['produksi19'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">20</td>
                    <td class="tg-7zrl">Kulit sapi</td>
                    <td class="tg-7zrl">Lembar</td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi20'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi20"
                            name="produksi20" value="<?php echo e(old('produksi20', $data->produksi20)); ?>">
                        <?php $__errorArgs = ['produksi20'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">21</td>
                    <td class="tg-7zrl">Kulit Kambing</td>
                    <td class="tg-7zrl">Lembar</td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi21'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi21"
                            name="produksi21" value="<?php echo e(old('produksi21', $data->produksi21)); ?>">
                        <?php $__errorArgs = ['produksi21'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-8d8j">22</td>
                    <td class="tg-7zrl">Kelinci</td>
                    <td class="tg-7zrl">Hewan</td>
                    <td class="tg-cly1"><input type="number" step="0.01"
                            class="form-control <?php $__errorArgs = ['produksi22'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="produksi22"
                            name="produksi22" value="<?php echo e(old('produksi22', $data->produksi22)); ?>">
                        <?php $__errorArgs = ['produksi22'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>

        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>

    </form>
<?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-7zrl">No</th>
                <th class="tg-7zrl">Komoditas</th>
                <th class="tg-7zrl">Satuan</th>
                <th class="tg-8d8j">2021</th>
                <th class="tg-8d8j"><?php echo e($data->tahun); ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-8d8j">1</td>
                <td class="tg-7zrl">Sapi Potong</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">679,052.44</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">2</td>
                <td class="tg-7zrl">Sapi Perah</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">0.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">3</td>
                <td class="tg-7zrl">Kerbau</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">0.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">4</td>
                <td class="tg-7zrl">Kambing</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">78,885.40</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">5</td>
                <td class="tg-7zrl">Domba</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">0.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">6</td>
                <td class="tg-7zrl">Babi</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">0.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">7</td>
                <td class="tg-7zrl">Kuda</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">33,750.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">8</td>
                <td class="tg-7zrl">Ayam Buras</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">252,468.37</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">9</td>
                <td class="tg-7zrl">Ayam Ras Pedaging</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">449,475.60</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">10</td>
                <td class="tg-7zrl">Ayam ras petelur</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">21,960.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">11</td>
                <td class="tg-7zrl">Itik</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">31,134.96</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">12</td>
                <td class="tg-7zrl">Kelinci</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">412.34</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">13</td>
                <td class="tg-7zrl">Burung puyuh</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">52.03</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">14</td>
                <td class="tg-7zrl">Merpati</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">0.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">15</td>
                <td class="tg-7zrl">Telur Ayam buras</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">2,266,365.26</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">16</td>
                <td class="tg-7zrl">Telur Ayam Ras Petelur</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">7,794,973.17</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">17</td>
                <td class="tg-7zrl">Telur Itik</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">1,432,547.66</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">18</td>
                <td class="tg-7zrl">Telur burung puyuh</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">4,644.63</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">19</td>
                <td class="tg-7zrl">Tulang sapi</td>
                <td class="tg-7zrl">Kg</td>
                <td class="tg-2b7s">69,780.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">20</td>
                <td class="tg-7zrl">Kulit sapi</td>
                <td class="tg-7zrl">Lembar</td>
                <td class="tg-2b7s">4,652.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">21</td>
                <td class="tg-7zrl">Kulit Kambing</td>
                <td class="tg-7zrl">Lembar</td>
                <td class="tg-2b7s">6,236.00</td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-8d8j">22</td>
                <td class="tg-7zrl">Kelinci</td>
                <td class="tg-7zrl">Hewan</td>
                <td class="tg-2b7s">18.08</td>
                <td class="tg-7zrl"></td>
            </tr>
        </tbody>

    </table>

<?php endif; ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/Peternakan/015001.blade.php ENDPATH**/ ?>