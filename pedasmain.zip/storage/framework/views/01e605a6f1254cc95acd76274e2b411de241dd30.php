
<?php $__env->startSection('title', 'Daftar Tabel'); ?>
<?php $__env->startSection('head'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>


        </div>
    <?php endif; ?>

    <script>
        // Automatically dismiss alerts after 5 seconds
        setTimeout(function() {
            $('.alert-dismissible').alert('close');
        }, 5000);
    </script>

    <!-- Content Wrapper. Contains page content -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Daftar Tabel yang sudah dan belum diisi.</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- Add a dropdown menu with the options for filtering -->
                        <div class="card-body">
                            <label for="filter">Filter Tahun:</label>
                            <div class="form-group form-inline">
                                <div class="row-md-2">
                                    <label for="filter">Awal</label>
                                    <select class="form-control" id="filter-start">
                                        <option value="">Semua</option>
                                        <?php $__currentLoopData = $listtahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tahun); ?>"><?php echo e($tahun); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <p>-</p>
                                <div class="row-md-2">
                                    <label for="filter">Akhir</label>
                                    <select class="form-control" id="filter-end">
                                        <option value="">Semua</option>
                                        <?php $__currentLoopData = $listtahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tahun); ?>"><?php echo e($tahun); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="overlay hidden">
                                <i class="fas fa-2x fa-sync-alt fa-spin"></i>
                            </div>
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Judul</th>
                                        <th>Tahun</th>
                                        <th>Kodetabel</th>
                                        <th>Status</th>
                                        <th>Template</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="table-body">
                                    <?php $__currentLoopData = $datakegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allItemss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td></td>
                                            <td><?php echo e($allItemss->judul); ?></td>
                                            <td><?php echo e($allItemss->tahun); ?></td>
                                            <td><?php echo e($allItemss->kodetabel); ?></td>
                                            <td>
                                                <?php if($allItemss->status_entri == 1): ?>
                                                    File Terunggah.
                                                <?php else: ?>
                                                    Belum Unggah.
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($allItemss->templatename): ?>
                                                    <a href="<?php echo e(route('downloadEntriExcel', $allItemss->kodetabel)); ?>">Download
                                                        File</a>
                                                <?php else: ?>
                                                    Belum tersedia
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                                    data-target="#uploadModal<?php echo e($allItemss->id); ?>">Upload</button>
                                            </td>
                                        </tr>

                                        <!-- Upload Modal -->
                                        <div class="modal fade" id="uploadModal<?php echo e($allItemss->id); ?>" tabindex="-1"
                                            role="dialog" aria-labelledby="uploadModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <form action="<?php echo e(route('UserUploadEntriexcel', $allItemss->id)); ?>"
                                                        method="POST" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="uploadModalLabel">Upload File</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="kodetabel"
                                                                value="<?php echo e($allItemss->kodetabel); ?>">
                                                            <div class="form-group">
                                                                <label for="file">Select file:</label>
                                                                <input type="file" name="file"
                                                                    class="form-control-file" required>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-primary">Upload</button>
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Close</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- DataTables  & Plugins -->
    <script src="/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="/plugins/jszip/jszip.min.js"></script>
    <script src="/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <!-- Page specific script -->
    <script>
        $(document).ready(function() {
            $('.overlay').removeClass('hidden');
            $('#table-body').on('DOMSubtreeModified', function() {
                if ($(this).children().length > 0) {
                    $('.overlay').hide();
                }
            });
            // Initialize the DataTable
            let columnIndex = 3;
            var t = $('#example1').DataTable().order([columnIndex, 'asc']).draw();
            // Filter the table when an option is selected in the dropdown
            $('#filter-start').on('change', function() {
                var startYear = $(this).val();
                var endYear = $('#filter-end').val();

                // Check if both start year and end year are selected
                if (startYear && endYear) {
                    // Create a regular expression that matches the range of years
                    var regex = '^(' + startYear + '|' + endYear + ')';
                    for (var i = startYear; i < endYear; i++) {
                        regex += '|' + i;
                    }
                    regex += '$';

                    // Use the regular expression to filter the table
                    $('#example1').DataTable().column(1).search(regex, true, false).draw();
                }
            });
            t.on('order.dt search.dt', function() {
                let i = 1;

                t.cells(null, 0, {
                    search: 'applied',
                    order: 'applied'
                }).every(function(cell) {
                    this.data(i++);
                });
            }).draw();

            $('#filter-end').on('change', function() {
                // Use the same logic as in the change event for the start year dropdown
                $('#filter-start').trigger('change');
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.users.layouts.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\pedas\resources\views/dashboard/users/entriexcel/entriexcel.blade.php ENDPATH**/ ?>