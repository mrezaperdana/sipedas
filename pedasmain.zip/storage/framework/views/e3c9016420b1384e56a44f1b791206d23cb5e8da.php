<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Tabel</th>
                    <th rowspan="2">2.2.9</th>
                    <th colspan="2"><?php echo e($judultabel); ?>, <?php echo e($data->tahun); ?></th>

                </tr>
                <tr>
                    <th>Table</th>
                    <th colspan="2"><?php echo e($judultabelen); ?>, <?php echo e($data->tahun); ?>

                    </th>

                </tr>
            </thead>
            <tbody>

                <tr>
                    <td rowspan="2" colspan="2">Kegiatan/Activity</td>
                    <td colspan="5">Tahun/Year</td>
                </tr>

                <tr>
                    <td><?php echo e($data->tahun); ?></td>
                </tr>
                <tr>
                    <td colspan="2">(1)</td>
                    <td>(2)</td>

                </tr>
                <tr>
                    <td colspan="2">Demonstrasi/Demonstration</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['demonstrasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="demonstrasi"
                            name="demonstrasi" value="<?php echo e(old('demonstrasi', $data->demonstrasi)); ?>">
                        <?php $__errorArgs = ['demonstrasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">Aspirasi/Aspiration</td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['aspirasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="aspirasi" name="aspirasi"
                            value="<?php echo e(old('aspirasi', $data->aspirasi)); ?>">
                        <?php $__errorArgs = ['aspirasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">Jumlah/Total</td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="total" name="total" value="<?php echo e(old('total', $data->total)); ?>">
                        <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tabel</th>
                <th rowspan="2">2.2.9</th>
                <th colspan="2">Jumlah Demonstrasi dan Penyampaian Aspirasi di Kabupaten Soppeng, 2018-2022</th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <th>Table</th>
                <th colspan="2">Number of Demonstrations and Delivery of Aspirations in Soppeng Regency, 2018-2022
                </th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td rowspan="3">Kegiatan/Activity</td>
                <td colspan="5">Tahun/</td>
            </tr>
            <tr>
                <td colspan="5">Year</td>
            </tr>
            <tr>
                <td>2018</td>
                <td>2019</td>
                <td>2020</td>
                <td>2021</td>
                <td>2022</td>
            </tr>
            <tr>
                <td colspan="2">(1)</td>
                <td>(3)</td>
                <td>(4)</td>
                <td>(5)</td>
                <td>(6)</td>
            </tr>
            <tr>
                <td colspan="2">Demonstrasi/Demonstration</td>
                <td>3</td>
                <td>3</td>
                <td>1</td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Aspirasi/Aspiration</td>
                <td>4</td>
                <td>4</td>
                <td>2</td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Jumlah/Total</td>
                <td>7</td>
                <td>7</td>
                <td>3</td>
                <td>0</td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <script>
        var myList = ["a", "b", "c"];

        function sumValues() {
            var valueSum = 0;
            for (var i = 0; i < myList.length; i++) {
                var valueElements = document.querySelectorAll('[id^="' + myList[i] + '"]');
                for (var j = 0; j < valueElements.length; j++) {
                    var valueValue = parseFloat(valueElements[j].value) || 0;
                    valueSum += valueValue;
                }
            }
            document.getElementById('valuet').value = valueSum;
        }

        for (var i = 0; i < myList.length; i++) {
            var valueInputs = document.querySelectorAll('[id^="' + myList[i] + '"]');
            for (var j = 0; j < valueInputs.length; j++) {
                valueInputs[j].addEventListener('focusout', sumValues);
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/020_Kesbangpol/020005.blade.php ENDPATH**/ ?>