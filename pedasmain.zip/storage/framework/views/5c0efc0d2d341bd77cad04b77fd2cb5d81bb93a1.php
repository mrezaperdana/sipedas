<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p> <?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                    <th class="tg-wa1i"><span style="font-weight:bold">Jumlah Obyek Pemeriksaan berdasarkan NON PPKT
                            menurut Jenis Sasaran, 2021</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></td>
                    <td class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Number of&nbsp;&nbsp;Non Annual
                            Supervision Work Program Inspection Object by Kind of Target, 2021</span></td>
                </tr>

                <tr>
                    <td class="tg-amwm"><span style="font-weight:bold;font-style:normal;color:#000">Uraian /
                        </span><span style="font-weight:bold;font-style:italic;color:#000">Description</span></td>
                    <td class="tg-nrix">2021 </td>
                </tr>
                <tr>
                    <td class="tg-wa1i"><span style="font-weight:bold">(1)</span></td>
                    <td class="tg-wa1i"><span style="font-weight:bold">(2)</span></td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Pengaduan Masyarakat yang Diajukan
                            kepada BKDH Kabupaten Soppeng / </span><span style="font-style:italic;color:#000">Community
                            Complaints Filed with BKDH Soppeng Regency</span></td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['obyek1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="obyek1" name="obyek1" value="<?php echo e(old('obyek1', $data->obyek1)); ?>">
                        <?php $__errorArgs = ['obyek1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Pengaduan Melalui Tromol Pos 5000 /
                        </span><span style="font-style:italic;color:#000">Accusation Pass PO BOX 5000</span></td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['obyek2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="obyek2" name="obyek2" value="<?php echo e(old('obyek2', $data->obyek2)); ?>">
                        <?php $__errorArgs = ['obyek2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Pelanggaran Disiplin Pegawai /
                        </span><span style="font-style:italic;color:#000">Transgression Civil Servant</span></td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['obyek3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="obyek3" name="obyek3" value="<?php echo e(old('obyek3', $data->obyek3)); ?>">
                        <?php $__errorArgs = ['obyek3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Peng1an Pejabat dalam Lingkungan
                            Pemerintah Daerah / </span><span style="font-style:italic;color:#000">Employee Subtitute in
                            Regency Goverment</span></td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['obyek4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="obyek4" name="obyek4" value="<?php echo e(old('obyek4', $data->obyek4)); ?>">
                        <?php $__errorArgs = ['obyek4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal;color:#000">Proyek Inpres Daerah Kab. Soppeng /
                        </span><span style="font-style:italic;color:#000">Soppeng Regency Regional Inpres Project</span>
                    </td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['obyek5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="obyek5" name="obyek5" value="<?php echo e(old('obyek5', $data->obyek5)); ?>">
                        <?php $__errorArgs = ['obyek5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-0lax"><span style="font-style:normal">Jumlah/</span><span
                            style="font-style:italic">Total</span></td>
                    <td class="tg-cly1"><input type="text" class="form-control <?php $__errorArgs = ['obyekt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="obyekt" name="obyekt" value="<?php echo e(old('obyekt', $data->obyekt)); ?>">
                        <?php $__errorArgs = ['obyekt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <script>
        function sumObyeks() {
            var obyekElements = document.querySelectorAll('[id^="obyek"]');
            var obyekSum = 0;
            for (var i = 0; i < obyekElements.length; i++) {
                if (obyekElements[i].id !== "obyekt") {
                    var obyekValue = parseFloat(obyekElements[i].value) || 0;
                    obyekSum += obyekValue;
                }
            }
            document.getElementById('obyekt').value = obyekSum;
        }

        var obyekInputs = document.querySelectorAll('[id^="obyek"]');
        for (var i = 0; i < obyekInputs.length; i++) {
            obyekInputs[i].addEventListener('focusout', sumObyeks);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/050_Inspekda/050002.blade.php ENDPATH**/ ?>