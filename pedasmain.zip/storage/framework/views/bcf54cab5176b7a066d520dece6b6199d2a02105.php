<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                    <th class="tg-amwm" rowspan="2">11.2.7</th>
                    <th class="tg-wa1i" colspan="4"><span style="font-weight:bold">Jumlah Kelompok Informasi Masyarakat
                            menurut Kecamatan di Kabupaten Soppeng, <?php echo e($data->tahun); ?></span></th>
                </tr>
                <tr>
                    <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                    <th class="tg-xxp7" colspan="4"><span style="font-weight:bold;font-style:italic">Number of
                            Community Information Groups by Subdistrict in Soppeng Regency, <?php echo e($data->tahun); ?></span>
                    </th>
                </tr>
            </thead>
            <tbody>

                <tr>
                    <td class="tg-baqh" colspan="2" rowspan="2"><span
                            style="font-style:normal;color:#000">Kecamatan/</span><span
                            style="font-style:italic;color:#000">Subdistrict</span></td>
                    <td class="tg-baqh" rowspan="2"><?php echo e($data->tahun); ?></td>

                </tr>
                <tr>
                </tr>
                <tr>
                    <td class="tg-nrix" colspan="2">(1)</td>
                    <td class="tg-nrix">(2)</td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">010. Marioriwawo</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok1"
                            name="kelompok1" value="<?php echo e(old('kelompok1', $data->kelompok1)); ?>">
                        <?php $__errorArgs = ['kelompok1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">020. Lalabata</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok2"
                            name="kelompok2" value="<?php echo e(old('kelompok2', $data->kelompok2)); ?>">
                        <?php $__errorArgs = ['kelompok2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">030. Liliriaja</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok3"
                            name="kelompok3" value="<?php echo e(old('kelompok3', $data->kelompok3)); ?>">
                        <?php $__errorArgs = ['kelompok3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">031. Ganra</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok4"
                            name="kelompok4" value="<?php echo e(old('kelompok4', $data->kelompok4)); ?>">
                        <?php $__errorArgs = ['kelompok4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">032. Citta</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok5"
                            name="kelompok5" value="<?php echo e(old('kelompok5', $data->kelompok5)); ?>">
                        <?php $__errorArgs = ['kelompok5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">040. Lilirilau</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok6"
                            name="kelompok6" value="<?php echo e(old('kelompok6', $data->kelompok6)); ?>">
                        <?php $__errorArgs = ['kelompok6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">050. Donri-Donri</span>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok7"
                            name="kelompok7" value="<?php echo e(old('kelompok7', $data->kelompok7)); ?>">
                        <?php $__errorArgs = ['kelompok7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">060. Marioriawa</span>
                    </td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompok8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompok8"
                            name="kelompok8" value="<?php echo e(old('kelompok8', $data->kelompok8)); ?>">
                        <?php $__errorArgs = ['kelompok8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-baqh" colspan="2" rowspan="2"><span
                            style="font-style:normal;color:#000">Jumlah/</span><span
                            style="font-style:italic;color:#000">
                            Total</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['kelompokt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kelompokt"
                            name="kelompokt" value="<?php echo e(old('kelompokt', $data->kelompokt)); ?>">
                        <?php $__errorArgs = ['kelompokt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-wa1i"><span style="font-weight:bold">Tabel</span></th>
                <th class="tg-amwm" rowspan="2">11.2.7</th>
                <th class="tg-wa1i" colspan="4"><span style="font-weight:bold">Jumlah Kelompok Informasi
                        Masyarakat
                        menurut Kecamatan di Kabupaten Soppeng, <?php echo e($data->tahun); ?></span></th>
            </tr>
            <tr>
                <th class="tg-xxp7"><span style="font-weight:bold;font-style:italic">Table</span></th>
                <th class="tg-xxp7" colspan="4"><span style="font-weight:bold;font-style:italic">Number of
                        Community Information Groups by Subdistrict in Soppeng Regency, <?php echo e($data->tahun); ?></span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
                <td class="tg-7zrl"></td>
            </tr>
            <tr>
                <td class="tg-baqh" colspan="2" rowspan="2"><span
                        style="font-style:normal;color:#000">Kecamatan/</span><br><span
                        style="font-style:italic;color:#000">Subdistrict</span></td>
                <td class="tg-baqh" rowspan="2"><?php echo e($data->tahun); ?></td>
                <td class="tg-baqh" rowspan="2">2019</td>
                <td class="tg-baqh" rowspan="2">2020</td>
                <td class="tg-baqh" rowspan="2">2021</td>
            </tr>
            <tr>
            </tr>
            <tr>
                <td class="tg-nrix" colspan="2">(1)</td>
                <td class="tg-nrix">(2)</td>
                <td class="tg-nrix">(3)</td>
                <td class="tg-nrix">(4)</td>
                <td class="tg-nrix">(5)</td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">010. Marioriwawo</span></td>
                <td class="tg-mwxe">8</td>
                <td class="tg-mwxe">&nbsp;&nbsp;8 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;8 </td>
                <td class="tg-lec9"><span style="background-color:#D7F3CB">&nbsp;&nbsp;8 </span></td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">020. Lalabata</span></td>
                <td class="tg-mwxe">1</td>
                <td class="tg-mwxe">&nbsp;&nbsp;7 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;7 </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;7 </span></td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">030. Liliriaja</span></td>
                <td class="tg-mwxe">8</td>
                <td class="tg-mwxe">&nbsp;&nbsp;8 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;8 </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;8 </span></td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">031. Ganra</span></td>
                <td class="tg-mwxe">4</td>
                <td class="tg-mwxe">&nbsp;&nbsp;4 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;4 </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;4 </span></td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">032. Citta</span></td>
                <td class="tg-mwxe">3</td>
                <td class="tg-mwxe">&nbsp;&nbsp;3 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;3 </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;3 </span></td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">040. Lilirilau</span></td>
                <td class="tg-mwxe">12</td>
                <td class="tg-mwxe">&nbsp;&nbsp;12 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;12 </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;12 </span></td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">050. Donri-Donri</span></td>
                <td class="tg-mwxe">9</td>
                <td class="tg-mwxe">&nbsp;&nbsp;9 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;9 </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;9 </span></td>
            </tr>
            <tr>
                <td class="tg-zr06" colspan="2"><span style="background-color:#FFF">060. Marioriawa</span></td>
                <td class="tg-mwxe">3</td>
                <td class="tg-mwxe">&nbsp;&nbsp;3 </td>
                <td class="tg-mwxe">&nbsp;&nbsp;3 </td>
                <td class="tg-iygw"><span style="background-color:#D7F3CB">&nbsp;&nbsp;7 </span></td>
            </tr>
            <tr>
                <td class="tg-baqh" colspan="2" rowspan="2"><span
                        style="font-style:normal;color:#000">Jumlah/</span><span style="font-style:italic;color:#000">
                        Total</span></td>
                <td class="tg-lqy6" rowspan="2">&nbsp;&nbsp;48 </td>
                <td class="tg-lqy6" rowspan="2">&nbsp;&nbsp;54 </td>
                <td class="tg-lqy6" rowspan="2">&nbsp;&nbsp;54 </td>
                <td class="tg-lqy6" rowspan="2">&nbsp;&nbsp;58 </td>
            </tr>
            <tr>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <script>
        function sumKelompoks() {
            var kelompokElements = document.querySelectorAll('[id^="kelompok"]');
            var kelompokSum = 0;
            for (var i = 0; i < kelompokElements.length; i++) {
                if (kelompokElements[i].id !== "kelompokt") {
                    var kelompokValue = parseFloat(kelompokElements[i].value) || 0;
                    kelompokSum += kelompokValue;
                }
            }
            document.getElementById('kelompokt').value = kelompokSum;
        }

        var kelompokInputs = document.querySelectorAll('[id^="kelompok"]');
        for (var i = 0; i < kelompokInputs.length; i++) {
            kelompokInputs[i].addEventListener('focusout', sumKelompoks);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/019_Diskominfo/019001.blade.php ENDPATH**/ ?>