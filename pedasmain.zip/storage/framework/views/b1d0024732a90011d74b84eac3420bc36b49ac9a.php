<?php if(!empty($data)): ?>
    <form action="/user/update/<?php echo e($data->tipetabel); ?>/<?php echo e($data->kodetabel); ?>"method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <p><?php echo e($judultabel); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th class="tg-bobw" colspan="5"><span style="font-weight:bold">PSB POTS/ INDIHOME</span></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="tg-bobw"><span style="font-weight:bold">Bulan</span></td>

                    <td class="tg-bobw"><span style="font-weight:bold"><?php echo e($data->tahun); ?></span></td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Januari</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome1"
                            name="indihome1" value="<?php echo e(old('indihome1', $data->indihome1)); ?>">
                        <?php $__errorArgs = ['indihome1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Februari</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome2"
                            name="indihome2" value="<?php echo e(old('indihome2', $data->indihome2)); ?>">
                        <?php $__errorArgs = ['indihome2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Maret</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome3"
                            name="indihome3" value="<?php echo e(old('indihome3', $data->indihome3)); ?>">
                        <?php $__errorArgs = ['indihome3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">April</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome4"
                            name="indihome4" value="<?php echo e(old('indihome4', $data->indihome4)); ?>">
                        <?php $__errorArgs = ['indihome4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Mei</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome5"
                            name="indihome5" value="<?php echo e(old('indihome5', $data->indihome5)); ?>">
                        <?php $__errorArgs = ['indihome5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Juni</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome6"
                            name="indihome6" value="<?php echo e(old('indihome6', $data->indihome6)); ?>">
                        <?php $__errorArgs = ['indihome6'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Juli</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome7"
                            name="indihome7" value="<?php echo e(old('indihome7', $data->indihome7)); ?>">
                        <?php $__errorArgs = ['indihome7'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Agustus</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome8"
                            name="indihome8" value="<?php echo e(old('indihome8', $data->indihome8)); ?>">
                        <?php $__errorArgs = ['indihome8'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">September</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome9"
                            name="indihome9" value="<?php echo e(old('indihome9', $data->indihome9)); ?>">
                        <?php $__errorArgs = ['indihome9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Oktober</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome10"
                            name="indihome10" value="<?php echo e(old('indihome10', $data->indihome10)); ?>">
                        <?php $__errorArgs = ['indihome10'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">November</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome11"
                            name="indihome11" value="<?php echo e(old('indihome11', $data->indihome11)); ?>">
                        <?php $__errorArgs = ['indihome11'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-7zrl"><span style="font-weight:normal">Desember</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihome12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihome12"
                            name="indihome12" value="<?php echo e(old('indihome12', $data->indihome12)); ?>">
                        <?php $__errorArgs = ['indihome12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-bobw"><span style="font-weight:bold">Jumlah</span></td>
                    <td class="tg-cly1"><input type="text"
                            class="form-control <?php $__errorArgs = ['indihomet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="indihomet"
                            name="indihomet" value="<?php echo e(old('indihomet', $data->indihomet)); ?>">
                        <?php $__errorArgs = ['indihomet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php echo $__env->make('tabel.catatan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="py-3 text-right">
            <button type="submit"class="btn  btn-success ">Simpan</button>
            <?php if(Auth::user()->role == 1): ?>
                <a class="btn btn-info"href="<?php echo e(route('admin.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php else: ?>
                <a class="btn btn-info"href="<?php echo e(route('user.dashboard.DaftarEntri')); ?>"role="button">Batal</a>
            <?php endif; ?>
        </div>
    </form>
<?php else: ?>
    
    <p><?php echo e($judultabel); ?></p>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="tg-bobw" colspan="5"><span style="font-weight:bold">PSB POTS/ INDIHOME</span></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="tg-bobw"><span style="font-weight:bold">Bulan</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2018</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2019</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2020</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">2021</span></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Januari</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Februari</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Maret</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">April</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Mei</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Juni</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Juli</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Agustus</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">September</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Oktober</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">November</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-7zrl"><span style="font-weight:normal">Desember</span></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
                <td class="tg-l6sh"></td>
            </tr>
            <tr>
                <td class="tg-bobw"><span style="font-weight:bold">Jumlah</span></td>
                <td class="tg-bobw"><span style="font-weight:bold">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
                <td class="tg-2b7s"><span style="font-weight:normal">0</span></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->startSection('script'); ?>
    
    <script>
        function sumIndihomes() {
            var indihomeElements = document.querySelectorAll('[id^="indihome"]');
            var indihomeSum = 0;
            for (var i = 0; i < indihomeElements.length; i++) {
                if (indihomeElements[i].id !== "indihomet") {
                    var indihomeValue = parseFloat(indihomeElements[i].value) || 0;
                    indihomeSum += indihomeValue;
                }
            }
            document.getElementById('indihomet').value = indihomeSum;
        }

        var indihomeInputs = document.querySelectorAll('[id^="indihome"]');
        for (var i = 0; i < indihomeInputs.length; i++) {
            indihomeInputs[i].addEventListener('focusout', sumIndihomes);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\USER\pedas\resources\views/tabel/SKPD/048_Telkom_Cangadi/048012.blade.php ENDPATH**/ ?>