<?php

namespace App\Models\Tables;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class T043006 extends Model
{
    use HasFactory;
    protected $guarded = [
        'id'
    ];
}
