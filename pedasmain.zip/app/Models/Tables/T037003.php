<?php

namespace App\Models\Tables;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class T037003 extends Model
{
    use HasFactory;
    protected $guarded = [
        'id'
    ];
}
