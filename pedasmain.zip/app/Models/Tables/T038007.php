<?php

namespace App\Models\Tables;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class T038007 extends Model
{
    protected $guarded = [
        'id'
    ];
}
