<?php

namespace App\Models\Tables;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class T038011 extends Model
{
    protected $guarded = [
        'id'
    ];
}
